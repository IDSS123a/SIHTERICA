# -*- coding: utf-8 -*-
import os, sys, traceback
D = os.path.dirname(os.path.abspath(__file__))
try:
    sys.path.insert(0, D)
    import gui
    app = gui.App()
    if app.ok: app.mainloop()
except SystemExit:
    raise
except BaseException:
    msg = traceback.format_exc()
    with open(os.path.join(D, "greska_pokretanja.txt"), "w", encoding="utf-8") as f: f.write(msg)
    print(msg); input("Doslo je do greske (zapisana u greska_pokretanja.txt). Pritisnite Enter...")
