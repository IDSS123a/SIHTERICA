@echo off
cd /d "%~dp0"
echo Pokrecem IDSS Evidenciju radnog vremena...
set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY python --version >nul 2>&1 && set "PY=python"
if not defined PY goto nopy
echo Koristim: %PY%
%PY% -c "import openpyxl" >nul 2>&1 || %PY% -m pip install --upgrade openpyxl
%PY% -c "import openpyxl" >nul 2>&1 || goto nolib
%PY% -c "import xlrd" >nul 2>&1 || %PY% -m pip install xlrd >nul 2>&1
%PY% -c "import tkinter" >nul 2>&1 || goto notk
%PY% start.py
echo.
echo Program je zatvoren. Ako je doslo do greske, pogledajte datoteku greska_pokretanja.txt u ovoj mapi.
pause
exit /b 0

:nopy
echo.
echo PYTHON NIJE PRONADJEN. Instalirajte ga sa https://www.python.org/downloads/
echo i pri instalaciji OBAVEZNO oznacite "Add python.exe to PATH". Zatim ponovo pokrenite ovu datoteku.
pause
exit /b 1

:nolib
echo.
echo Biblioteka openpyxl nije instalirana (potreban je internet pri prvom pokretanju).
echo Provjerite internet vezu i pokrenite ponovo.
pause
exit /b 1

:notk
echo.
echo Ovoj instalaciji Pythona nedostaje Tkinter (grafika). Ponovo pokrenite instalaciju Pythona,
echo odaberite "Modify" i oznacite "tcl/tk and IDLE".
pause
exit /b 1
