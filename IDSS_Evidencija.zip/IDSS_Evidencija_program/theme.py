# -*- coding: utf-8 -*-
"""Vizuelni identitet: pet boja (crna, žuta #FFCB29, plava #035EA1, crvena #E8262C, bijela) + neutralne nijanse samo za pozadine i sporedni tekst."""
BLACK = "#000000"
YELLOW = "#FFCB29"
BLUE = "#035EA1"
RED = "#E8262C"
WHITE = "#FFFFFF"
# neutralne nijanse: SAMO pozadine i sporedni tekst
BG = "#F4F4F4"        # pozadina sadržaja
CARD = "#FFFFFF"
LINE = "#DADADA"
TEXT = "#111111"
MUTED = "#5A5A5A"
BLUE_DARK = "#024677"  # hover plave (tamnija nijansa iste boje)
YELLOW_DARK = "#E6B400"
BLUE_SOFT = "#E6F0F8"  # blijeda plava za izabrani red (pozadina)

FONT_STACK = ("Segoe UI Variable Text", "Segoe UI Variable", "Segoe UI", "SF Pro Text", "SF Pro Display", "Roboto", "Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans")

def pick_font(available):
    low = {f.lower(): f for f in available}
    for name in FONT_STACK:
        if name.lower() in low: return low[name.lower()]
    return "TkDefaultFont"

class Fonts:
    def __init__(self, family):
        self.family = family
        self.base = (family, 10); self.small = (family, 9); self.bold = (family, 10, "bold")
        self.h1 = (family, 16, "bold"); self.h2 = (family, 12, "bold"); self.kpi = (family, 24, "bold")
        self.title = (family, 14, "bold"); self.nav = (family, 10, "bold"); self.mono = ("Consolas", 10)
