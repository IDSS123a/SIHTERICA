# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk
import theme as T, charts

class Btn(tk.Button):
    KINDS = {"primary": (T.YELLOW, T.BLACK, T.YELLOW_DARK), "secondary": (T.BLUE, T.WHITE, T.BLUE_DARK),
             "danger": (T.RED, T.WHITE, "#C41E24"), "ghost": (T.WHITE, T.BLACK, "#EDEDED")}
    def __init__(self, parent, text, command, fonts, kind="secondary", **kw):
        bg, fg, hover = self.KINDS[kind]
        super().__init__(parent, text=text, command=command, bg=bg, fg=fg, activebackground=hover, activeforeground=fg, relief="flat", bd=0,
                         padx=16, pady=7, cursor="hand2", font=fonts.bold, highlightthickness=1 if kind == "ghost" else 0,
                         highlightbackground=T.BLACK, **kw)
        self._bg, self._hover = bg, hover
        self.bind("<Enter>", lambda e: self.configure(bg=self._hover)); self.bind("<Leave>", lambda e: self.configure(bg=self._bg))

class Card(tk.Frame):
    def __init__(self, parent, **kw):
        super().__init__(parent, bg=T.CARD, highlightbackground=T.LINE, highlightthickness=1, **kw)

class ChartCanvas(tk.Canvas):
    """Platno koje crta scenu iz charts.py i prikazuje oblačić (tooltip) kad se miš zadrži na tački/traci."""
    def __init__(self, parent, builder, fonts, height=300, **kw):
        super().__init__(parent, height=height, bg=T.WHITE, highlightthickness=0, **kw)
        self.builder, self.fonts, self.scene = builder, fonts, None
        self.bind("<Configure>", lambda e: self.redraw()); self.bind("<Motion>", self._move); self.bind("<Leave>", lambda e: self.delete("tip"))
    def redraw(self):
        w, h = max(self.winfo_width(), 200), max(self.winfo_height(), 120)
        self.scene = self.builder(w, h); charts.draw_tk(self, self.scene, self.fonts.family)
    def _move(self, e):
        self.delete("tip")
        tip = self.scene.hit_at(e.x, e.y) if self.scene else None
        if not tip: return
        x = min(e.x + 14, max(10, self.winfo_width() - 190)); y = max(8, e.y - 12)
        t = self.create_text(x + 8, y + 6, text=tip, anchor="nw", fill=T.WHITE, font=self.fonts.small, tags="tip")
        x0, y0, x1, y1 = self.bbox(t)
        r = self.create_rectangle(x0 - 8, y0 - 6, x1 + 8, y1 + 6, fill=T.BLACK, outline=T.YELLOW, width=2, tags="tip")
        self.tag_raise(t, r)

# ------------------------------------------------------------------ dijalozi
ACCENT = {"ok": T.BLUE, "info": T.BLUE, "warn": T.YELLOW, "error": T.RED, "ask": T.BLUE}
BADGE = {"ok": ("USPJEH", T.BLUE, T.WHITE), "info": ("OBAVIJEST", T.BLUE, T.WHITE), "warn": ("UPOZORENJE", T.YELLOW, T.BLACK),
         "error": ("GREŠKA", T.RED, T.WHITE), "ask": ("POTVRDA", T.BLUE, T.WHITE)}

def _visible(parent):
    try: return bool(parent.winfo_viewable())
    except Exception: return False

def _transient(win, parent):
    if _visible(parent): win.transient(parent)       # za skriveni glavni prozor (prijava) transient bi sakrio dijalog
    win.attributes("-topmost", True)

def _center(win, parent):
    win.update_idletasks()
    try:
        if _visible(parent): x = parent.winfo_rootx() + (parent.winfo_width() - win.winfo_width()) // 2; y = parent.winfo_rooty() + (parent.winfo_height() - win.winfo_height()) // 3
        else: x = (win.winfo_screenwidth() - win.winfo_width()) // 2; y = (win.winfo_screenheight() - win.winfo_height()) // 3
    except Exception: x, y = 200, 150
    win.geometry(f"+{max(0, x)}+{max(0, y)}")

def message(parent, fonts, kind, title, text, ask=False):
    """kind: ok/info (plava), warn (žuta), error (crni tekst, crveni rub). Vraća True/False za pitanja."""
    win = tk.Toplevel(parent); win.title(title); win.configure(bg=T.WHITE)
    _transient(win, parent); win.resizable(False, False); res = {"v": False}
    outer = tk.Frame(win, bg=T.WHITE, highlightbackground=ACCENT[kind], highlightcolor=ACCENT[kind], highlightthickness=3); outer.pack(fill="both", expand=True)
    badge, bbg, bfg = BADGE[kind]
    head = tk.Frame(outer, bg=T.WHITE); head.pack(fill="x", padx=20, pady=(18, 6))
    tk.Label(head, text=badge, bg=bbg, fg=bfg, font=(fonts.family, 8, "bold"), padx=8, pady=2).pack(side="left")
    tk.Label(head, text=title, bg=T.WHITE, fg=T.BLACK, font=fonts.title).pack(side="left", padx=10)
    tk.Label(outer, text=text, bg=T.WHITE, fg=T.BLACK, font=fonts.base, justify="left", wraplength=520, anchor="w").pack(fill="x", padx=20, pady=(4, 14))
    bar = tk.Frame(outer, bg=T.WHITE); bar.pack(fill="x", padx=20, pady=(0, 18))
    def done(v): res["v"] = v; win.destroy()
    if ask:
        Btn(bar, "Da", lambda: done(True), fonts, "primary").pack(side="right", padx=(8, 0)); Btn(bar, "Ne", lambda: done(False), fonts, "ghost").pack(side="right")
    else: Btn(bar, "U redu", lambda: done(True), fonts, "primary").pack(side="right")
    win.bind("<Escape>", lambda e: done(False)); win.protocol("WM_DELETE_WINDOW", lambda: done(False))
    _center(win, parent); win.grab_set(); win.focus_force(); parent.wait_window(win); return res["v"]

def ask_text(parent, fonts, title, prompt, secret=True):
    win = tk.Toplevel(parent); win.title(title); _transient(win, parent); win.resizable(False, False); res = {"v": None}
    outer = tk.Frame(win, bg=T.WHITE, highlightbackground=T.BLUE, highlightthickness=3); outer.pack(fill="both", expand=True)
    tk.Label(outer, text=title, bg=T.WHITE, fg=T.BLACK, font=fonts.title).pack(anchor="w", padx=20, pady=(18, 4))
    tk.Label(outer, text=prompt, bg=T.WHITE, fg=T.MUTED, font=fonts.base, wraplength=420, justify="left").pack(anchor="w", padx=20)
    v = tk.StringVar(); e = ttk.Entry(outer, textvariable=v, show="*" if secret else "", width=44); e.pack(padx=20, pady=12)
    bar = tk.Frame(outer, bg=T.WHITE); bar.pack(fill="x", padx=20, pady=(0, 18))
    def ok(): res["v"] = v.get(); win.destroy()
    Btn(bar, "U redu", ok, fonts, "primary").pack(side="right", padx=(8, 0)); Btn(bar, "Odustani", win.destroy, fonts, "ghost").pack(side="right")
    win.bind("<Return>", lambda ev: ok()); win.bind("<Escape>", lambda ev: win.destroy())
    _center(win, parent); win.grab_set(); e.focus_set(); parent.wait_window(win); return res["v"]

class Form(tk.Toplevel):
    """Dijalog s poljima. fields: [(ključ, oznaka, početna vrijednost, [opcije])]"""
    def __init__(self, parent, fonts, title, fields):
        super().__init__(parent); self.title(title); self.result = None; _transient(self, parent); self.vars = {}
        outer = tk.Frame(self, bg=T.WHITE, highlightbackground=T.BLUE, highlightthickness=3); outer.pack(fill="both", expand=True)
        tk.Label(outer, text=title, bg=T.WHITE, fg=T.BLACK, font=fonts.title).grid(row=0, column=0, columnspan=2, sticky="w", padx=20, pady=(16, 8))
        for i, (key, label, init, *opts) in enumerate(fields, 1):
            tk.Label(outer, text=label, bg=T.WHITE, fg=T.BLACK, font=fonts.base, wraplength=260, justify="left").grid(row=i, column=0, sticky="w", padx=(20, 10), pady=5)
            v = tk.StringVar(value="" if init is None else str(init)); self.vars[key] = v
            w = ttk.Combobox(outer, textvariable=v, values=opts[0], state="readonly", width=38) if opts else ttk.Entry(outer, textvariable=v, width=40)
            w.grid(row=i, column=1, padx=(0, 20), pady=5)
        bar = tk.Frame(outer, bg=T.WHITE); bar.grid(row=len(fields) + 1, column=0, columnspan=2, sticky="e", padx=20, pady=16)
        Btn(bar, "Spremi", self.ok, fonts, "primary").pack(side="right", padx=(8, 0)); Btn(bar, "Odustani", self.destroy, fonts, "ghost").pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy()); _center(self, parent); self.grab_set(); parent.wait_window(self)
    def ok(self): self.result = {k: v.get().strip() for k, v in self.vars.items()}; self.destroy()

def style_ttk(root, fonts):
    st = ttk.Style(root)
    try: st.theme_use("clam")
    except tk.TclError: pass
    st.configure(".", font=fonts.base, background=T.BG, foreground=T.TEXT)
    st.configure("Treeview", background=T.WHITE, fieldbackground=T.WHITE, foreground=T.TEXT, rowheight=26, bordercolor=T.LINE, lightcolor=T.WHITE, darkcolor=T.WHITE, borderwidth=0)
    st.configure("Treeview.Heading", background=T.BLACK, foreground=T.WHITE, font=fonts.bold, relief="flat", padding=(8, 7))
    st.map("Treeview.Heading", background=[("active", T.BLUE)])
    st.map("Treeview", background=[("selected", T.BLUE)], foreground=[("selected", T.WHITE)])
    st.configure("TCombobox", fieldbackground=T.WHITE, background=T.WHITE, foreground=T.TEXT, bordercolor=T.LINE, arrowcolor=T.BLUE, padding=4)
    st.configure("TEntry", fieldbackground=T.WHITE, bordercolor=T.LINE, padding=5)
    st.configure("TSpinbox", fieldbackground=T.WHITE, bordercolor=T.LINE, arrowcolor=T.BLUE, padding=4)
    st.configure("TScrollbar", background=T.LINE, troughcolor=T.BG, bordercolor=T.BG, arrowcolor=T.BLACK)
    st.configure("TLabel", background=T.BG, foreground=T.TEXT)


def choice(parent, fonts, title, text, options):
    """Dijalog s više dugmadi. options = [(oznaka, vrsta)] vrsta: primary/secondary/ghost. Vraća indeks ili None."""
    win = tk.Toplevel(parent); win.title(title); _transient(win, parent); win.resizable(False, False); res = {"v": None}
    outer = tk.Frame(win, bg=T.WHITE, highlightbackground=T.BLUE, highlightthickness=3); outer.pack(fill="both", expand=True)
    tk.Label(outer, text=title, bg=T.WHITE, fg=T.BLACK, font=fonts.title).pack(anchor="w", padx=20, pady=(18, 6))
    tk.Label(outer, text=text, bg=T.WHITE, fg=T.BLACK, font=fonts.base, justify="left", wraplength=540, anchor="w").pack(fill="x", padx=20, pady=(0, 14))
    bar = tk.Frame(outer, bg=T.WHITE); bar.pack(fill="x", padx=20, pady=(0, 18))
    def done(i): res["v"] = i; win.destroy()
    for i, (lab, kind) in reversed(list(enumerate(options))): Btn(bar, lab, lambda i=i: done(i), fonts, kind).pack(side="right", padx=(8, 0))
    win.bind("<Escape>", lambda e: win.destroy()); _center(win, parent); win.grab_set(); parent.wait_window(win); return res["v"]
