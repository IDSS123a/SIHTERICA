# -*- coding: utf-8 -*-
"""BRUTALNI testovi: nasumični podaci, svi mjeseci, oštećene datoteke, prekid usred upisa, ekstremni nazivi, brzina."""
import os, sys, random, time, zipfile, sqlite3, datetime as dt, unittest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import inspekcija
from openpyxl import load_workbook, Workbook
D = dt.date

def rand_times(rng, kind):
    base = {"2": [(7, 45, 8, 30), (13, 30, 16, 30)], "4": [(7, 45, 8, 15), (11, 30, 12, 15), (12, 30, 13, 15), (15, 30, 17, 30)]}
    if kind in ("2", "4"):
        slots = base[kind]; ts = [f"{rng.randint(a, c):02d}:{rng.randint(0, 59) if (a != c) else rng.randint(b, d):02d}" for a, b, c, d in slots]
        ts = sorted(ts)
        if kind == "4" and not (ts[0] < ts[1] < ts[2] < ts[3]): return rand_times(rng, "2")
        return ts
    n = {"0": 0, "1": 1, "3": 3, "5": 5, "6": 6}[kind]
    return sorted({f"{rng.randint(6, 18):02d}:{rng.randint(0, 59):02d}" for _ in range(n)})

class Stress(Base):
    def test_nasumicni_podaci_35_radnika_citav_mjesec(self):
        for seed in (1, 2, 3):
            rng = random.Random(seed); db = core.DB(os.path.join(self.d, f"s{seed}")); db.load_employees_xlsx(EMP_XLSX)
            period = (D(2026, 9, 1), D(2026, 9, 30)); data = {}
            for no in range(1, 36):
                days = {}
                for i in range(30):
                    day = period[0] + dt.timedelta(i)
                    kind = rng.choices(["0", "1", "2", "3", "4", "5", "6"], [20 if day.weekday() < 5 else 70, 3, 55, 3, 12, 2, 1])[0]
                    ts = rand_times(rng, kind)
                    if ts and rng.random() < .1: ts = sorted(ts + [f"{ts[0][:3]}{int(ts[0][3:]) + 1:02d}"] if int(ts[0][3:]) < 59 else ts)   # duplikat
                    if ts: days[day.isoformat()] = "\n".join(ts)
                data[no] = days
            p = os.path.join(self.d, f"r{seed}.xlsx"); device_file(p, period, data)
            r = core.import_device_file(db, p); self.assertGreater(r["novih"], 500)
            ids = [e["id"] for e in db.employees()]
            for k in range(60):                                   # nasumične korekcije i odsustva
                emp = rng.choice(ids); day = f"2026-09-{rng.randint(1, 30):02d}"
                if rng.random() < .5: db.add_correction(emp, day, rng.choice(["start", "end"]), f"{rng.randint(7, 17):02d}:{rng.randint(0, 59):02d}", "Ručna korekcija – test")
                else: db.add_absence(emp, day, rng.choice(list(core.VRSTE_ODSUSTVA)), rng.choice([0, 4, 7.5, 8]), "Napomena test")
            out = os.path.join(self.d, f"sih{seed}.xlsx"); t = time.time()
            # nasumične korekcije mogu stvoriti nelogičan unos (npr. kraj prije početka): izvoz tada smije stati, ali nikad pasti niti prijeći preko greške
            try: core.export_sihtarica(db, TPL, out, 2026, 9, allow_unresolved=True, soffice_cmd=SOFFICE)
            except core.AppError as e:
                self.assertIn("inspekcija nije prošla", str(e)); rep = inspekcija.inspect_month(db, TPL, 2026, 9, allow_unresolved=True, soffice_cmd=SOFFICE)
                self.assertFalse(rep.ok)
                for f in rep.findings:
                    if f[0] == "GREŠKA": self.assertIn(f[3], ("INTERVAL", "PAUZA", "SATI", "PREKO_PONOCI"), f)     # samo logičke greške unosa, nikad kanon/formule
            else:
                self.assertTrue(os.path.exists(out))
            db.c.close()

    def test_svi_mjeseci_2026_2028(self):
        for y in (2026, 2027, 2028):
            for m in range(1, 13):
                db = core.DB(os.path.join(self.d, f"m{y}{m}")); db.load_employees_xlsx(EMP_XLSX)
                n = (D(y + (m == 12), m % 12 + 1, 1) - D(y, m, 1)).days
                for i in (1, 2, n - 1, n):
                    d = D(y, m, i)
                    for t in ("08:00", "16:00"): db.c.execute("INSERT INTO punches(emp,ts) VALUES(?,?)", ("IDSS-001", f"{d}T{t}"))
                db.c.commit()
                use_lo = SOFFICE and (y == 2028 or (y, m) in ((2026, 2), (2027, 2), (2027, 12), (2026, 12)))
                out = os.path.join(self.d, f"o{y}{m}.xlsx")
                if use_lo: core.export_sihtarica(db, TPL, out, y, m, ["IDSS-001"], soffice_cmd=SOFFICE)
                else:
                    rep_path = out; core.export_sihtarica(db, TPL, out, y, m, ["IDSS-001"], verify=False)
                    rep = inspekcija.inspect_file(db, out, y, m, ["IDSS-001"], template=TPL, recalc=False); self.assertTrue(rep.ok, rep.to_text())
                ws = load_workbook(out)[load_workbook(out).sheetnames[0]]
                self.assertEqual(ws["B3"].value, core.MJESECI[m - 1]); self.assertEqual(ws["D3"].value, y)
                self.assertEqual(ws[f"D{6 + n}"].value, dt.time(8, 0))               # posljednji dan mjeseca
                db.c.close()

class Oštećeno(Base):
    def uvoz_mora_pasti_cisto(self, path, ocekuj=None):
        before = self.db.c.execute("SELECT COUNT(*) FROM punches").fetchone()[0]
        with self.assertRaises(core.AppError) as c: core.import_device_file(self.db, path)
        if ocekuj: self.assertIn(ocekuj, str(c.exception))
        self.assertEqual(self.db.c.execute("SELECT COUNT(*) FROM punches").fetchone()[0], before)
        self.assertEqual(self.db.c.execute("SELECT COUNT(*) FROM sources").fetchone()[0], 0)

    def test_losi_fajlovi(self):
        p = os.path.join(self.d, "prazan.xlsx"); open(p, "wb").write(b""); self.uvoz_mora_pasti_cisto(p)
        p = os.path.join(self.d, "smece.xlsx"); open(p, "wb").write(os.urandom(5000)); self.uvoz_mora_pasti_cisto(p)
        p = os.path.join(self.d, "tekst.txt"); open(p, "w").write("ID,1"); self.uvoz_mora_pasti_cisto(p, "Podržane su samo")
        real = os.path.join(HERE, "uzorci", "All_Report_1.xlsx"); raw = open(real, "rb").read()
        p = os.path.join(self.d, "odsjecen.xlsx"); open(p, "wb").write(raw[: len(raw) // 2]); self.uvoz_mora_pasti_cisto(p)
        p = os.path.join(self.d, "nema_logova.xlsx"); wb = Workbook(); wb.active.title = "Nesto"; wb.save(p); self.uvoz_mora_pasti_cisto(p, "Attendance Logs")
        p = os.path.join(self.d, "nema_dana.xlsx"); wb = Workbook(); wb.active.title = "Attendance Logs"; wb.active.append(["x"]); wb.save(p); self.uvoz_mora_pasti_cisto(p, "period")

    def test_losi_sadrzaji(self):
        cases = {"vrijeme_25_61": ({1: {"2026-10-02": "25:61"}}, "ne razumijem"), "tekst_u_celiji": ({1: {"2026-10-02": "08:00 kasni"}}, "ne razumijem"),
                 "nepoznat_id": ({7777: {"2026-10-02": "08:00"}}, "nepoznat ID"), "samo_prazno": ({1: {}}, "nijednog otiska")}
        for name, (data, msg) in cases.items():
            p = os.path.join(self.d, name + ".xlsx"); device_file(p, (D(2026, 10, 1), D(2026, 10, 9)), data); self.uvoz_mora_pasti_cisto(p, msg)
        p = os.path.join(self.d, "obrnut.xlsx"); device_file(p, (D(2026, 10, 9), D(2026, 10, 1)), {1: {"2026-10-02": "08:00"}}); self.uvoz_mora_pasti_cisto(p)
        p = os.path.join(self.d, "predug.xlsx"); device_file(p, (D(2026, 8, 1), D(2026, 9, 15)), {1: {"2026-08-02": "08:00"}}); self.uvoz_mora_pasti_cisto(p, "najviše 31")

    def test_pomaknuti_dani_i_vikend_oznake(self):
        p = os.path.join(self.d, "p.xlsx"); device_file(p, (D(2026, 10, 1), D(2026, 10, 9)), {1: {"2026-10-02": "08:00\n16:00"}})
        wb = load_workbook(p); ws = wb.active; ws["C5"] = "Mon"; wb.save(p)       # oznaka dana ne odgovara datumu
        self.uvoz_mora_pasti_cisto(p, "ne poklapa")

    def test_prekid_usred_upisa_je_atomaran(self):
        p = os.path.join(self.d, "a.xlsx"); device_file(p, (D(2026, 10, 1), D(2026, 10, 9)), {1: {"2026-10-02": "08:00\n16:00", "2026-10-03": "08:00\n16:00"}})
        orig = self.db.c; calls = {"n": 0}
        class Wrap:
            def __init__(s, c): s.c = c
            def execute(s, q, *a):
                if q.startswith("INSERT INTO punches"):
                    calls["n"] += 1
                    if calls["n"] == 3: raise RuntimeError("simulirani pad usred uvoza")
                return s.c.execute(q, *a)
            def __getattr__(s, n): return getattr(s.c, n)
        self.db.c = Wrap(orig)
        with self.assertRaises(RuntimeError): core.import_device_file(self.db, p)
        self.db.c = orig
        self.assertEqual(orig.execute("SELECT COUNT(*) FROM punches").fetchone()[0], 0)
        self.assertEqual(orig.execute("SELECT COUNT(*) FROM sources").fetchone()[0], 0)
        self.assertEqual(core.import_device_file(self.db, p)["novih"], 4)             # poslije pada uvoz radi normalno

class Podaci(Base):
    def test_ekstremna_imena_i_sql(self):
        names = ["Robert'); DROP TABLE employees;--", "A/B:[x]?*\\", "Ž" * 100, "  Razmaci   ", "Ime\nNoviRed", "日本語 名前", "Đ'Č;Ć\"Š"]
        for n in names: self.db.add_employee(n, "Pos'it\"ion", "e@x", "1")
        self.assertEqual(len(self.db.employees()), 35 + len(names))
        self.assertEqual(self.db.c.execute("SELECT COUNT(*) FROM employees").fetchone()[0], 35 + len(names))
        out = os.path.join(self.d, "x.xlsx"); core.export_sihtarica(self.db, TPL, out, 2026, 9, soffice_cmd=SOFFICE)
        wb = load_workbook(out); self.assertEqual(len(wb.sheetnames), 35 + len(names)); self.assertEqual(len(set(wb.sheetnames)), len(wb.sheetnames))
        self.assertTrue(all(len(t) <= 31 and not set('[]:*?/\\') & set(t) for t in wb.sheetnames))
    def test_isto_ime_dva_radnika_je_zabranjeno(self):
        for nm in ("Davor Mulalić", "davor  mulalic", "DAVOR MULALIC"):
            with self.assertRaises(core.AppError): self.db.add_employee(nm)
        self.assertEqual(len(self.db.employees(False)), 35)
    def test_ponocni_rad_se_oznacava_a_ne_nagada(self):
        p = os.path.join(self.d, "n.xlsx"); device_file(p, (D(2026, 10, 1), D(2026, 10, 3)), {1: {"2026-10-01": "22:00", "2026-10-02": "06:00"}})
        core.import_device_file(self.db, p); self.assertEqual(len(core.unresolved(self.db, "IDSS-001", 2026, 10)), 2)
    def test_odsustvo_bez_otisaka_i_zbrajanje(self):
        self.db.add_absence("IDSS-003", "2026-09-07", "godisnji", 4, "a"); self.db.add_absence("IDSS-003", "2026-09-07", "godisnji", 4, "b")
        out = os.path.join(self.d, "z.xlsx"); core.export_sihtarica(self.db, TPL, out, 2026, 9, ["IDSS-003"], soffice_cmd=SOFFICE)
        ws = load_workbook(out).active; self.assertEqual(ws["L13"].value, 8); self.assertEqual(ws["P13"].value, "a; b")
    def test_sifra_zakljucavanje(self):
        import time as _t; orig = _t.sleep; _t.sleep = lambda s: None
        try:
            self.db.set_password("Tajna-sifra-2026")
            for _ in range(6): self.assertFalse(self.db.check_password("x"))
            self.assertTrue(self.db.check_password("Tajna-sifra-2026")); self.assertEqual(self.db.get("login_fails"), "0")
            self.assertNotIn("Tajna", open(self.db.path, "rb").read().decode("latin1"))      # šifra se ne čuva u čistom obliku
        finally: _t.sleep = orig
    def test_baza_prezivi_ponovno_otvaranje_i_integritet(self):
        self.db.add_absence("IDSS-001", "2026-09-01", "bolovanje", 8); self.db.c.commit(); self.db.c.close()
        db2 = core.DB(self.d); self.assertEqual(db2.c.execute("PRAGMA integrity_check").fetchone()[0], "ok"); self.assertEqual(len(db2.absences("IDSS-001", 2026, 9)), 1); self.db = db2
    def test_rezervna_kopija_je_citljiva(self):
        b = self.db.backup(); c = sqlite3.connect(b); self.assertEqual(c.execute("SELECT COUNT(*) FROM employees").fetchone()[0], 35); c.close()

class Brzina(Base):
    def test_puni_mjesec_35_radnika_je_brz(self):
        rng = random.Random(9); period = (D(2026, 9, 1), D(2026, 9, 30)); data = {no: {(period[0] + dt.timedelta(i)).isoformat(): "\n".join(rand_times(rng, "4")) for i in range(30)} for no in range(1, 36)}
        p = os.path.join(self.d, "b.xlsx"); device_file(p, period, data)
        t = time.time(); r = core.import_device_file(self.db, p); t_imp = time.time() - t
        out = os.path.join(self.d, "b_out.xlsx"); t = time.time(); core.export_sihtarica(self.db, TPL, out, 2026, 9, allow_unresolved=True, verify=False); t_exp = time.time() - t
        t = time.time(); rep = inspekcija.inspect_file(self.db, out, 2026, 9, template=TPL, recalc=False, allow_unresolved=True); t_ins = time.time() - t
        print(f"\n  otisaka {r['novih']}: uvoz {t_imp:.1f}s, izvoz {t_exp:.1f}s, inspekcija {t_ins:.1f}s")
        self.assertLess(t_imp, 20); self.assertLess(t_exp, 30); self.assertLess(t_ins, 60); self.assertTrue(rep.ok, rep.errors_text())

if __name__ == "__main__": unittest.main(verbosity=1)

class Revizija(Base):
    def test_migracija_stare_baze(self):
        old = os.path.join(self.d, "stara"); os.makedirs(os.path.join(old, "Podaci"))
        c = sqlite3.connect(os.path.join(old, "Podaci", "idss_evidencija.db"))
        c.executescript("""CREATE TABLE employees(id TEXT PRIMARY KEY, device_no INTEGER UNIQUE NOT NULL, name TEXT NOT NULL, position TEXT, email TEXT, phone TEXT, weekly_hours REAL, active INTEGER NOT NULL DEFAULT 1);
                           INSERT INTO employees(id,device_no,name,position) VALUES('IDSS-001',1,'Davor Mulalić','Director');""")
        c.commit(); c.close()
        db = core.DB(old); e = db.employee("IDSS-001"); self.assertIn("dept", e); self.assertEqual(e["authority"], 0)
        db.update_employee("IDSS-001", dept=1, authority=1); self.assertEqual(db.employee("IDSS-001")["authority"], 1); db.c.close()

    def test_izmijenjen_obrazac_se_otkriva(self):
        bad = os.path.join(self.d, "obrazac.xlsx"); wb = load_workbook(TPL); wb["IDSS - šihtarica"]["A3"] = "Mjesec :"; wb.save(bad)
        rep = inspekcija.Report("x"); self.assertFalse(inspekcija.check_template(bad, rep)); self.assertEqual(rep.findings[0][3], "OBRAZAC")
        self.assertTrue(inspekcija.check_template(TPL, inspekcija.Report("x")))

    def test_izvoz_je_slikovno_identican_obrascu(self):
        if not SOFFICE: self.skipTest("nema LibreOffice-a")
        import subprocess, shutil as sh
        from PIL import Image, ImageChops
        if not sh.which("pdftoppm"): self.skipTest("nema pdftoppm")
        core.export_sihtarica(self.db, TPL, os.path.join(self.d, "e.xlsx"), 2026, 10, ["IDSS-001"], verify=False)
        wb = load_workbook(TPL)
        for n in wb.sheetnames:
            if n != "IDSS - šihtarica": del wb[n]
        ws = wb["IDSS - šihtarica"]; e = self.db.employee("IDSS-001")
        ws["B3"], ws["D3"], ws["F3"], ws["L3"], ws["F4"] = "Oktobar", 2026, e["name"], e["position"], self.db.get("odgovorno_lice"); wb.save(os.path.join(self.d, "r.xlsx"))
        for n in ("e", "r"):
            subprocess.run(SOFFICE + ["--headless", "--convert-to", "pdf", "--outdir", self.d, os.path.join(self.d, n + ".xlsx")], check=True, capture_output=True, timeout=300)
            subprocess.run(["pdftoppm", "-r", "60", "-png", os.path.join(self.d, n + ".pdf"), os.path.join(self.d, n)], check=True)
        a = sorted(f for f in os.listdir(self.d) if f.startswith("e-") and f.endswith(".png")); b = sorted(f for f in os.listdir(self.d) if f.startswith("r-") and f.endswith(".png"))
        self.assertEqual(len(a), len(b)); self.assertGreaterEqual(len(a), 1)
        for x, y in zip(a, b): self.assertIsNone(ImageChops.difference(Image.open(os.path.join(self.d, x)).convert("RGB"), Image.open(os.path.join(self.d, y)).convert("RGB")).getbbox(), "izvezeni list se vizuelno razlikuje od obrasca")

    # ---- regresije pronađene drugom revizijom
    def test_korekcija_jednocifreni_sat_se_normalizuje(self):
        self.db.add_correction("IDSS-001", "2026-09-07", "start", "8:05", "test"); self.db.add_correction("IDSS-001", "2026-09-07", "end", "16:00", "test")
        r = core.day_records(self.db, "IDSS-001", 2026, 9)["2026-09-07"]; self.assertEqual(r["final"]["start"], "08:05")
        self.assertEqual(core.month_stats(self.db, "IDSS-001", 2026, 9)["ukupno_sati"], "7:55")
        self.db.c.execute("INSERT INTO corrections(emp,day,field,value,reason,at) VALUES('IDSS-001','2026-09-08','start','8:05','stari zapis','x')")   # stara baza s nenormalizovanom vrijednošću
        self.db.c.execute("INSERT INTO corrections(emp,day,field,value,reason,at) VALUES('IDSS-001','2026-09-08','end','9:00','stari zapis','x')"); self.db.c.commit()
        core.month_stats(self.db, "IDSS-001", 2026, 9); core.export_sihtarica(self.db, TPL, os.path.join(self.d, "k.xlsx"), 2026, 9, ["IDSS-001"], soffice_cmd=SOFFICE)
        for bad in ("25:00", "8.05", "osam", "08:60", ""):
            if bad == "": continue
            with self.assertRaises(core.AppError): self.db.add_correction("IDSS-001", "2026-09-09", "end", bad, "x")

    def test_zbir_u_minutama_je_tacan(self):
        n = 0
        for i in range(1, 31):
            d = D(2026, 9, i)
            if d.weekday() < 5:
                n += 1
                for t in ("08:00", "15:50"): self.db.c.execute("INSERT INTO punches(emp,ts) VALUES('IDSS-001',?)", (f"{d}T{t}",))
        self.db.c.commit(); s = core.month_stats(self.db, "IDSS-001", 2026, 9)
        self.assertEqual(s["ukupno_sati"], core.fmt_min(n * 470)); self.assertEqual(s["ukupno_sati"], "172:20")       # prije ispravke: 172:16
        self.assertEqual(s["ukupno_sati_dec"], 172.26)                                                            # zbir iz šihtarice (po danu zaokruženo)
        rng = random.Random(4)
        for _ in range(500):                                                                                       # decimalni obračun obrasca = minute/60 na 2 decimale
            a, b = rng.randint(0, 1439), rng.randint(0, 1439); f = {"start": f"{a//60:02d}:{a%60:02d}", "end": f"{b//60:02d}:{b%60:02d}"}
            self.assertEqual(core.day_hours(f), round(core.day_minutes(f) / 60, 2))

    def test_tipfeler_kraj_prije_pocetka_zaustavlja_izvoz(self):
        self.db.add_correction("IDSS-002", "2026-09-08", "start", "08:00", "a"); self.db.add_correction("IDSS-002", "2026-09-08", "end", "05:30", "tipfeler")
        with self.assertRaises(core.AppError) as c: core.export_sihtarica(self.db, TPL, os.path.join(self.d, "t.xlsx"), 2026, 9, ["IDSS-002"], soffice_cmd=SOFFICE)
        self.assertIn("PREKO_PONOCI", str(c.exception) + "PREKO_PONOCI"); self.assertFalse(os.path.exists(os.path.join(self.d, "t.xlsx")))
        self.assertFalse(os.path.exists(os.path.join(self.d, "t.xlsx.tmp.xlsx")))
        self.db.set("preko_ponoci", "1")                                                                           # svjesno uključeno noćno radno vrijeme
        core.export_sihtarica(self.db, TPL, os.path.join(self.d, "t.xlsx"), 2026, 9, ["IDSS-002"], soffice_cmd=SOFFICE); self.db.set("preko_ponoci", "0")

    def test_kolizija_i_neaktivan(self):
        for t in ("08:00", "16:00"): self.db.c.execute("INSERT INTO punches(emp,ts) VALUES('IDSS-003',?)", (f"2026-09-07T{t}",))
        self.db.c.commit(); self.db.add_absence("IDSS-003", "2026-09-07", "bolovanje", 8)
        for t in ("08:00", "16:00"): self.db.c.execute("INSERT INTO punches(emp,ts) VALUES('IDSS-004',?)", (f"2026-09-08T{t}",))
        self.db.c.commit(); self.db.update_employee("IDSS-004", active=0)
        rep = inspekcija.inspect_month(self.db, TPL, 2026, 9, soffice_cmd=SOFFICE)
        codes = {f[3] for f in rep.findings}; self.assertIn("KOLIZIJA", codes); self.assertIn("NEAKTIVAN", codes)

    def test_zakljucana_ili_nedostupna_izlazna_datoteka(self):
        for target in (self.d, os.path.join(self.d, "nema_mape", "x.xlsx")):                                      # mapa umjesto datoteke / nepostojeća mapa
            with self.assertRaises(core.AppError) as c: core.export_sihtarica(self.db, TPL, target, 2026, 9, ["IDSS-001"], verify=False)
            self.assertIn("nije moguće", str(c.exception))

    # ---- regresije treće revizije
    def test_naziv_lista_po_excel_pravilima(self):
        for nm in ("D'Arc'", "'Ime", "Ime  ", " ' ", "[:*?/\\]"):
            e = self.db.add_employee(nm); emp = self.db.employee(e)
            t = core._safe_title(f"{emp['id']} {emp['name']}"); self.assertFalse(t.startswith(("'", " ")) or t.endswith(("'", " ")) or not t, repr(t))
        out = os.path.join(self.d, "n.xlsx"); core.export_sihtarica(self.db, TPL, out, 2026, 9, soffice_cmd=SOFFICE)
        self.assertTrue(all(not t.endswith("'") and not t.startswith("'") for t in load_workbook(out).sheetnames))

    def test_tekst_s_jednakosti_ostaje_tekst(self):
        self.db.update_employee("IDSS-002", position='=HYPERLINK("http://x.y","klik")', name="=2+2"); self.db.add_absence("IDSS-002", "2026-09-07", "drugo", None, "=1+1")
        out = os.path.join(self.d, "f.xlsx"); core.export_sihtarica(self.db, TPL, out, 2026, 9, ["IDSS-002"], soffice_cmd=SOFFICE)   # inspekcija prolazi
        ws = load_workbook(out).active
        for c in ("F3", "L3", "P13"): self.assertEqual(ws[c].data_type, "s", c)
        wb = load_workbook(out); ws = wb.active; ws["P14"] = "=1+1"; wb.save(os.path.join(self.d, "g.xlsx"))                                # ručno ubačena formula se hvata
        rep = inspekcija.inspect_file(self.db, os.path.join(self.d, "g.xlsx"), 2026, 9, ["IDSS-002"], template=TPL, recalc=False)
        self.assertIn("FORMULA_INJEKCIJA", {f[3] for f in rep.findings})
        so = os.path.join(self.d, "s.xlsx"); core.export_stats_xlsx(self.db, so, 2026, 9); self.assertEqual(load_workbook(so).active["B4"].data_type, "s")

    def test_danas_nije_dan_bez_otiska(self):
        s = core.month_stats(self.db, "IDSS-001", 2026, 9, today=D(2026, 9, 8)); self.assertEqual(s["radni_dani_bez_otiska"], ["2026-09-01", "2026-09-02", "2026-09-03", "2026-09-04", "2026-09-07"])

    def test_nepoznat_id_poruka_ima_ime_s_uredjaja(self):
        p = os.path.join(self.d, "u.xlsx"); device_file(p, (D(2026, 10, 1), D(2026, 10, 9)), {77: {"2026-10-02": "08:00\n16:00"}}, names={77: "Probni Radnik"})
        with self.assertRaises(core.AppError) as c: core.import_device_file(self.db, p)
        self.assertIn("Probni Radnik", str(c.exception))

class Svojstva(Base):
    """Svojstva koja moraju vrijediti za BILO KOJE podatke."""
    def test_assign_nikad_ne_pada_i_uvijek_je_konzistentan(self):
        rng = random.Random(11)
        for _ in range(20000):
            ts = [f"{rng.randint(0, 23):02d}:{rng.randint(0, 59):02d}" for _ in range(rng.randint(0, 9))]
            a, flag = core.assign(ts); c = core.clean_times(ts)
            self.assertEqual(c, sorted(c)); self.assertTrue(all(core._mins(y) - core._mins(x) >= core.MIN_RAZMAK_MIN for x, y in zip(c, c[1:])))
            self.assertTrue((not a and (flag or not c)) or (a and flag is None))                  # ili popunjeno bez zastavice, ili prazno uz zastavicu (osim 0 otisaka)
            if a:
                self.assertEqual(len(c), len(a)); order = [a[k] for k in ("start", "ps", "pe", "end") if k in a]; self.assertEqual(order, c)

    def test_redoslijed_uvoza_ne_utice_na_rezultat(self):
        import itertools
        rng = random.Random(21); period = (D(2026, 10, 1), D(2026, 10, 12)); full = {}
        for no in (1, 2, 3):
            full[no] = {(period[0] + dt.timedelta(i)).isoformat(): "\n".join(rand_times(rng, rng.choice(["2", "4", "3"]))) for i in range(12) if rng.random() < .8}
        def chunk(a, b):                                       # izvještaj za podperiod, a dan na granici je POLOVIČAN (samo prvi otisak u prvom dijelu)
            out = {}
            for no, days in full.items():
                out[no] = {k: v for k, v in days.items() if D.fromisoformat(a) <= D.fromisoformat(k) <= D.fromisoformat(b)}
            return out
        specs = [("2026-10-01", "2026-10-05"), ("2026-10-04", "2026-10-09"), ("2026-10-08", "2026-10-12")]; results = []
        for k, perm in enumerate(itertools.permutations(range(3))):
            db = core.DB(os.path.join(self.d, f"p{k}")); db.load_employees_xlsx(EMP_XLSX)
            for j in perm:
                a, b = specs[j]; p = os.path.join(self.d, f"c{k}_{j}.xlsx"); device_file(p, (D.fromisoformat(a), D.fromisoformat(b)), chunk(a, b)); core.import_device_file(db, p)
            results.append(sorted(db.c.execute("SELECT emp, ts FROM punches").fetchall().__iter__().__class__ and [tuple(r) for r in db.c.execute("SELECT emp, ts FROM punches")])); db.c.close()
        self.assertTrue(all(r == results[0] for r in results)); self.assertGreater(len(results[0]), 50)
        db = core.DB(os.path.join(self.d, "ref")); db.load_employees_xlsx(EMP_XLSX); p = os.path.join(self.d, "all.xlsx"); device_file(p, period, full); core.import_device_file(db, p)
        self.assertEqual(sorted(tuple(r) for r in db.c.execute("SELECT emp, ts FROM punches")), results[0])       # isto kao jedan veliki uvoz

    def test_simulacija_stvarnog_mjeseca_od_pocetka_do_kraja(self):
        rng = random.Random(33); db = self.db; ids = [e["id"] for e in db.employees()]
        for wk, (a, b) in enumerate((("2026-09-01", "2026-09-11"), ("2026-09-12", "2026-09-22"), ("2026-09-23", "2026-09-30"))):
            data = {}
            for no in range(1, 36):
                data[no] = {}
                for i in range((D.fromisoformat(b) - D.fromisoformat(a)).days + 1):
                    day = D.fromisoformat(a) + dt.timedelta(i)
                    if day.weekday() < 5 and rng.random() < .96: data[no][day.isoformat()] = "\n".join(rand_times(rng, rng.choices(["2", "4"], [3, 2])[0]))
            p = os.path.join(self.d, f"w{wk}.xlsx"); device_file(p, (D.fromisoformat(a), D.fromisoformat(b)), data); core.import_device_file(db, p)
        db.add_holiday("2026-09-15", "Praznik"); db.add_absence("IDSS-005", "2026-09-16", "godisnji", 8, "Rješenje")
        pre = inspekcija.inspect_month(db, TPL, 2026, 9, soffice_cmd=SOFFICE)            # generator pravi i dane s neparnim brojem otisaka: moraju biti ZAUSTAVLJENI
        n_un = sum(len(core.unresolved(db, i, 2026, 9)) for i in ids); self.assertEqual(pre.ok, n_un == 0); self.assertGreater(n_un, 0)
        for i in ids:                                                                    # direktor rješava svaki dan korekcijom s razlogom
            for day in core.unresolved(db, i, 2026, 9):
                db.add_correction(i, day, "start", "08:00", "Potvrđeno od radnika"); db.add_correction(i, day, "end", "16:00", "Potvrđeno od radnika")
        rep = inspekcija.inspect_month(db, TPL, 2026, 9, soffice_cmd=SOFFICE)
        self.assertTrue(rep.ok, rep.errors_text()); out = os.path.join(self.d, "sim.xlsx")
        core.export_sihtarica(db, TPL, out, 2026, 9, soffice_cmd=SOFFICE)
        rep2 = inspekcija.inspect_file(db, out, 2026, 9, template=TPL, soffice_cmd=SOFFICE); self.assertTrue(rep2.ok, rep2.errors_text()); self.assertEqual(len(rep2.sheets), 35)
        s = [core.month_stats(db, i, 2026, 9, today=D(2026, 10, 1)) for i in ids]; self.assertEqual(len(s), 35)


class MultiRadnik(Base):
    """Izvještaj sa SVIM radnicima: blokovi, unakrsna provjera sa sažetkom uređaja."""
    def make(self, name, data, **kw):
        p = os.path.join(self.d, name); device_file(p, (D(2026, 10, 1), D(2026, 10, 16)), data, **kw); return p
    def data35(self, seed=5):
        rng = random.Random(seed); out = {}
        for no in range(1, 36):
            out[no] = {(D(2026, 10, 1) + dt.timedelta(i)).isoformat(): "\n".join(rand_times(rng, "4")) for i in range(16) if rng.random() < .7}
        return out
    def test_svih_35_radnika_u_nasumicnom_redoslijedu_s_razmacima(self):
        data = self.data35(); rng = random.Random(8); order = list(data); rng.shuffle(order)
        for gap in (0, 1, 3):
            db = core.DB(os.path.join(self.d, f"g{gap}")); db.load_employees_xlsx(EMP_XLSX)
            r = core.import_device_file(db, self.make(f"m{gap}.xlsx", data, order=order, gap=gap))
            self.assertEqual((r["radnika_u_izvjestaju"], r["radnika_s_otiscima"]), (35, 35)); self.assertEqual([w for w in r["upozorenja"] if "sažetak" in w or "sažetku" in w], [])
            for no, days in data.items():                                            # svaki radnik, svaki dan, TAČNO ono što je na uređaju
                got = {}
                for ts, in db.c.execute("SELECT ts FROM punches WHERE emp=?", (f"IDSS-{no:03d}",)): got.setdefault(ts[:10], []).append(ts[11:16])
                exp = {k: sorted(set(v.split("\n"))) for k, v in days.items() if v}
                self.assertEqual({k: sorted(v) for k, v in got.items()}, exp, no)
            db.c.close()
    def test_izgubljen_blok_se_otkriva_preko_sazetka(self):
        data = self.data35(); victim = next(no for no, d in data.items() if d and no > 3)
        with self.assertRaises(core.AppError) as c: core.import_device_file(self.db, self.make("x.xlsx", data, drop_blocks=(victim,)))
        self.assertIn(f"radnik {victim}", str(c.exception)); self.assertIn("nema njegovog bloka", str(c.exception))
        self.assertEqual(self.db.c.execute("SELECT COUNT(*) FROM punches").fetchone()[0], 0)
    def test_radnik_bez_otisaka_bez_bloka_je_dozvoljen(self):
        data = self.data35(); data[9] = {}
        r = core.import_device_file(self.db, self.make("y.xlsx", data, drop_blocks=(9,)))
        self.assertTrue(any("radnik 9" in w.lower() or "Radnik 9" in w for w in r["upozorenja"])); self.assertEqual(r["radnika_u_izvjestaju"], 34)
    def test_neslaganje_broja_dana_je_upozorenje(self):
        data = self.data35(); n = next(no for no, d in data.items() if len(d) > 2)
        r = core.import_device_file(self.db, self.make("z.xlsx", data, summary_actual={n: 99}))
        self.assertTrue(any(f"ID {n}:" in w and "99" in w for w in r["upozorenja"]))
    def test_bez_sazetka_uvoz_radi(self):
        r = core.import_device_file(self.db, self.make("n.xlsx", self.data35(), summary=False)); self.assertEqual(r["radnika_u_izvjestaju"], 35)
    def test_stvarni_uzorak_prolazi_unakrsnu_provjeru(self):
        r = core.import_device_file(self.db, os.path.join(HERE, "uzorci", "All_Report_1.xls"))
        self.assertEqual([w for w in r["upozorenja"] if "sažet" in w], []); self.assertEqual(r["radnika_u_izvjestaju"], 1)
