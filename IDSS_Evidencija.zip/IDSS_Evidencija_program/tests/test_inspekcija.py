# -*- coding: utf-8 -*-
"""Test mutacijama: INSPEKCIJA mora uhvatiti SVAKU namjernu grešku u izvezenoj šihtarici."""
import os, sys, datetime as dt, copy, unittest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import inspekcija
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side
from openpyxl.formatting.rule import CellIsRule
from openpyxl.workbook.defined_name import DefinedName

class Mut(Base):
    @classmethod
    def setUpClass(cls): cls.cache = {}
    def setUp(self):
        super().setUp()
        for day in range(1, 31):
            d = dt.date(2026, 9, day)
            if d.weekday() < 5:
                for emp in ("IDSS-001", "IDSS-002"):
                    for t in ("08:00", "12:00", "12:30", "16:00"): self.db.c.execute("INSERT INTO punches(emp,ts) VALUES(?,?)", (emp, f"{d}T{t}"))
        self.db.c.commit(); self.db.add_absence("IDSS-002", "2026-09-03", "godisnji", 8, "Rješenje 12/26")
        self.ids = ["IDSS-001", "IDSS-002"]
        self.base = os.path.join(self.d, "base.xlsx"); core.export_sihtarica(self.db, TPL, self.base, 2026, 9, self.ids, verify=False)
    def run_mut(self, fn, recalc=False):
        wb = load_workbook(self.base); ws1, ws2 = wb[wb.sheetnames[0]], wb[wb.sheetnames[1]]
        fn(wb, ws1, ws2); p = os.path.join(self.d, "mut.xlsx"); wb.save(p)
        return inspekcija.inspect_file(self.db, p, 2026, 9, self.ids, template=TPL, recalc=recalc, soffice_cmd=SOFFICE)

    def test_nemutirana_prolazi(self):
        rep = inspekcija.inspect_file(self.db, self.base, 2026, 9, self.ids, template=TPL, recalc=SOFFICE is not None, soffice_cmd=SOFFICE)
        self.assertTrue(rep.ok, rep.to_text())

MUTACIJE = {
 "izmijenjen_tekst_oznake": lambda wb, a, b: a.__setitem__("A3", "Mjesec :"),
 "izmijenjena_formula_datuma": lambda wb, a, b: a.__setitem__("B10", "=DATE(2026,9,11)"),
 "H_ukucano_umjesto_formule": lambda wb, a, b: a.__setitem__("H12", 7.5),
 "obrisana_formula_dana": lambda wb, a, b: a.__setitem__("C7", None),
 "izmijenjena_formula_zbira": lambda wb, a, b: a.__setitem__("H38", "=SUM(H7:H36)"),
 "pogresan_mjesec": lambda wb, a, b: a.__setitem__("B3", "Oktobar"),
 "pogresna_godina": lambda wb, a, b: a.__setitem__("D3", 2025),
 "godina_kao_tekst": lambda wb, a, b: a.__setitem__("D3", "2026"),
 "pogresno_ime": lambda wb, a, b: a.__setitem__("F3", "Neko Drugi"),
 "pogresno_radno_mjesto": lambda wb, a, b: a.__setitem__("L3", "Director "),
 "pogresno_odgovorno_lice": lambda wb, a, b: a.__setitem__("F4", "Neko"),
 "vrijeme_pomaknuto_za_minutu": lambda wb, a, b: a.__setitem__("D8", dt.time(8, 1)),
 "podaci_za_31_dan_u_mjesecu_od_30": lambda wb, a, b: a.__setitem__("D37", dt.time(8, 0)),
 "sekunde_u_vremenu": lambda wb, a, b: a.__setitem__("D8", dt.time(8, 0, 30)),
 "pocetak_bez_kraja": lambda wb, a, b: a.__setitem__("E8", None),
 "pauza_bez_kraja": lambda wb, a, b: a.__setitem__("G8", None),
 "pauza_izvan_radnog_vremena": lambda wb, a, b: (a.__setitem__("F8", dt.time(17, 0)), a.__setitem__("G8", dt.time(17, 30))),
 "vrijeme_kao_tekst": lambda wb, a, b: a.__setitem__("D8", "08:00"),
 "negativni_sati": lambda wb, a, b: a.__setitem__("L9", -1),
 "sati_preko_24": lambda wb, a, b: a.__setitem__("L9", 25),
 "sati_kao_tekst": lambda wb, a, b: a.__setitem__("L9", "osam"),
 "potpis_popunjen": lambda wb, a, b: a.__setitem__("Q9", "AB"),
 "obrisan_podatak": lambda wb, a, b: a.__setitem__("D8", None),
 "tuđi_podatak_zamijenjen": lambda wb, a, b: a.__setitem__("E8", b["E8"].value.replace(hour=17)),
 "sirina_kolone": lambda wb, a, b: setattr(a.column_dimensions["P"], "width", 50),
 "visina_reda": lambda wb, a, b: setattr(a.row_dimensions[10], "height", 40),
 "format_broja": lambda wb, a, b: setattr(a["D7"], "number_format", "General"),
 "format_datuma": lambda wb, a, b: setattr(a["B7"], "number_format", "yyyy-mm-dd"),
 "font": lambda wb, a, b: setattr(a["A6"], "font", Font(name="Arial", size=11, bold=True)),
 "boja_ćelije": lambda wb, a, b: setattr(a["H9"], "fill", PatternFill("solid", fgColor="FFFF00")),
 "obruba": lambda wb, a, b: setattr(a["H9"], "border", Border(left=Side(style="thick"))),
 "razdvojene_spojene": lambda wb, a, b: a.unmerge_cells("A1:Q1"),
 "uklonjena_validacija": lambda wb, a, b: setattr(a.data_validations, "dataValidation", []),
 "zamrznuto_okno": lambda wb, a, b: setattr(a, "freeze_panes", "A7"),
 "orijentacija_stranice": lambda wb, a, b: setattr(a.page_setup, "orientation", "portrait"),
 "dodatni_list": lambda wb, a, b: wb.create_sheet("Višak"),
 "uklonjen_list": lambda wb, a, b: wb.remove(b),
 "preimenovan_list": lambda wb, a, b: setattr(b, "title", "Drugi naziv"),
 "ćelija_izvan_obrasca": lambda wb, a, b: a.__setitem__("S5", "x"),
 "sakriven_red": lambda wb, a, b: setattr(a.row_dimensions[12], "hidden", True),
 "uslovno_formatiranje": lambda wb, a, b: a.conditional_formatting.add("H7:H37", CellIsRule(operator="greaterThan", formula=["10"], fill=PatternFill("solid", bgColor="FF0000"))),
 "zaštita_lista": lambda wb, a, b: setattr(a.protection, "sheet", True),
 "sakriven_list": lambda wb, a, b: setattr(a, "sheet_state", "hidden"),
 "naslov_obrasca": lambda wb, a, b: a.__setitem__("A1", "IDSS | EVIDENCIJA"),
 "napomena_obrasca_izmijenjena": lambda wb, a, b: a.__setitem__("A42", "Napomena: nešto drugo."),
 "kolona_sati_prazna_formula": lambda wb, a, b: a.__setitem__("H7", ""),
 "ime_u_pogresnom_polju": lambda wb, a, b: (a.__setitem__("F3", None), a.__setitem__("G3", b["F3"].value)),
 "mjesec_malim_slovima": lambda wb, a, b: a.__setitem__("B3", "septembar"),
}
for _n, _f in MUTACIJE.items():
    setattr(Mut, "test_mutacija_" + _n, (lambda f: lambda self: self._check(f))(_f))
def _check(self, f):
    rep = self.run_mut(f)
    self.assertFalse(rep.ok, "INSPEKCIJA NIJE UHVATILA mutaciju!\n" + rep.to_text()[:600])
Mut._check = _check

class MutFormule(Mut):
    """Mutacije koje se vide tek preračunom formula (zahtijeva LibreOffice)."""
    @unittest.skipUnless(SOFFICE, "nema LibreOffice-a")
    def test_preracun_hvata_pogresnu_cached_vrijednost_ne_treba(self):
        rep = self.run_mut(lambda wb, a, b: None, recalc=True); self.assertTrue(rep.ok, rep.to_text())
    @unittest.skipUnless(SOFFICE, "nema LibreOffice-a")
    def test_zbir_se_preracunava(self):
        rep = self.run_mut(lambda wb, a, b: a.__setitem__("D9", dt.time(7, 0)), recalc=True)
        self.assertFalse(rep.ok)   # podatak ne odgovara bazi
for n in list(vars(MutFormule)):
    if n.startswith("test_mutacija_"): setattr(MutFormule, n, None)

if __name__ == "__main__": unittest.main(verbosity=1)
