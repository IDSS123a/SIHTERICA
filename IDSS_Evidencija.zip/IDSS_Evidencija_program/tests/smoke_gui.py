# Dimni test sučelja bez ekrana (tkinter je zamijenjen lažnim modulom): izvodi izgradnju svih stranica, osvježavanja,
# crtanje svih grafikona nad stvarnim podacima, INSPEKCIJU i izvoz. Ne zamjenjuje probu na stvarnom ekranu.
import sys, types, os, tempfile
class Any:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n): return lambda *a, **k: Any()
    def __iter__(self): return iter(())
    def __setitem__(self, k, v): pass
    def __getitem__(self, k): return None
    def get(self, *a): return ""
    def winfo_width(self): return 900
    def winfo_height(self): return 320
    def bbox(self, *a): return (0, 0, 10, 10)
class Var:
    def __init__(self, value=""): self.v = value
    def get(self): return self.v
    def set(self, v): self.v = v
_cache = {}
def mod(name):
    m = types.ModuleType(name)
    def ga(attr):
        if attr.startswith("__"): raise AttributeError(attr)
        if attr == "StringVar": return Var
        if attr == "families": return lambda *a: ["Segoe UI", "Arial"]
        if attr == "TclError": return Exception
        return _cache.setdefault((name, attr), type(attr, (Any,), {}))
    m.__getattr__ = ga; return m
tk = mod("tkinter"); ttk = mod("tkinter.ttk"); fd = mod("tkinter.filedialog"); fnt = mod("tkinter.font")
tk.ttk, tk.filedialog, tk.font = ttk, fd, fnt
for name, m in (("tkinter", tk), ("tkinter.ttk", ttk), ("tkinter.filedialog", fd), ("tkinter.font", fnt)): sys.modules[name] = m
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, ".."))
import core; core.find_soffice = lambda: None          # bez LibreOffice-a (sporo u ovom testu)
import gui, widgets
shown = []
gui.message = lambda parent, fonts, kind, title, text, ask=False: (shown.append((kind, title, text)), True)[1]
gui.ask_text = lambda *a, **k: "Tajna-sifra-2026"
gui.DEFAULT_BASE = tempfile.mkdtemp()
app = gui.App(); assert app.ok, "prijava nije uspjela"
assert len(app.db.employees()) == 35
core.import_device_file(app.db, os.path.join(HERE, "uzorci", "All_Report_1.xlsx"))
app.mv.set("Oktobar"); app.yv.set("2026")
for p in gui.PAGES: app.show(p)
app.cb_emp.get = lambda: "IDSS-001  Davor Mulalić"; app.refresh_view()
app.run_insp_month(); assert app.last_rep is not None
app.check_sih(); app.refresh_stats(); app.device_make()
# uvoz liste novih radnika kroz sučelje (dijalozi zamijenjeni odgovorima)
import roster
tp = os.path.join(tempfile.mkdtemp(), "lista.xlsx"); roster.make_template(tp)
from openpyxl import load_workbook
wb = load_workbook(tp); wb["Zaposlenici"].append(["Smoke Novi Jedan", "Teacher", "s1@idss.ba", "061/1"]); wb["Zaposlenici"].append(["Smoke Novi Dva", "German", "", ""]); wb.save(tp)
gui.filedialog.askopenfilename = lambda **k: tp; gui.filedialog.asksaveasfilename = lambda **k: tp + ".sablon.xlsx"
seen_dialog = []; app.roster_dialog = lambda items: (seen_dialog.append(roster.summarize(items)), (set(), False))[1]
gui.choice = lambda *a, **k: 0
n0 = len(app.db.employees(False)); app.roster_import(); assert len(app.db.employees(False)) == n0 + 2, "uvoz liste nije dodao radnike"
assert seen_dialog and seen_dialog[0].get("NOVI") == 2
app.roster_template(); app.show("Uređaj"); app.device_make(only_ids=set(filter(None, app.db.get("zadnje_dodani").split(","))))
errs = [s for s in shown if s[0] == "error"]
assert not errs, errs
# svi grafikoni su stvarno nacrtani nad podacima
for cv in app.ch + [app.ch_view, app.ch_range]: assert cv.scene is not None and cv.scene.items, "grafikon prazan"
print("DIMNI TEST SUCELJA: OK (", len(gui.PAGES), "stranica,", len(app.ch) + 2, "grafikona, inspekcija, izvoz obrasca )")
