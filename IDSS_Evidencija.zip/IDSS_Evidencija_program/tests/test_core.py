# -*- coding: utf-8 -*-
import os, sys, tempfile, shutil, datetime as dt, unittest, subprocess
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import core
from openpyxl import Workbook, load_workbook
HERE = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.join(HERE, "..", "sablon", "Sihtarica_IDSS.xlsx")
DEV_TPL = os.path.join(HERE, "..", "sablon", "Employee_Form_sablon.xlsx")
EMP_XLSX = os.path.join(HERE, "..", "podaci_za_pocetak", "IDSS_Zaposlenici_prijedlog.xlsx")
REAL = os.path.join(HERE, "uzorci", "All_Report_1.xlsx")         # STVARNI izvoz s uređaja (pretvoren u xlsx)
REAL_XLS = os.path.join(HERE, "uzorci", "All_Report_1.xls")      # isti stvarni izvoz u izvornom .xls
WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

def device_file(path, period, data, names=None):
    """Pravi datoteku u STVARNOM rasporedu uređaja (Attendance Logs: blok po radniku). data = {device_no: {'YYYY-MM-DD': 'hh:mm\\nhh:mm'}}"""
    a, b = period; n = (b - a).days + 1
    wb = Workbook(); ws = wb.active; ws.title = "Attendance Logs"
    ws.append(["Attendance Logs"]); ws.append(["Date", None, f"{a:%d/%m/%Y} ~ {b:%d/%m/%Y}"])
    for no, days in data.items():
        head = [None] * 21; head[0] = "ID"; head[2] = no; head[9] = "Name"; head[11] = (names or {}).get(no, "x"); head[18] = "Dept."; head[20] = "Not Set4"
        ws.append(head)
        ws.append([(a + dt.timedelta(i)).day for i in range(n)])
        ws.append([WD[(a + dt.timedelta(i)).weekday()] for i in range(n)])
        ws.append([days.get((a + dt.timedelta(i)).isoformat()) for i in range(n)])
    wb.save(path)

D = dt.date
class Base(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp(); self.db = core.DB(self.d)
        self.assertEqual(self.db.load_employees_xlsx(EMP_XLSX), 35)
    def tearDown(self): shutil.rmtree(self.d)
    def imp(self, data, period=(D(2026, 10, 1), D(2026, 10, 9)), name="f.xlsx", names=None):
        p = os.path.join(self.d, name); device_file(p, period, data, names); return core.import_device_file(self.db, p)

class Real(Base):
    def test_stvarna_datoteka_uredjaja(self):
        r = core.import_device_file(self.db, REAL)
        self.assertEqual(r["novih"], 5)
        self.assertTrue(any("fffd" in w for w in r["upozorenja"]))            # ime na uređaju != ime u aplikaciji
        rec = core.day_records(self.db, "IDSS-001", 2026, 10)
        self.assertEqual(rec["2026-10-14"]["times"], ["11:16", "11:58", "14:14"])
        self.assertFalse(rec["2026-10-14"]["resolved"])                       # tri otiska = anomalija
        self.assertEqual(rec["2026-10-16"]["times"], ["17:27", "17:30"])      # razmak 3 min nije duplikat (kao na uređaju)
        self.assertEqual(rec["2026-10-16"]["final"], {"start": "17:27", "end": "17:30"})
        self.assertEqual(core.import_device_file(self.db, REAL)["novih"], 0)  # ista datoteka
    def test_stvarna_xls_datoteka(self):
        self.assertEqual(core.import_device_file(self.db, REAL_XLS)["novih"], 5)

class T(Base):
    def test_formula_i_pretvorbe(self):
        t = core.parse_time
        self.assertEqual(core.sat_formula(t("08:00"), t("16:30"), t("12:00"), t("12:30")), 8.0)
        self.assertEqual(core.sat_formula(t("07:45"), t("14:10"), None, None), 6.42)
        self.assertEqual(core.sat_formula(t("22:00"), t("06:00"), None, None), 8.0)
        self.assertEqual(core.dec_to_hhmm(6.42), "6:25"); self.assertEqual(core.hhmm_to_dec("6:25"), 6.42)
        self.assertEqual(core.translit("Feđa Čaušević Šemsija Žuža"), "Fedja Causevic Semsija Zuza")

    def test_pravila_otisaka(self):
        self.assertEqual(core.assign(["08:00", "08:02", "15:00"])[0], {"start": "08:00", "end": "15:00"})   # 2 min < 3 = duplikat
        self.assertEqual(core.assign(["08:00", "12:00", "12:30", "16:00"])[0]["pe"], "12:30")
        for bad in (["08:00"], ["08:00", "12:00", "16:00"], ["08:00", "09:00", "10:00", "11:00", "12:00"]):
            a, flag = core.assign(bad); self.assertEqual(a, {}); self.assertTrue(flag)

    def test_uvoz_vise_radnika_i_ponovni_uvoz(self):
        r = self.imp({1: {"2026-10-01": "08:00\n16:00", "2026-10-04": "07:50\n12:00\n12:30\n15:50"}, 2: {"2026-10-02": "09:00\n15:00"}})
        self.assertEqual(r["novih"], 8)
        self.assertEqual(self.imp({1: {"2026-10-01": "08:00\n16:00", "2026-10-04": "07:50\n12:00\n12:30\n15:50"}, 2: {"2026-10-02": "09:00\n15:00"}})["novih"], 0)
        rec = core.day_records(self.db, "IDSS-001", 2026, 10)
        self.assertEqual(core.day_hours(rec["2026-10-04"]["final"]), 7.5)

    def test_period_preko_granice_mjeseca(self):
        self.imp({1: {"2026-09-30": "08:00\n16:00", "2026-10-01": "09:00\n17:00"}}, period=(D(2026, 9, 28), D(2026, 10, 3)))
        self.assertEqual(core.day_records(self.db, "IDSS-001", 2026, 9)["2026-09-30"]["final"]["end"], "16:00")
        self.assertEqual(core.day_records(self.db, "IDSS-001", 2026, 10)["2026-10-01"]["final"]["start"], "09:00")

    def test_preklapanje_perioda_bez_duplikata(self):
        self.imp({1: {"2026-10-02": "08:00\n16:00"}}, name="a.xlsx")
        r = self.imp({1: {"2026-10-02": "08:00\n17:00"}}, period=(D(2026, 10, 2), D(2026, 10, 8)), name="b.xlsx")
        self.assertEqual((r["novih"], r["duplikata"]), (1, 1))

    def test_uvoz_prekida_na_nejasnoci(self):
        for bad, msg in (({1: {"2026-10-02": "08:00"}, 99: {"2026-10-02": "09:00"}}, "nepoznat ID"),
                         ({1: {"2026-10-02": "osam sati"}}, "ne razumijem")):
            with self.assertRaises(core.AppError) as c: self.imp(bad, name="x%d.xlsx" % len(msg))
            self.assertIn(msg, str(c.exception))
            self.assertEqual(self.db.c.execute("SELECT COUNT(*) FROM punches").fetchone()[0], 0)

    def test_pomaknut_period_se_odbija(self):
        p = os.path.join(self.d, "m.xlsx"); device_file(p, (D(2026, 10, 1), D(2026, 10, 5)), {1: {"2026-10-02": "08:00\n16:00"}})
        wb = load_workbook(p); ws = wb.active; ws["C2"] = "02/10/2026 ~ 06/10/2026"; wb.save(p)   # datumi u zaglavlju ne odgovaraju kolonama
        with self.assertRaises(core.AppError) as c: core.import_device_file(self.db, p)
        self.assertIn("ne poklapa", str(c.exception))

    def test_prazan_izvjestaj_se_odbija(self):
        with self.assertRaises(core.AppError): self.imp({1: {}})

    def test_anomalija_blokira_izvoz_dok_se_ne_rijesi(self):
        self.imp({1: {"2026-10-05": "08:00", "2026-10-06": "08:00\n16:00"}})
        out = os.path.join(self.d, "x.xlsx")
        with self.assertRaises(core.AppError): core.export_sihtarica(self.db, TPL, out, 2026, 10, ["IDSS-001"])
        with self.assertRaises(core.AppError): self.db.add_correction("IDSS-001", "2026-10-05", "end", "15:30", "  ")
        for f, v in (("start", "08:00"), ("end", "15:30")): self.db.add_correction("IDSS-001", "2026-10-05", f, v, "Radnik zaboravio otisnuti; potvrđeno")
        core.export_sihtarica(self.db, TPL, out, 2026, 10, ["IDSS-001"])

    def test_izvoz_sihtarice_format_i_vrijednosti(self):
        self.imp({1: {"2026-10-01": "08:00\n12:00\n12:30\n16:00"}, 2: {"2026-10-02": "07:45\n14:10"}})
        self.db.add_absence("IDSS-002", "2026-10-05", "godisnji", 8, "Rješenje direktora")
        self.db.update_employee("IDSS-001", weekly_hours=40)
        out = os.path.join(self.d, "sih.xlsx"); core.export_sihtarica(self.db, TPL, out, 2026, 10)
        wb = load_workbook(out); self.assertEqual(len(wb.sheetnames), 35); self.assertEqual(wb.sheetnames[0], "IDSS-001 Davor Mulalić")
        ws = wb["IDSS-002 Adnana Agić"]; tpl = load_workbook(TPL)[core.SHEET_TEMPLATE]
        self.assertEqual((ws["B3"].value, ws["D3"].value), ("Oktobar", 2026)); self.assertEqual(ws["D8"].value, dt.time(7, 45)); self.assertEqual(ws["L11"].value, 8)
        self.assertEqual(sorted(map(str, ws.merged_cells.ranges)), sorted(map(str, tpl.merged_cells.ranges)))
        for c in "ABHIPQ": self.assertEqual(ws.column_dimensions[c].width, tpl.column_dimensions[c].width)
        for row in ws.iter_rows(min_row=1, max_row=6):
            for c in row:
                if c.coordinate not in ("B3", "D3", "F3", "F4", "L3"): self.assertEqual(c.value, tpl[c.coordinate].value, c.coordinate)
        for r in range(7, 39):
            for col in "ABCH": self.assertEqual(ws[f"{col}{r}"].value, tpl[f"{col}{r}"].value)
        self.assertEqual(len(ws.data_validations.dataValidation), 2)
        self.assertEqual(ws.freeze_panes, "D7"); self.assertEqual(ws.print_title_rows, tpl.print_title_rows)

    def test_statistika(self):
        self.imp({1: {"2026-10-01": "08:00\n16:00", "2026-10-02": "08:30\n15:30"}}); self.db.update_employee("IDSS-001", weekly_hours=40)
        s = core.month_stats(self.db, "IDSS-001", 2026, 10, today=dt.date(2026, 10, 9))
        self.assertEqual((s["ukupno_sati"], s["prosječan_dolazak"], s["broj_dana_bez_otiska"], s["razlika_prema_ugovorenom"]), ("15:00", "08:15", 4, "-1:00"))

    def test_statistika_izvoz(self):
        self.imp({1: {"2026-10-01": "08:00\n16:00"}})
        out = os.path.join(self.d, "st.xlsx"); core.export_stats_xlsx(self.db, out, 2026, 10)
        ws = load_workbook(out).active; self.assertEqual((ws.max_row, ws["E3"].value), (2 + 35, "8:00"))

    def test_sifra(self):
        with self.assertRaises(core.AppError): self.db.set_password("kratko")
        self.db.set_password("Tajna-sifra-2026"); self.assertTrue(self.db.check_password("Tajna-sifra-2026"))
        self.assertFalse(self.db.check_password("pogresna")); self.assertTrue(self.db.check_password("Tajna-sifra-2026"))

    def test_razmak_duplikata_je_podesiv(self):
        self.db.set("min_razmak", "5"); self.assertEqual(core.assign(["08:00", "08:04", "15:00"])[0], {"start": "08:00", "end": "15:00"})
        self.db.set("min_razmak", "3")

class Device(Base):
    def test_obrazac_za_uredjaj(self):
        out = os.path.join(self.d, "Employee_Form.xlsx"); core.fill_device_form(self.db, DEV_TPL, out)
        wb = load_workbook(out); ws = wb["Employee Form"]
        self.assertEqual([c.value for c in ws[9]][:4], [1, "Davor Mulalic", 1, 1])              # ID 1 = direktor, administrator
        self.assertEqual([c.value for c in ws[43]][:4], [35, "Victoria Krajina", 3, 0])
        self.assertIsNone(ws["A44"].value)
        self.assertEqual(ws["E7"].value, "=DAY(E6+0)"); self.assertEqual(ws["E6"].value, "2026-10-16")   # ostalo netaknuto
        orig = load_workbook(DEV_TPL)
        for sh in orig.sheetnames:
            for row in orig[sh].iter_rows():
                for c in row:
                    if sh == "Employee Form" and c.row >= 9 and c.column <= 4: continue
                    if sh == "Attendance Rules Form" and c.column == 9 and 5 <= c.row <= 10: continue
                    self.assertEqual(wb[sh][c.coordinate].value, c.value, (sh, c.coordinate))
        self.assertEqual(wb["Attendance Rules Form"]["I5"].value, "Uprava")
        self.assertTrue(ws.protection.sheet)
        ids = [ws.cell(r, 1).value for r in range(9, 44)]; self.assertEqual(ids, list(range(1, 36)))
        self.assertTrue(all(len(ws.cell(r, 2).value) <= 32 and ws.cell(r, 2).value.isascii() for r in range(9, 44)))

    def test_validacija_obrasca(self):
        with self.assertRaises(core.AppError): core.validate_device_rows([(1, "Ime", 17, 0)])
        with self.assertRaises(core.AppError): core.validate_device_rows([(1, "Ime", 1, 0), (1, "Drugi", 1, 0)])
        with self.assertRaises(core.AppError): core.validate_device_rows([(1, "Čudno", 1, 0)])

if __name__ == "__main__": unittest.main(verbosity=2)

class XlsReader(Base):
    def test_ugradeni_citac_i_provjera_dva_citaca(self):
        import types, xlsparse
        r = core.import_device_file(self.db, REAL_XLS); self.assertEqual(r["novih"], 5)            # samo ugrađeni čitač
        self.db.c.execute("DELETE FROM punches"); self.db.c.execute("DELETE FROM sources"); self.db.c.commit()
        data = xlsparse.read_xls(REAL_XLS)
        def fake(tamper):
            m = types.ModuleType("xlrd"); m.XL_CELL_DATE, m.XL_CELL_EMPTY, m.XL_CELL_BLANK, m.XL_CELL_TEXT = 3, 0, 6, 1
            class Cell:
                def __init__(s, v): s.value = "" if v is None else v; s.ctype = 0 if v is None else 1
            class Sheet:
                def __init__(s, n, rows): s.name, s.rows = n, rows; s.nrows = len(rows); s.ncols = max(len(r) for r in rows) if rows else 0
                def cell(s, r, c):
                    row = s.rows[r]; v = row[c] if c < len(row) else None
                    if tamper and s.name == "Attendance Logs" and r == 5 and c == 13 and v: v = v.replace("11:16", "11:17")
                    return Cell(v)
            class Book:
                datemode = 0
                def sheets(s): return [Sheet(n, rows) for n, rows in data.items()]
            m.open_workbook = lambda p: Book(); return m
        sys.modules["xlrd"] = fake(False)
        try:
            self.assertEqual(core.import_device_file(self.db, REAL_XLS)["novih"], 5)                 # oba čitača se slažu
            self.db.c.execute("DELETE FROM punches"); self.db.c.execute("DELETE FROM sources"); self.db.c.commit()
            sys.modules["xlrd"] = fake(True)
            with self.assertRaises(core.AppError) as c: core.import_device_file(self.db, REAL_XLS)
            self.assertIn("različit sadržaj", str(c.exception)); self.assertEqual(self.db.c.execute("SELECT COUNT(*) FROM punches").fetchone()[0], 0)
        finally: del sys.modules["xlrd"]
