# -*- coding: utf-8 -*-
"""Uvoz liste novih radnika: stari podaci ostaju ZAŠTIĆENI, ID-evi se nikad ne ponavljaju, ništa se ne gubi."""
import os, sys, csv, hashlib, sqlite3, random, datetime as dt, unittest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import roster
from openpyxl import Workbook, load_workbook

D = dt.date
TABLES = ("employees", "punches", "corrections", "absences", "holidays", "sources")
def snapshot(db):
    """Otisak SVIH podataka o postojećim radnicima (za dokaz da ništa nije promijenjeno)."""
    h = hashlib.sha256()
    for t in TABLES: h.update(repr([tuple(r) for r in db.c.execute(f"SELECT * FROM {t} ORDER BY 1")]).encode())
    return h.hexdigest()

def make_xlsx(path, rows, header=("ID radnika", "Ime i prezime", "Radno mjesto", "Poslovni e-mail", "Telefon")):
    wb = Workbook(); ws = wb.active; ws.title = "Zaposlenici"; ws.append(list(header))
    for r in rows: ws.append(list(r))
    wb.save(path)

class R(Base):
    def setUp(self):
        super().setUp()
        for e in ("IDSS-001", "IDSS-002", "IDSS-005"):                                   # postojeći podaci koji moraju preživjeti
            for t in ("08:00", "12:00", "12:30", "16:00"): self.db.c.execute("INSERT INTO punches(emp,ts) VALUES(?,?)", (e, f"2026-09-07T{t}"))
        self.db.c.commit(); self.db.add_correction("IDSS-002", "2026-09-08", "start", "08:00", "razlog"); self.db.add_absence("IDSS-005", "2026-09-09", "godisnji", 8, "rj"); self.db.add_holiday("2026-09-15", "Praznik")
    def run_roster(self, path, accept=(), update=False):
        items = roster.plan_roster(self.db, roster.read_roster(path)); return items, roster.apply_roster(self.db, items, accept, update, path)

    def test_pet_novih_radnika_dobivaju_nove_ID_a_stari_ostaju_nepromijenjeni(self):
        before = snapshot(self.db); old_ids = {e["id"]: e["device_no"] for e in self.db.employees(False)}; orig = [tuple(r) for r in self.db.c.execute("SELECT * FROM employees ORDER BY id")]
        p = os.path.join(self.d, "nova.xlsx"); make_xlsx(p, [(None, f"Novi Radnik{n}", "Teacher", f"n{n}@idss.ba", "062/1") for n in "ABCDE"])
        items = roster.plan_roster(self.db, roster.read_roster(p)); self.assertEqual([i["status"] for i in items], [roster.NOVI] * 5)
        self.assertEqual(snapshot(self.db), before)                                       # pregled NE mijenja bazu
        rep = roster.apply_roster(self.db, items, source=p)
        self.assertEqual([e for e, _ in rep["dodani"]], ["IDSS-036", "IDSS-037", "IDSS-038", "IDSS-039", "IDSS-040"]); self.assertTrue(os.path.exists(rep["backup"]))
        for eid, no in old_ids.items(): self.assertEqual(self.db.employee(eid)["device_no"], no)
        self.assertEqual(len({e["device_no"] for e in self.db.employees(False)}), 40)
        new_snap = {t: [tuple(r) for r in self.db.c.execute(f"SELECT * FROM {t} ORDER BY 1")] for t in TABLES if t != "employees"}
        self.assertEqual(len(new_snap["punches"]), 12); self.assertEqual(len(new_snap["corrections"]), 1); self.assertEqual(len(new_snap["absences"]), 1)
        self.assertEqual([tuple(r) for r in self.db.c.execute("SELECT * FROM employees WHERE device_no<=35 ORDER BY id")], orig)       # svaki stari radnik, svako polje, bajt po bajt

    def test_lista_sa_svih_35_starih_i_5_novih_dodaje_samo_nove(self):
        before = [tuple(r) for r in self.db.c.execute("SELECT * FROM employees ORDER BY id")]
        rows = [(e["id"], e["name"], e["position"], e["email"], e["phone"]) for e in self.db.employees()] + [(None, f"Nova Osoba{n}", "German", "", "") for n in range(5)]
        p = os.path.join(self.d, "puna.xlsx"); make_xlsx(p, rows)
        items, rep = self.run_roster(p)
        self.assertEqual(len(rep["dodani"]), 5); self.assertEqual(rep["preskoceno"], 35)
        self.assertEqual([tuple(r) for r in self.db.c.execute("SELECT * FROM employees WHERE device_no<=35 ORDER BY id")], before)
        _, rep2 = None, None
        with self.assertRaises(core.AppError): self.run_roster(p)                         # ponovni uvoz iste liste: nema ničega za primjenu, ništa se ne duplira
        self.assertEqual(len(self.db.employees(False)), 40)

    def test_lista_bez_starih_radnika_ih_ne_dira_niti_deaktivira(self):
        before = snapshot(self.db); p = os.path.join(self.d, "samo5.xlsx"); make_xlsx(p, [(None, "Samo Jedan", "Teacher", "", "")])
        self.run_roster(p); self.assertEqual(len(self.db.employees()), 36)                # svih 35 ostaje aktivno

    def test_ID_postojeceg_radnika_se_nikad_ne_dodjeljuje_novom(self):
        p = os.path.join(self.d, "k.xlsx"); make_xlsx(p, [("IDSS-010", "Nova Osoba", "Teacher", "", ""), ("IDSS-003", "Medina Karaga", "Psihology", "", ""), (None, "Druga Nova", "Teacher", "", "")])
        items = roster.plan_roster(self.db, roster.read_roster(p))
        self.assertEqual(items[0]["status"], roster.GRESKA); self.assertIn("već pripada", items[0]["note"]); self.assertIn("Maja Bajraktarević", items[0]["note"])
        self.assertEqual(items[1]["status"], roster.POSTOJI); self.assertEqual(items[2]["status"], roster.NOVI)
        rep = roster.apply_roster(self.db, items); self.assertEqual(rep["dodani"], [("IDSS-036", "Druga Nova")]); self.assertEqual(self.db.employee("IDSS-010")["name"], "Maja Bajraktarević")

    def test_ID_iz_liste_za_novu_osobu_ako_je_slobodan(self):
        p = os.path.join(self.d, "s.xlsx"); make_xlsx(p, [("IDSS-050", "Nova S Brojem", "Teacher", "", "")]); items, rep = self.run_roster(p)
        self.assertEqual(rep["dodani"], [("IDSS-050", "Nova S Brojem")]); self.assertEqual(self.db.next_device_no(), 51)

    def test_ime_u_drugom_zapisu_je_isti_radnik_a_slicno_je_PROVJERA(self):
        p = os.path.join(self.d, "d.xlsx"); make_xlsx(p, [(None, "davor  mulalic", "", "", ""), (None, "Mulalić Davor", "", "", ""), (None, "Melisa Babicc", "", "", ""), (None, "Potpuno Novo Ime", "", "", "")])
        items = roster.plan_roster(self.db, roster.read_roster(p))
        self.assertEqual([i["status"] for i in items], [roster.POSTOJI, roster.PROVJERA, roster.PROVJERA, roster.NOVI]); self.assertEqual(items[0]["id"], "IDSS-001")   # promijenjen redoslijed riječi = sumnja, ne novi radnik
        rep = roster.apply_roster(self.db, items); self.assertEqual(len(rep["dodani"]), 1)                       # sumnjivi NIJE dodan sam od sebe
        rep = roster.apply_roster(self.db, items[2:3], accept={items[2]["row"]}); self.assertEqual(len(rep["dodani"]), 1)   # dodan tek nakon odobrenja

    def test_deaktiviran_radnik_zadrzava_isti_ID(self):
        self.db.update_employee("IDSS-007", active=0); name = self.db.employee("IDSS-007")["name"]
        p = os.path.join(self.d, "r.xlsx"); make_xlsx(p, [(None, name, "", "", "")]); items = roster.plan_roster(self.db, roster.read_roster(p))
        self.assertEqual((items[0]["status"], items[0]["id"]), (roster.REAKT, "IDSS-007"))
        with self.assertRaises(core.AppError): roster.apply_roster(self.db, items)                              # bez odobrenja nema promjene
        self.assertEqual(self.db.employee("IDSS-007")["active"], 0)
        roster.apply_roster(self.db, items, accept={items[0]["row"]}); self.assertEqual(self.db.employee("IDSS-007")["active"], 1); self.assertEqual(len(self.db.employees(False)), 35)

    def test_ID_deaktiviranog_i_ID_sa_uredjaja_se_ne_ponavljaju(self):
        self.db.update_employee("IDSS-035", active=0)                                                            # najveći ID je deaktiviran: i dalje je zauzet
        p = os.path.join(self.d, "n1.xlsx"); make_xlsx(p, [(None, "Prva Nova", "", "", "")]); _, rep = self.run_roster(p); self.assertEqual(rep["dodani"][0][0], "IDSS-036")
        dev = os.path.join(self.d, "dev.xlsx"); device_file(dev, (D(2026, 10, 1), D(2026, 10, 9)), {1: {"2026-10-02": "08:00\n16:00"}, 77: {"2026-10-02": "09:00\n15:00"}}, names={77: "Probni"})
        with self.assertRaises(core.AppError): core.import_device_file(self.db, dev)                             # 77 nije u aplikaciji: uvoz staje...
        self.assertEqual(self.db.next_device_no(), 78)                                                           # ...ali je ID 77 od sada REZERVISAN
        p = os.path.join(self.d, "n2.xlsx"); make_xlsx(p, [("77", "Ručni Sedamdeset Sedam", "", "", "")]); items = roster.plan_roster(self.db, roster.read_roster(p))
        self.assertEqual(items[0]["status"], roster.GRESKA); self.assertIn("Probni", items[0]["note"])

    def test_nevaljani_redovi_su_greske_a_ostali_prolaze(self):
        rows = [(None, "", "x", "", ""), (None, "Ime Koje Je Predugo Za Uredjaj Jer Ima Previse Znakova", "", "", ""), (None, "Dobar Radnik", "", "loš-email", ""),
                (None, "Ponovljeno Ime", "", "", ""), (None, "ponovljeno ime", "", "", ""), ("IDSSxx", "Lose ID", "", "", ""), (None, "Čista Osoba", "Teacher", "c@idss.ba", "")]
        items = roster.plan_roster(self.db, roster.read_roster(os.path.join(self.d, "x.xlsx")) if False else [dict(zip(("id", "name", "position", "email", "phone"), r), row=i + 2) for i, r in enumerate(rows)])
        self.assertEqual([i["status"] for i in items], [roster.GRESKA, roster.GRESKA, roster.GRESKA, roster.NOVI, roster.GRESKA, roster.GRESKA, roster.NOVI])

    def test_kontakt_podaci_postojecih_se_mijenjaju_samo_na_zahtjev(self):
        e = self.db.employee("IDSS-004"); p = os.path.join(self.d, "u.xlsx"); make_xlsx(p, [(None, e["name"], "Novo mjesto", "novi@idss.ba", "061/999")])
        items = roster.plan_roster(self.db, roster.read_roster(p)); self.assertEqual(set(items[0]["diffs"]), {"position", "email", "phone"})
        with self.assertRaises(core.AppError): roster.apply_roster(self.db, items)                                # bez zahtjeva nema promjene
        self.assertEqual(self.db.employee("IDSS-004")["email"], e["email"])
        roster.apply_roster(self.db, items, update_contacts=True); n = self.db.employee("IDSS-004")
        self.assertEqual((n["name"], n["device_no"], n["email"]), (e["name"], e["device_no"], "novi@idss.ba"))   # ime i ID nikad
        self.assertTrue(self.db.c.execute("SELECT 1 FROM audit WHERE action='radnik_kontakt_azuriran'").fetchone())

    def test_primjena_je_atomarna_pad_usred_ne_ostavlja_nista(self):
        p = os.path.join(self.d, "a.xlsx"); make_xlsx(p, [(None, f"Atom Radnik{c}", "", "", "") for c in "ABCDE"]); items = roster.plan_roster(self.db, roster.read_roster(p)); before = snapshot(self.db)
        orig = self.db._insert_employee; calls = {"n": 0}
        def bomb(*a, **k):
            calls["n"] += 1
            if calls["n"] == 3: raise RuntimeError("pad usred primjene")
            return orig(*a, **k)
        self.db._insert_employee = bomb
        with self.assertRaises(RuntimeError): roster.apply_roster(self.db, items)
        self.db._insert_employee = orig; self.assertEqual(snapshot(self.db), before); self.assertEqual(len(self.db.employees(False)), 35)
        self.assertEqual(len(roster.apply_roster(self.db, items)["dodani"]), 5)                                   # poslije pada radi normalno

    def test_baza_ne_dozvoljava_brisanje_ni_promjenu_ID_a(self):
        for sql in ("DELETE FROM employees WHERE id='IDSS-001'", "UPDATE employees SET device_no=999 WHERE id='IDSS-002'", "UPDATE employees SET id='IDSS-999' WHERE id='IDSS-002'"):
            with self.assertRaises(sqlite3.DatabaseError): self.db.c.execute(sql)
        self.db.c.rollback(); self.db.update_employee("IDSS-002", name="Adnana Agić-Test"); self.assertEqual(self.db.employee("IDSS-002")["device_no"], 2)   # ostale izmjene rade
        with self.assertRaises(core.AppError): self.db.add_employee("Adnana Agic-Test")                            # duplikat imena ručno
        with self.assertRaises(core.AppError): self.db._insert_employee("Neko", "", "", "", None, 5, None, None)         # zauzet broj

    def test_formati_csv_xlsx_xls_i_stari_kontakt_list(self):
        pc = os.path.join(self.d, "l.csv"); open(pc, "w", encoding="utf-8-sig", newline="").write("Name;Birthday;Phone;E-mail business;E-mail private;Position\nPetar Petrović;01.01.1990;061/1;petar@idss.ba;privatni@gmail.com;English\n")
        r = roster.read_roster(pc); self.assertEqual((r[0]["name"], r[0]["email"], r[0]["position"], r[0]["phone"]), ("Petar Petrović", "petar@idss.ba", "English", "061/1"))
        self.assertNotIn("birthday", " ".join(r[0])); self.assertNotIn("privatni@gmail.com", repr(r))                   # datum rođenja i privatni e-mail se ne uvoze
        px = os.path.join(self.d, "l.xlsx"); make_xlsx(px, [("", "Ana Anić", "Music", "ana@idss.ba", "062/2")], header=("ID", "Name", "Position", "E-mail business", "Phone")); self.assertEqual(roster.read_roster(px)[0]["name"], "Ana Anić")
        pt = os.path.join(self.d, "t.xlsx"); roster.make_template(pt); wb = load_workbook(pt); wb["Zaposlenici"].append(["Iz Predloška", "Teacher", "ip@idss.ba", "061/3", "40", "2", "0", ""]); wb.save(pt)
        it = roster.plan_roster(self.db, roster.read_roster(pt)); self.assertEqual((it[0]["status"], it[0]["weekly"], it[0]["dept"]), (roster.NOVI, 40.0, 2))
        if SOFFICE:
            import subprocess; subprocess.run(SOFFICE + ["--headless", "--convert-to", "xls", "--outdir", self.d, px], check=True, capture_output=True, timeout=200)
            self.assertEqual(roster.read_roster(os.path.join(self.d, "l.xls"))[0]["name"], "Ana Anić")
        with self.assertRaises(core.AppError): roster.read_roster(os.path.join(self.d, "nema.txt")) if False else roster.read_roster(__file__)

    def test_obrazac_za_uredjaj_samo_novi_ili_svi_a_stari_ID_ostaju(self):
        p = os.path.join(self.d, "o.xlsx"); make_xlsx(p, [(None, f"Obr Radnik{c}", "German", "", "") for c in "AB"]); _, rep = self.run_roster(p); ids = [e for e, _ in rep["dodani"]]
        self.assertEqual(self.db.get("zadnje_dodani").split(","), ids)
        for only, n, first in ((set(ids), 2, 36), (None, 37, 1)):
            out = os.path.join(self.d, f"f{n}.xlsx"); core.fill_device_form(self.db, DEV, out, only_ids=only); ws = load_workbook(out)["Employee Form"]
            got = [(ws.cell(r, 1).value, ws.cell(r, 2).value) for r in range(9, 60) if ws.cell(r, 1).value]
            self.assertEqual(len(got), n); self.assertEqual(got[0][0], first); self.assertEqual(len({g[0] for g in got}), n)
        self.assertEqual(got[0], (1, "Davor Mulalic"))
        with self.assertRaises(core.AppError): core.fill_device_form(self.db, DEV, out, only_ids=set())

    def test_novi_radnici_dobivaju_sihtaricu_i_inspekcija_prolazi_a_stari_podaci_isti(self):
        import inspekcija
        p = os.path.join(self.d, "i.xlsx"); make_xlsx(p, [(None, "Šihtarica Novi", "Teacher", "", "")]); self.run_roster(p)
        dev = os.path.join(self.d, "d.xlsx"); device_file(dev, (D(2026, 10, 1), D(2026, 10, 9)), {36: {"2026-10-02": "08:00\n16:00"}, 1: {"2026-10-02": "08:00\n16:00"}}); core.import_device_file(self.db, dev)
        out = os.path.join(self.d, "s.xlsx"); core.export_sihtarica(self.db, TPL, out, 2026, 10, soffice_cmd=SOFFICE); wb = load_workbook(out); self.assertEqual(len(wb.sheetnames), 36)
        self.assertEqual(core.day_records(self.db, "IDSS-002", 2026, 9)["2026-09-08"]["final"]["start"], "08:00")   # stara korekcija netaknuta

DEV = os.path.join(HERE, "..", "sablon", "Employee_Form_sablon.xlsx")
if __name__ == "__main__": unittest.main(verbosity=1)
