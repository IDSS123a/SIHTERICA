# -*- coding: utf-8 -*-
import os, sys, tempfile, shutil, datetime as dt, unittest
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, ".."))
import core
from openpyxl import Workbook
TPL = os.path.join(HERE, "..", "sablon", "Sihtarica_IDSS.xlsx")
EMP_XLSX = os.path.join(HERE, "..", "podaci_za_pocetak", "IDSS_Zaposlenici_prijedlog.xlsx")
WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
# LibreOffice za preračun formula: na Windowsu ga pronalazi aplikacija, u ovom okruženju koristimo omotač
SOFFICE = None
if os.path.exists("/mnt/skills/public/xlsx/scripts/office/soffice.py"): SOFFICE = [sys.executable, "/mnt/skills/public/xlsx/scripts/office/soffice.py"]
elif core.find_soffice(): SOFFICE = core.find_soffice()

def device_file(path, period, data, names=None, summary=True, order=None, gap=0, drop_blocks=(), summary_actual=None):
    """Datoteka u STVARNOM rasporedu uređaja: Attendance Logs (blok po radniku) + Attendance summary + Schedule information sheet.
    data = {device_no: {'YYYY-MM-DD': 'hh:mm\\nhh:mm'}}; order = redoslijed blokova; gap = prazni redovi između blokova;
    drop_blocks = ID-evi čiji se blok NE upisuje u Attendance Logs (ali ostaju u sažetku)."""
    a, b = period; n = (b - a).days + 1; rng_txt = f"{a:%d/%m/%Y} ~ {b:%d/%m/%Y}"
    wb = Workbook(); ws = wb.active; ws.title = "Attendance Logs"
    ws.append(["Attendance Logs"]); ws.append(["Date", None, rng_txt])
    for no in (order or list(data)):
        if no in drop_blocks or no not in data: continue
        days = data[no]
        head = [None] * 21; head[0] = "ID"; head[2] = no; head[9] = "Name"; head[11] = (names or {}).get(no, "x"); head[18] = "Dept."; head[20] = "Not Set4"
        ws.append(head); ws.append([(a + dt.timedelta(i)).day for i in range(n)])
        ws.append([WD[(a + dt.timedelta(i)).weekday()] for i in range(n)])
        ws.append([days.get((a + dt.timedelta(i)).isoformat()) for i in range(n)])
        for _ in range(gap): ws.append([])
    if summary:
        s = wb.create_sheet("Attendance summary"); s.append(["Attendance summary"]); s.append(["Date", rng_txt])
        s.append(["ID", "Name", "Dept.", "Working hours", None, "Late", None, "Early", None, "Overtime", None, "Attend(Standard/Actual)"]); s.append([None, None, None, "Standard", "Actual"])
        for no, days in data.items():
            act = (summary_actual or {}).get(no, sum(1 for v in days.values() if v))
            s.append([float(no), "x", "Not Set4", "00:00", "00:00", 0.0, 0.0, 0.0, 0.0, "00:00", "00:00", f"{n}/{act}"])
        sc = wb.create_sheet("Schedule information sheet"); sc.append(["Schedule information sheet"]); sc.append(["Date", rng_txt]); sc.append(["ID", "Name", "Dept."]); sc.append([])
        for no in data: sc.append([float(no), "x", "Not Set4"])
    wb.save(path)

class Base(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp(); self.db = core.DB(self.d); self.db.load_employees_xlsx(EMP_XLSX)
    def tearDown(self): self.db.c.close(); shutil.rmtree(self.d, ignore_errors=True)
