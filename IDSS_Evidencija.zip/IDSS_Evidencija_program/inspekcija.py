# -*- coding: utf-8 -*-
"""INSPEKCIJA – nezavisna provjera izvezene šihtarice.

Šta se provjerava (svaki list, svaka ćelija):
  A. List je vjerna kopija kanonskog obrasca (Sihtarica_IDSS.xlsx): tekstovi, formule, spojene ćelije, širine kolona,
     visine redova, formati brojeva, fontovi, boje, obrube, poravnanja, validacije unosa, zamrznuto okno, postavke štampe.
  B. Samo dozvoljene ćelije (zaglavlje + dnevni unos) smiju imati drugačiji sadržaj, i to TAČNO onaj koji proizlazi iz baze.
  C. Logika unosa: potpuni intervali, pauza unutar radnog vremena, dani izvan mjeseca prazni, sati u dozvoljenom rasponu.
  D. (ako postoji LibreOffice) preračun formula i poređenje s nezavisnim izračunom.
  E. Popunjenost: nerazriješeni dani, radni dani bez evidencije, radnici bez lista.
Ograničenje: INSPEKCIJA dokazuje vjernost obrascu i tačnost podataka, ne zamjenjuje pravnu ocjenu usklađenosti s propisima."""
import os, hashlib, datetime as dt, tempfile, shutil, subprocess, calendar, zipfile
from openpyxl import load_workbook
import core
from core import MJESECI, SHEET_TEMPLATE, DAY_COLS, sat_formula, AppError

GRESKA, UPOZ, INFO = "GREŠKA", "UPOZORENJE", "INFO"
MAX_DNEVNO_SATI = 12.0
COLS = "ABCDEFGHIJKLMNOPQ"
NROWS = 43
TEMPLATE_FINGERPRINT = "6868f97ca26202ee96db2bca25d2ba2fcff6dbf1987ee594f5cc27fa9f7a9962"

class Report:
    def __init__(self, path): self.path = path; self.findings = []; self.sheets = []; self.sha256 = ""; self.when = dt.datetime.now(); self.title = ""
    def add(self, sev, sheet, cell, code, msg): self.findings.append((sev, sheet or "", cell or "", code, msg))
    def count(self, sev): return sum(1 for f in self.findings if f[0] == sev)
    @property
    def ok(self): return self.count(GRESKA) == 0
    def errors_text(self, limit=25):
        e = [f for f in self.findings if f[0] == GRESKA]
        return "\n".join(f"[{f[1]} {f[2]}] {f[4]}" for f in e[:limit]) + (f"\n… i još {len(e) - limit}" if len(e) > limit else "")
    def to_text(self):
        L = ["IZVJEŠTAJ INSPEKCIJE ŠIHTARICA", "=" * 60, f"Naslov:    {self.title}", f"Datoteka:  {self.path}", f"SHA-256:   {self.sha256}",
             f"Vrijeme:   {self.when:%d.%m.%Y. %H:%M:%S}", f"Listova:   {len(self.sheets)}",
             f"REZULTAT:  {'PROŠLA – nema grešaka' if self.ok else 'NIJE PROŠLA'}   (grešaka: {self.count(GRESKA)}, upozorenja: {self.count(UPOZ)}, napomena: {self.count(INFO)})", ""]
        for sev in (GRESKA, UPOZ, INFO):
            rows = [f for f in self.findings if f[0] == sev]
            if rows:
                L.append(f"--- {sev} ({len(rows)}) ---")
                L += [f"  [{f[1]}{' ' + f[2] if f[2] else ''}] {f[3]}: {f[4]}" for f in rows]
                L.append("")
        L += ["Opseg: vjernost kanonskom obrascu, tačnost podataka u odnosu na bazu, logika unosa, preračun formula (ako je dostupan LibreOffice).",
              "INSPEKCIJA ne zamjenjuje pravnu ocjenu usklađenosti s propisima i kolektivnim ugovorom."]
        return "\n".join(L)
    def save(self, path):
        with open(path, "w", encoding="utf-8") as f: f.write(self.to_text())

# ------------------------------------------------------------------ otisak stila i svojstava
def _col(x):
    if x is None: return None
    t = getattr(x, "type", None)
    if t == "rgb": return ("rgb", x.rgb)
    if t == "theme": return ("theme", x.theme, round(x.tint or 0, 4))
    if t == "indexed": return ("idx", x.indexed)
    return (t,)

def style_sig(c):
    f, b, a = c.font, c.border, c.alignment
    return (c.number_format, f.name, f.sz, bool(f.b), bool(f.i), f.u, bool(f.strike), _col(f.color),
            c.fill.fill_type, _col(c.fill.fgColor) if c.fill.fill_type else None,
            tuple(((getattr(b, s).style, _col(getattr(b, s).color) if getattr(b, s).style else None) if getattr(b, s) is not None else (None, None)) for s in ("left", "right", "top", "bottom")),
            a.horizontal, a.vertical, bool(a.wrap_text), a.indent, a.textRotation, bool(a.shrink_to_fit),
            bool(c.protection.locked), bool(c.protection.hidden))

def col_widths(ws):
    out = {}
    for key, d in ws.column_dimensions.items():
        lo, hi = (d.min or 1), (d.max or d.min or 1)
        for i in range(lo, min(hi, 60) + 1): out[i] = (round(d.width, 3) if d.width else None, bool(d.hidden))
    return out

def sheet_props(ws):
    ps, pm, po = ws.page_setup, ws.page_margins, ws.print_options
    dvs = sorted((str(d.sqref), d.type, d.operator, d.formula1, d.formula2, d.allow_blank, d.showErrorMessage, d.errorTitle, d.error, d.prompt)
                 for d in ws.data_validations.dataValidation)
    hf = tuple(getattr(getattr(getattr(ws.HeaderFooter, p), pos), "text") for p in ("oddHeader", "oddFooter") for pos in ("left", "center", "right"))
    return {
        "dimenzije": (ws.max_row, ws.max_column),
        "spojene_ćelije": sorted(str(m) for m in ws.merged_cells.ranges),
        "širine_kolona": col_widths(ws),
        "visine_redova": {r: ws.row_dimensions[r].height for r in range(1, NROWS + 3) if ws.row_dimensions[r].height is not None},
        "sakriveni_redovi": [r for r in range(1, NROWS + 3) if ws.row_dimensions[r].hidden],
        "zamrznuto_okno": ws.freeze_panes, "naslovni_redovi_štampe": ws.print_title_rows, "područje_štampe": (ws.print_area.split("!")[-1] if ws.print_area else None),
        "štampa": (ps.orientation, ps.paperSize, ps.fitToWidth, ps.fitToHeight, ps.scale),
        "prilagodi_stranici": bool(getattr(ws.sheet_properties.pageSetUpPr, "fitToPage", False)),
        "margine": tuple(round(getattr(pm, k), 4) for k in ("left", "right", "top", "bottom", "header", "footer")),
        "opcije_štampe": (po.horizontalCentered, po.verticalCentered, po.gridLines, po.headings),
        "zaglavlje_podnožje": hf, "validacije": dvs,
        "uslovno_formatiranje": len(list(ws.conditional_formatting)), "stanje": ws.sheet_state, "zaštita_lista": bool(ws.protection.sheet),
        "linije_mreže": ws.sheet_view.showGridLines, "zumiranje": ws.sheet_view.zoomScale,
        "slike_grafikoni": (len(ws._images), len(ws._charts)), "hiperveze": len(ws._hyperlinks),
    }

def template_fingerprint(tpl):
    h = hashlib.sha256()
    for r in range(1, NROWS + 1):
        for c in range(1, len(COLS) + 1):
            cell = tpl.cell(r, c); h.update(repr((cell.coordinate, cell.value, style_sig(cell))).encode("utf-8"))
    h.update(repr(sorted(sheet_props(tpl).items(), key=lambda kv: kv[0])).encode("utf-8"))
    return h.hexdigest()

TEMPLATE_FILE_SHA256 = "d329ac30d9a9901658ccf2a6ee709c9c48c3c1faa68c1953e06084b815ecce1a"

def check_template(template, rep=None):
    """Provjerava da obrazac u mapi sablon nije mijenjan (SHA-256 datoteke; ne zavisi od verzije biblioteka)."""
    with open(template, "rb") as fh: got = hashlib.sha256(fh.read()).hexdigest()
    if got != TEMPLATE_FILE_SHA256:
        if rep: rep.add(GRESKA, "", "", "OBRAZAC", "Kanonski obrazac u mapi 'sablon' nije identičan originalu (SHA-256 se ne poklapa). Vratite originalnu Sihtarica_IDSS.xlsx.")
        return False
    return True

# ------------------------------------------------------------------ glavna provjera
def _norm(v):
    if isinstance(v, dt.datetime) and v.date() == dt.date(1899, 12, 30): return v.time()
    return v

def _same(a, b):
    a, b = _norm(a), _norm(b)
    if isinstance(a, bool) or isinstance(b, bool): return a is b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)): return abs(a - b) < 1e-9
    return type(a) == type(b) and a == b if not (a is None or b is None) else a is b

def expected_titles(db, emps):
    used, out = set(), []
    for e in emps:
        title = core._safe_title(f"{e['id']} {e['name']}"); base, k = title, 1
        while title in used: k += 1; title = f"{base[:28]}~{k}"
        used.add(title); out.append(title)
    return out

def inspect_file(db, path, y, m, emp_ids=None, template=None, allow_unresolved=False, soffice_cmd=None, recalc=True):
    template = template or os.path.join(os.path.dirname(os.path.abspath(__file__)), "sablon", "Sihtarica_IDSS.xlsx")
    rep = Report(path); rep.title = f"{MJESECI[m - 1]} {y}"
    if not os.path.exists(path): rep.add(GRESKA, "", "", "DATOTEKA", "Datoteka ne postoji."); return rep
    with open(path, "rb") as fh: rep.sha256 = hashlib.sha256(fh.read()).hexdigest()
    try:
        if zipfile.ZipFile(path).testzip() is not None: raise zipfile.BadZipFile("oštećen sadržaj")
        wb = load_workbook(path)
    except Exception as ex:
        rep.add(GRESKA, "", "", "DATOTEKA", f"Datoteka se ne može otvoriti kao ispravan .xlsx ({ex})."); return rep
    check_template(template, rep)
    tpl = load_workbook(template)[SHEET_TEMPLATE]; tprops = sheet_props(tpl)
    emps = [db.employee(i) for i in emp_ids] if emp_ids else db.employees()
    titles = expected_titles(db, emps)
    # ---- radna sveska
    if list(wb.sheetnames) != titles:
        miss = [t for t in titles if t not in wb.sheetnames]; extra = [t for t in wb.sheetnames if t not in titles]
        if miss: rep.add(GRESKA, "", "", "LISTOVI", "Nedostaju listovi: " + ", ".join(miss))
        if extra: rep.add(GRESKA, "", "", "LISTOVI", "Višak listova: " + ", ".join(extra))
        if not miss and not extra: rep.add(GRESKA, "", "", "LISTOVI", "Redoslijed listova nije kao u evidenciji radnika.")
    if len(set(wb.sheetnames)) != len(wb.sheetnames): rep.add(GRESKA, "", "", "LISTOVI", "Ponavljaju se nazivi listova.")
    if wb.defined_names: rep.add(GRESKA, "", "", "IMENA", "Radna sveska sadrži definisana imena koja obrazac nema.")
    ndays = calendar.monthrange(y, m)[1]
    totals = {}
    for e, title in zip(emps, titles):
        if title not in wb.sheetnames: continue
        ws = wb[title]; rep.sheets.append(title)
        head, days = core.sheet_content(db, e, y, m)
        # A. svojstva lista
        props = sheet_props(ws)
        for k, v in tprops.items():
            if props[k] != v: rep.add(GRESKA, title, "", "SVOJSTVO", f"'{k}' se razlikuje od obrasca (obrazac: {v}; list: {props[k]}).")
        # B. ćelije
        expected = {}
        for r in range(1, NROWS + 1):
            for c in range(1, len(COLS) + 1): expected[(r, c)] = tpl.cell(r, c).value
        for cell, v in head.items(): expected[(int(cell[1:]), COLS.index(cell[0]) + 1)] = v
        for row, cells in days.items():
            for col, v in cells.items(): expected[(row, COLS.index(col) + 1)] = v
        for r in range(1, NROWS + 1):
            for c in range(1, len(COLS) + 1):
                a, t = ws.cell(r, c), tpl.cell(r, c); coord = a.coordinate
                if style_sig(a) != style_sig(t): rep.add(GRESKA, title, coord, "STIL", "Format ćelije (font/boja/obruba/broj/poravnanje) razlikuje se od obrasca.")
                if a.data_type == "f" and t.data_type != "f": rep.add(GRESKA, title, coord, "FORMULA_INJEKCIJA", "Ćelija sadrži formulu koje u obrascu nema (tekst koji počinje s '=' mora ostati tekst).")
                exp = expected[(r, c)]
                if not _same(a.value, exp):
                    kanon = (r, c) == (r, c) and (coord not in head) and not (7 <= r <= 37 and COLS[c - 1] in "DEFGIJKLMNOPQ")
                    rep.add(GRESKA, title, coord, "KANON" if kanon and exp is not None and exp == tpl.cell(r, c).value else "PODACI",
                            f"Očekivano {exp!r}, u listu {a.value!r}." if len(repr(exp)) < 80 and len(repr(a.value)) < 80 else "Sadržaj ćelije se ne poklapa s obrascem/bazom.")
        # C. logika unosa (nezavisno od baze – gleda samo datoteku)
        hours_sum = 0.0; sums = {k: 0.0 for k in "IJKLMNO"}; worked = 0
        for r in range(7, 38):
            day = r - 6; vals = {col: ws[f"{col}{r}"].value for col in "DEFGIJKLMNOPQ"}
            if day > ndays:
                if any(v not in (None, "") for v in vals.values()): rep.add(GRESKA, title, f"A{r}", "DAN", f"Podaci upisani za dan {day}, a mjesec ima {ndays} dana.")
                continue
            t = {}
            for col in "DEFG":
                v = _norm(vals[col])
                if v is None: continue
                if not isinstance(v, dt.time) or v.second or v.microsecond: rep.add(GRESKA, title, f"{col}{r}", "VRIJEME", f"Vrijednost {v!r} nije vrijeme hh:mm."); continue
                t[col] = v
            if ("D" in t) != ("E" in t): rep.add(GRESKA, title, f"D{r}", "INTERVAL", "Upisan je samo jedan kraj radnog vremena (nepotpun interval).")
            if ("F" in t) != ("G" in t): rep.add(GRESKA, title, f"F{r}", "PAUZA", "Upisan je samo jedan kraj pauze (nepotpuna pauza).")
            if {"D", "E"} <= set(t):
                if t["E"] <= t["D"]:
                    rep.add(UPOZ if db.get("preko_ponoci", "0") == "1" else GRESKA, title, f"E{r}", "PREKO_PONOCI", "Završetak rada nije poslije početka (obračun bi išao preko ponoći) – vjerovatno pogrešan unos.")
                elif {"F", "G"} <= set(t) and not (t["D"] <= t["F"] < t["G"] <= t["E"]): rep.add(GRESKA, title, f"F{r}", "PAUZA", "Pauza nije unutar radnog vremena.")
                h = sat_formula(t["D"], t["E"], t.get("F"), t.get("G")); hours_sum += h; worked += 1
                if h > MAX_DNEVNO_SATI: rep.add(UPOZ, title, f"H{r}", "SATI", f"Dnevno {core.dec_to_hhmm(h)} sati – provjerite (granica opreza {MAX_DNEVNO_SATI:g} h, nije propis).")
                if h <= 0: rep.add(UPOZ, title, f"H{r}", "SATI", "Dnevni zbir sati je nula ili negativan.")
            if {"D", "E"} <= set(t) and any(isinstance(vals[c], (int, float)) and not isinstance(vals[c], bool) and vals[c] > 0 for c in "LMN"):
                rep.add(UPOZ, title, f"A{r}", "KOLIZIJA", "Isti dan ima radne sate i godišnji/bolovanje/praznik – provjerite.")
            for col in "IJKLMNO":
                v = vals[col]
                if v is None: continue
                if isinstance(v, bool) or not isinstance(v, (int, float)) or v < 0 or v > 24: rep.add(GRESKA, title, f"{col}{r}", "SATI", f"Neispravan broj sati '{v}' (dozvoljeno 0–24).")
                else: sums[col] += v
            if vals["P"] is not None and not isinstance(vals["P"], str): rep.add(GRESKA, title, f"P{r}", "NAPOMENA", "Napomena mora biti tekst.")
            if vals["Q"] is not None: rep.add(GRESKA, title, f"Q{r}", "POTPIS", "Kolona za potpis mora ostati prazna (potpisuje radnik).")
        totals[title] = (round(hours_sum, 2), {k: round(v, 2) for k, v in sums.items()}, worked)
        # E. popunjenost
        un = core.unresolved(db, e["id"], y, m)
        for d in un:
            rep.add(UPOZ if allow_unresolved else GRESKA, title, "", "NERAZRIJESEN", f"{dt.date.fromisoformat(d):%d.%m.%Y.}: neparan/neočekivan broj otisaka – dan nije upisan u šihtaricu dok se ne riješi korekcijom.")
        today = dt.date.today(); recs = core.day_records(db, e["id"], y, m)
        absd = {a["day"] for a in db.absences(e["id"], y, m)}
        gaps = [d.isoformat() for d in core.workdays(db, y, m) if d < today and d.isoformat() not in recs and d.isoformat() not in absd]
        if gaps:
            rep.add(UPOZ, title, "", "BEZ_EVIDENCIJE", f"{len(gaps)} radnih dana bez otiska i bez odsustva: " + ", ".join(f"{dt.date.fromisoformat(d):%d.%m.}" for d in gaps[:12]) + (" …" if len(gaps) > 12 else ""))
    if emp_ids is None:
        have = {e["id"] for e in emps}
        for e in db.employees(active_only=False):
            if e["id"] not in have and db.c.execute("SELECT 1 FROM punches WHERE emp=? AND ts LIKE ? LIMIT 1", (e["id"], f"{y:04d}-{m:02d}-%")).fetchone():
                rep.add(UPOZ, e["id"] + " " + e["name"], "", "NEAKTIVAN", "Radnik je deaktiviran, a ima otiske u ovom mjesecu: nema lista u šihtarici.")
    rep.add(INFO, "", "", "SEDMICNO", "Obrazac nema označeno polje za ugovoreno sedmično radno vrijeme (red 4, lijevo); aplikacija ga ne upisuje osim ako je uključena postavka 'sedmicno_u_obrazac'.")
    # ---- D. preračun formula
    if recalc: _recalc_check(rep, db, path, emps, titles, y, m, totals, soffice_cmd)
    return rep

def _recalc_check(rep, db, path, emps, titles, y, m, totals, soffice_cmd):
    cmd = soffice_cmd or core.find_soffice()
    if not cmd: rep.add(INFO, "", "", "PRERACUN", "LibreOffice nije dostupan: preračun formula nije izvršen. Formule su ipak provjerene kao identične kanonskim (tačnost kanona provjerena testovima)."); return
    tmp = tempfile.mkdtemp()
    try:
        src = os.path.join(tmp, "in.xlsx"); shutil.copy2(path, src)
        subprocess.run(cmd + ["--headless", "--convert-to", "xlsx", "--outdir", os.path.join(tmp, "out"), src], check=True, capture_output=True, timeout=300, creationflags=(0x08000000 if os.name == "nt" else 0))
        wb = load_workbook(os.path.join(tmp, "out", "in.xlsx"), data_only=True)
    except Exception as ex:
        rep.add(INFO, "", "", "PRERACUN", f"Preračun formula nije uspio ({type(ex).__name__}); nije dokaz greške."); shutil.rmtree(tmp, ignore_errors=True); return
    ndays = calendar.monthrange(y, m)[1]; checked = 0
    for e, title in zip(emps, titles):
        if title not in wb.sheetnames: continue
        ws = wb[title]
        for r in range(7, 38):
            day = r - 6; b, c, h = ws[f"B{r}"].value, ws[f"C{r}"].value, ws[f"H{r}"].value
            for cell in (b, c, h):
                if isinstance(cell, str) and cell.startswith("#"): rep.add(GRESKA, title, f"B{r}", "FORMULA", f"Formula vraća grešku {cell}.")
            if day <= ndays:
                d = dt.date(y, m, day)
                bd = b.date() if isinstance(b, dt.datetime) else b
                if bd != d: rep.add(GRESKA, title, f"B{r}", "FORMULA", f"Datum u listu je {b!r}, treba {d}.")
                if c != core.DANI[d.weekday()]: rep.add(GRESKA, title, f"C{r}", "FORMULA", f"Dan u sedmici je {c!r}, treba {core.DANI[d.weekday()]}.")
            elif b not in (None, "") or c not in (None, ""): rep.add(GRESKA, title, f"B{r}", "FORMULA", f"Red za dan {day} mora biti prazan u mjesecu s {ndays} dana.")
            vals = {col: ws[f"{col}{r}"].value for col in "DEFG"}
            exp = None
            if vals["D"] is not None and vals["E"] is not None:
                tm = lambda v: v if isinstance(v, dt.time) else (v.time() if isinstance(v, dt.datetime) else None)
                exp = sat_formula(tm(vals["D"]), tm(vals["E"]), tm(vals["F"]) if vals["F"] is not None and vals["G"] is not None else None, tm(vals["G"]) if vals["F"] is not None and vals["G"] is not None else None)
            if (exp is None and h not in (None, "")) or (exp is not None and (not isinstance(h, (int, float)) or abs(h - exp) > 0.006)):
                rep.add(GRESKA, title, f"H{r}", "FORMULA", f"Ukupno dnevno sati je {h!r}, nezavisni izračun daje {exp!r}.")
            checked += 1
        hs, sums, _ = totals.get(title, (0, {}, 0))
        if abs((ws["H38"].value or 0) - hs) > 0.011: rep.add(GRESKA, title, "H38", "ZBIR", f"UKUPNO H je {ws['H38'].value!r}, treba {hs}.")
        for col, v in sums.items():
            if abs((ws[f"{col}38"].value or 0) - v) > 0.011: rep.add(GRESKA, title, f"{col}38", "ZBIR", f"UKUPNO {col} je {ws[f'{col}38'].value!r}, treba {v}.")
    rep.add(INFO, "", "", "PRERACUN", f"Preračun formula provjeren u LibreOfficeu ({checked} redova; datumi, dani, sati, zbirovi).")
    shutil.rmtree(tmp, ignore_errors=True)

def inspect_month(db, template, y, m, emp_ids=None, allow_unresolved=False, soffice_cmd=None, keep_dir=None):
    """Probni izvoz u privremenu datoteku i potpuna inspekcija (ne ostavlja ništa osim ako je zadano keep_dir)."""
    tmp = tempfile.mkdtemp()
    try:
        out = os.path.join(tmp, f"Sihtarica_{y}_{m:02d}.xlsx")
        core.export_sihtarica(db, template, out, y, m, emp_ids, allow_unresolved=True, verify=False)
        rep = inspect_file(db, out, y, m, emp_ids, template=template, allow_unresolved=allow_unresolved, soffice_cmd=soffice_cmd)
        if keep_dir: shutil.copy2(out, os.path.join(keep_dir, os.path.basename(out)))
        return rep
    finally: shutil.rmtree(tmp, ignore_errors=True)
