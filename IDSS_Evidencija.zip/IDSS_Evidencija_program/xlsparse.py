# -*- coding: utf-8 -*-
"""Minimalni čitač .xls (BIFF8, Excel 97–2003) bez vanjskih biblioteka. Čita samo vrijednosti ćelija (tekst, brojevi, logičke,
izračunate vrijednosti formula) – dovoljno za izvještaje uređaja. Koristi se kao rezerva ako 'xlrd' nije dostupan ili ne uspije."""
import struct

class XlsError(Exception):
    pass

ENDOFCHAIN, FREESECT = 0xFFFFFFFE, 0xFFFFFFFF

def _ole_stream(data, names=("Workbook", "Book")):
    if data[:8] != b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1": raise XlsError("Nije Excel 97–2003 (.xls) datoteka.")
    u16 = lambda o: struct.unpack_from("<H", data, o)[0]; u32 = lambda o: struct.unpack_from("<I", data, o)[0]
    ssz = 1 << u16(30); msz = 1 << u16(32); n_fat = u32(44); dir_start = u32(48); cutoff = u32(56)
    mini_start = u32(60); difat_start = u32(68); n_difat = u32(72)
    sector = lambda i: data[(i + 1) * ssz:(i + 2) * ssz]
    difat = [u32(76 + 4 * i) for i in range(109)]
    sec = difat_start
    for _ in range(n_difat):
        if sec >= 0xFFFFFFFA: break
        b = sector(sec); ids = struct.unpack("<%dI" % (ssz // 4), b); difat += list(ids[:-1]); sec = ids[-1]
    fat = []
    for s in [x for x in difat if x < 0xFFFFFFFA][:n_fat]: fat += struct.unpack("<%dI" % (ssz // 4), sector(s))
    def chain(start, table=None):
        table = fat if table is None else table; out, seen = [], set()
        while start < 0xFFFFFFFA:
            if start in seen or start >= len(table): raise XlsError("Oštećen lanac sektora.")
            seen.add(start); out.append(start); start = table[start]
        return out
    d = b"".join(sector(i) for i in chain(dir_start)); entries = []
    for o in range(0, len(d) - 127, 128):
        nlen = struct.unpack_from("<H", d, o + 64)[0]; nm = d[o:o + max(0, nlen - 2)].decode("utf-16-le", "replace")
        entries.append((nm, d[o + 66], struct.unpack_from("<I", d, o + 116)[0], struct.unpack_from("<I", d, o + 120)[0]))
    root = next((e for e in entries if e[1] == 5), None); ent = next((e for e in entries if e[0] in names and e[1] == 2), None)
    if not ent: raise XlsError("Datoteka nema Workbook tok (možda je zaštićena ili oštećena).")
    _, _, start, size = ent
    if size >= cutoff: return b"".join(sector(i) for i in chain(start))[:size]
    ministream = b"".join(sector(i) for i in chain(root[2]))[:root[3]]
    mfat = []
    for s in chain(mini_start): mfat += struct.unpack("<%dI" % (ssz // 4), sector(s))
    return b"".join(ministream[i * msz:(i + 1) * msz] for i in chain(start, mfat))[:size]

def _records(buf, pos=0):
    while pos + 4 <= len(buf):
        rid, ln = struct.unpack_from("<HH", buf, pos); yield rid, buf[pos + 4:pos + 4 + ln], pos; pos += 4 + ln

def _ustr(buf, pos, cch_size=2):
    """Unicode string u zapisu (cch, flags, ...). Vraća (tekst, nova pozicija)."""
    cch = struct.unpack_from("<H" if cch_size == 2 else "<B", buf, pos)[0]; pos += cch_size; fl = buf[pos]; pos += 1
    rich = ext = 0
    if fl & 8: rich = struct.unpack_from("<H", buf, pos)[0]; pos += 2
    if fl & 4: ext = struct.unpack_from("<I", buf, pos)[0]; pos += 4
    if fl & 1: txt = buf[pos:pos + 2 * cch].decode("utf-16-le", "replace"); pos += 2 * cch
    else: txt = buf[pos:pos + cch].decode("latin-1"); pos += cch
    return txt, pos + 4 * rich + ext

def _sst(chunks):
    first = chunks[0]; uniq = struct.unpack_from("<I", first, 4)[0]; ci, pos = 0, 8; out = []
    def cur(): return chunks[ci]
    for _ in range(uniq):
        while pos >= len(cur()) and ci + 1 < len(chunks): ci += 1; pos = 0
        c = cur(); cch = struct.unpack_from("<H", c, pos)[0]; fl = c[pos + 2]; pos += 3; rich = ext = 0
        if fl & 8: rich = struct.unpack_from("<H", c, pos)[0]; pos += 2
        if fl & 4: ext = struct.unpack_from("<I", c, pos)[0]; pos += 4
        wide = bool(fl & 1); remaining = cch; parts = []
        while remaining > 0:
            c = cur(); w = 2 if wide else 1; take = min((len(c) - pos) // w, remaining)
            if take > 0:
                raw = c[pos:pos + take * w]; parts.append(raw.decode("utf-16-le", "replace") if wide else raw.decode("latin-1")); pos += take * w; remaining -= take
            if remaining > 0:
                if ci + 1 >= len(chunks): raise XlsError("Oštećena tabela tekstova.")
                ci += 1; c = cur(); wide = bool(c[0] & 1); pos = 1
        skip = 4 * rich + ext
        while skip > 0:
            avail = len(cur()) - pos; t = min(avail, skip); pos += t; skip -= t
            if skip > 0:
                if ci + 1 >= len(chunks): break
                ci += 1; pos = 0
        out.append("".join(parts))
    return out

def _rk(v):
    if v & 2: x = struct.unpack("<i", struct.pack("<I", v))[0] >> 2; val = float(x)
    else: val = struct.unpack("<d", struct.pack("<Q", (v & 0xFFFFFFFC) << 32))[0]
    return val / 100 if v & 1 else val

def read_xls(path):
    """Vraća {naziv_lista: [[vrijednost, ...], ...]} (prazne ćelije su None)."""
    with open(path, "rb") as f: wbs = _ole_stream(f.read())
    sheets, sst_chunks, collecting, ver = [], [], False, None
    for rid, d, pos in _records(wbs):
        if rid == 0x809 and ver is None: ver = struct.unpack_from("<H", d, 0)[0]
        if rid == 0x0A: break                                   # kraj globalnog dijela
        if rid == 0x85:
            off = struct.unpack_from("<I", d, 0)[0]; typ = d[5]; nm, _ = _ustr(d, 6, 1); sheets.append((nm, off, typ))
        elif rid == 0xFC: sst_chunks = [d]; collecting = True; continue
        elif rid == 0x3C and collecting: sst_chunks.append(d); continue
        collecting = False
    if ver != 0x600: raise XlsError("Podržan je samo format Excel 97–2003 (BIFF8).")
    sst = _sst(sst_chunks) if sst_chunks else []
    out = {}
    for nm, off, typ in sheets:
        if typ != 0: continue
        cells, last_formula, depth = {}, None, 0
        for rid, d, _ in _records(wbs, off):
            if rid == 0x809:
                depth += 1
                if depth > 1: break
            elif rid == 0x0A: break
            elif rid == 0xFD: r, c, _, i = struct.unpack_from("<HHHI", d, 0); cells[(r, c)] = sst[i] if i < len(sst) else None
            elif rid == 0x204: r, c = struct.unpack_from("<HH", d, 0); cells[(r, c)] = _ustr(d, 6)[0]
            elif rid == 0x203: r, c = struct.unpack_from("<HH", d, 0); cells[(r, c)] = struct.unpack_from("<d", d, 6)[0]
            elif rid == 0x27E: r, c = struct.unpack_from("<HH", d, 0); cells[(r, c)] = _rk(struct.unpack_from("<I", d, 6)[0])
            elif rid == 0xBD:
                r, c0 = struct.unpack_from("<HH", d, 0); n = (len(d) - 6) // 6
                for k in range(n): cells[(r, c0 + k)] = _rk(struct.unpack_from("<I", d, 4 + 6 * k + 2)[0])
            elif rid == 0x205: r, c = struct.unpack_from("<HH", d, 0); cells[(r, c)] = bool(d[6]) if d[7] == 0 else None
            elif rid == 0x06:
                r, c = struct.unpack_from("<HH", d, 0); res = d[6:14]
                if res[6:8] == b"\xff\xff":
                    if res[0] == 0: last_formula = (r, c)           # tekstualni rezultat slijedi u zapisu STRING
                    elif res[0] == 1: cells[(r, c)] = bool(res[2])
                else: cells[(r, c)] = struct.unpack("<d", res)[0]
            elif rid == 0x207 and last_formula: cells[last_formula] = _ustr(d, 0)[0]; last_formula = None
        nr = max((r for r, _ in cells), default=-1) + 1; nc = max((c for _, c in cells), default=-1) + 1
        out[nm] = [[cells.get((r, c)) for c in range(nc)] for r in range(nr)]
    return out
