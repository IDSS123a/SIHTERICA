# -*- coding: utf-8 -*-
"""Uvoz liste radnika (novi zaposleni) – SIGURNO.

Načela:
  * Postojeći radnici se NIKAD ne brišu, ne preimenuju i ne mijenja im se ID. Lista koja ih ne sadrži ništa im ne radi.
  * Novi radnik uvijek dobiva prvi broj koji nikad nije korišten (iznad svih radnika, deaktiviranih i ID-eva viđenih na uređaju).
  * Prvo se pravi PREGLED (plan); tek potvrđeni plan se primjenjuje, u jednoj transakciji, uz rezervnu kopiju baze.
  * Sumnjivi redovi (isto ime drugačijeg zapisa, moguć duplikat, ID koji pripada drugom radniku) se ne primjenjuju sami od sebe."""
import csv, os, re, difflib
import core
from core import AppError, translit, name_key, DEPT_NAMES

NOVI, POSTOJI, REAKT, PROVJERA, GRESKA = "NOVI", "POSTOJI", "REAKTIVIRATI", "PROVJERA", "GREŠKA"
HEADERS = ["Ime i prezime *", "Radno mjesto", "Poslovni e-mail", "Telefon", "Ugovoreno sedmično (sati)", "Odjel na uređaju (broj 1–16 ili naziv)",
           "Ovlast (0 = radnik, 1 = administrator)", "ID (ostaviti prazno – dodjeljuje aplikacija)"]

def _norm(h): return re.sub(r"[^a-z0-9]", "", translit(str(h or "")).lower())

def col_kind(h):
    n = _norm(h)
    if not n: return None
    if "privat" in n or "private" in n or "rodjen" in n or "birth" in n or "datum" in n: return None          # privatni podaci se NE uvoze
    if n in ("id", "sifra", "idradnika") or n.startswith(("idradnika", "idostaviti", "idbroj")): return "id"
    if n in ("name", "ime", "imeprezime", "radnik", "zaposlenik", "zaposleni") or n.startswith("imeiprezime"): return "name"
    if n.startswith(("radnomjesto", "pozicija", "position", "funkcija")): return "position"
    if n.startswith(("poslovni", "email", "mail")): return "email"
    if n.startswith(("telefon", "phone", "mobitel", "tel")): return "phone"
    if "sedmic" in n or "weekly" in n: return "weekly"
    if n.startswith(("odjel", "department", "dept")): return "dept"
    if n.startswith(("ovlast", "authority", "admin")): return "authority"
    return None

def _cell(v):
    if v is None: return ""
    if isinstance(v, float) and v == int(v): return str(int(v))
    return re.sub(r"\s+", " ", str(v)).strip()

def read_roster(path):
    """Čita .xlsx / .xls / .csv. Vraća listu redova {'row': n, id, name, position, email, phone, weekly, dept, authority}."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        raw = open(path, "rb").read()
        try: text = raw.decode("utf-8-sig")
        except UnicodeDecodeError: text = raw.decode("cp1250", "replace")
        delim = ";" if text.count(";") >= text.count(",") else ","
        rows = [list(r) for r in csv.reader(text.splitlines(), delimiter=delim)]
    elif ext in (".xlsx", ".xlsm", ".xls"):
        sheets = core.read_workbook(path); rows = None
        for rws in sheets.values():                                      # prvi list koji ima prepoznatljivo zaglavlje
            if any(any(col_kind(c) == "name" for c in r) for r in rws[:15]): rows = rws; break
        if rows is None: rows = next(iter(sheets.values()), [])
    else: raise AppError("Podržane su datoteke .xlsx, .xls i .csv.")
    hdr = next((i for i, r in enumerate(rows[:15]) if any(col_kind(c) == "name" for c in r)), None)
    if hdr is None: raise AppError("U listi nisam našao kolonu s imenom radnika. Očekujem zaglavlje 'Ime i prezime' (ili 'Name'). Preuzmite predložak liste iz aplikacije.")
    cols = {}
    for j, c in enumerate(rows[hdr]):
        k = col_kind(c)
        if k and k not in cols: cols[k] = j
    out = []
    for i, r in enumerate(rows[hdr + 1:], hdr + 2):
        vals = {k: _cell(r[j]) if j < len(r) else "" for k, j in cols.items()}
        if not any(vals.values()): continue
        vals["row"] = i; out.append(vals)
    if not out: raise AppError("Lista nema nijednog reda s podacima.")
    return out

def _parse_id(t):
    m = re.fullmatch(r"(?:IDSS-?)?0*(\d{1,6})", t.strip(), re.I)
    return int(m[1]) if m and int(m[1]) > 0 else None

def _dept(t, position):
    if not t: return core.dept_for_position(position)
    if re.fullmatch(r"\d+", t):
        if 1 <= int(t) <= 16: return int(t)
        raise AppError("odjel mora biti 1–16")
    for n, nm in DEPT_NAMES.items():
        if name_key(nm) == name_key(t): return n
    raise AppError(f"nepoznat odjel '{t}'")

def _similar(k1, k2):
    if set(k1.split()) == set(k2.split()): return True
    return difflib.SequenceMatcher(None, k1, k2).ratio() >= 0.86

def plan_roster(db, rows):
    """Pravi PREGLED bez ikakve izmjene baze. Svaka stavka: status, ime, ID (postojeći ili predviđeni), napomena, razlike."""
    emps = db.employees(False); by_key = {name_key(e["name"]): e for e in emps}; by_no = {e["device_no"]: e for e in emps}
    seen = {r[0]: r[1] for r in db.c.execute("SELECT no, name FROM device_ids_seen")}
    used = db.used_numbers(); nxt = db.next_device_no(); file_keys = {}; items = []
    for r in rows:
        it = {"row": r["row"], "status": NOVI, "name": r["name"], "position": r.get("position", ""), "email": r.get("email", ""), "phone": r.get("phone", ""),
              "weekly": None, "dept": None, "authority": None, "id": "", "device_no": None, "note": "", "diffs": {}, "existing": None}
        items.append(it)
        def fail(msg): it["status"] = GRESKA; it["note"] = msg
        name = r["name"]
        if not name: fail("Ime je prazno."); continue
        if len(name) > 60 or any(ord(c) < 32 for c in name): fail("Ime je predugo ili sadrži nedozvoljene znakove."); continue
        dn = translit(name).strip()
        if not all(32 <= ord(c) < 127 for c in dn) or len(dn) > 32: fail(f"Ime na uređaju ('{dn[:40]}') mora imati najviše 32 osnovna znaka. Skratite ga."); continue
        key = name_key(name)
        if key in file_keys: fail(f"Isto ime se ponavlja u listi (red {file_keys[key]})."); continue
        file_keys[key] = r["row"]
        if r.get("email") and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", r["email"]): fail(f"E-mail '{r['email']}' nije ispravan."); continue
        try:
            if r.get("weekly"):
                w = float(r["weekly"].replace(",", ".")); 
                if not 0 < w <= 60: raise ValueError
                it["weekly"] = w
        except ValueError: fail("Sedmično radno vrijeme mora biti broj od 1 do 60."); continue
        try: it["dept"] = _dept(r.get("dept", ""), r.get("position", ""))
        except AppError as ex: fail(str(ex).capitalize() + "."); continue
        if r.get("authority", "") not in ("", "0", "1"): fail("Ovlast mora biti 0 ili 1."); continue
        it["authority"] = int(r["authority"]) if r.get("authority", "") != "" else 0
        given = None
        if r.get("id"):
            given = _parse_id(r["id"])
            if given is None: fail(f"ID '{r['id']}' nije ispravan (očekujem IDSS-036 ili 36)."); continue
        # ---- poklapanje s postojećim radnikom
        ex = by_key.get(key)
        if given is not None and given in by_no and by_no[given] is not ex:
            fail(f"ID {given} već pripada radniku '{by_no[given]['name']}'. Ime iz liste se ne poklapa: ništa nije promijenjeno."); continue
        if given is not None and given in seen and given not in by_no:
            fail(f"ID {given} je zauzet na uređaju (ime na uređaju: '{seen[given]}'). Ostavite ID prazan."); continue
        if ex is not None:
            if given is not None and given != ex["device_no"]: fail(f"Radnik već postoji s ID-em {ex['id']}, a u listi je ID {given}."); continue
            it["existing"] = ex; it["id"] = ex["id"]; it["device_no"] = ex["device_no"]
            for f_, new in (("position", r.get("position", "")), ("email", r.get("email", "")), ("phone", r.get("phone", ""))):
                if new and new != (ex[f_] or ""): it["diffs"][f_] = (ex[f_] or "", new)
            if it["weekly"] is not None and it["weekly"] != ex["weekly_hours"]: it["diffs"]["weekly_hours"] = (ex["weekly_hours"], it["weekly"])
            if ex["active"]: it["status"] = POSTOJI; it["note"] = "Već postoji – ništa se ne mijenja." + (" Razlike u kontaktu se mogu primijeniti na zahtjev." if it["diffs"] else "")
            else: it["status"] = REAKT; it["note"] = f"Deaktiviran radnik ({ex['id']}); ako se vraća na posao zadržava ISTI ID. Potvrdite ako želite aktivirati."
            continue
        # ---- moguć duplikat?
        sim = [e for k, e in by_key.items() if _similar(key, k)]
        if sim:
            it["status"] = PROVJERA; it["note"] = "Slično postojećem: " + ", ".join(f"{e['name']} ({e['id']})" for e in sim[:3]) + ". Nije dodan; potvrdite ako je zaista nova osoba."; continue
        # ---- nov radnik
        if given is not None: no = given
        else:
            while nxt in used: nxt += 1
            no = nxt
        used.add(no); nxt = max(nxt, no + 1); it["device_no"] = no; it["id"] = f"IDSS-{no:03d}"
        it["note"] = "Novi radnik." + (" ID iz liste je slobodan." if given is not None else "")
    return items

def summarize(items):
    c = {}
    for it in items: c[it["status"]] = c.get(it["status"], 0) + 1
    return c

def apply_roster(db, items, accept=(), update_contacts=False, source=""):
    """Primjenjuje pregled. accept = brojevi redova (item['row']) sumnjivih stavki (PROVJERA/REAKTIVIRATI) koje je direktor ODOBRIO.
    Sve u jednoj transakciji; greška = ništa nije promijenjeno. Vraća izvještaj."""
    accept = set(accept)
    todo_new = [it for it in items if it["status"] == NOVI or (it["status"] == PROVJERA and it["row"] in accept)]
    todo_react = [it for it in items if it["status"] == REAKT and it["row"] in accept]
    todo_upd = [it for it in items if it["status"] in (POSTOJI, REAKT) and update_contacts and it["diffs"]]
    if not (todo_new or todo_react or todo_upd): raise AppError("Nema ničega za primjenu (nema novih radnika niti odobrenih izmjena).")
    backup = db.backup(); report = {"dodani": [], "reaktivirani": [], "azurirani": [], "preskoceno": 0, "backup": backup}
    try:
        used = db.used_numbers()
        for it in todo_new:
            no = it["device_no"]
            if it["status"] == PROVJERA or no is None or no in used or any(name_key(e["name"]) == name_key(it["name"]) for e in db.employees(False)):
                if any(name_key(e["name"]) == name_key(it["name"]) for e in db.employees(False)): raise AppError(f"Radnik '{it['name']}' u međuvremenu već postoji.")
                no = db.next_device_no()
            eid = db._insert_employee(it["name"], it["position"], it["email"], it["phone"], it["weekly"], no, it["dept"], it["authority"], commit=False)
            used.add(no); report["dodani"].append((eid, it["name"]))
        for it in todo_react:
            db.c.execute("UPDATE employees SET active=1 WHERE id=?", (it["id"],)); db.log("radnik_reaktiviran", f"{it['id']} {it['name']}", commit=False); report["reaktivirani"].append((it["id"], it["name"]))
        for it in todo_upd:
            sets = {k: v[1] for k, v in it["diffs"].items()}
            db.c.execute("UPDATE employees SET " + ",".join(f"{k}=?" for k in sets) + " WHERE id=?", (*sets.values(), it["id"]))
            db.log("radnik_kontakt_azuriran", f"{it['id']} " + "; ".join(f"{k}: '{v[0]}' -> '{v[1]}'" for k, v in it["diffs"].items()), commit=False); report["azurirani"].append((it["id"], it["name"]))
        report["preskoceno"] = len(items) - len(todo_new) - len(todo_react) - len(todo_upd)
        db.set_raw("zadnje_dodani", ",".join(e for e, _ in report["dodani"])); db.log("uvoz_liste_radnika", f"{os.path.basename(source)} dodano={len(report['dodani'])} reaktivirano={len(report['reaktivirani'])} azurirano={len(report['azurirani'])}", commit=False)
        db.c.commit()
    except Exception:
        db.c.rollback(); raise
    return report

def make_template(path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = Workbook(); ws = wb.active; ws.title = "Zaposlenici"; ws.append(HEADERS)
    for c in ws[1]: c.font = Font(name="Arial", bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="035EA1"); c.alignment = Alignment(wrap_text=True, vertical="center")
    for col, w in zip("ABCDEFGH", (28, 24, 30, 18, 16, 26, 22, 24)): ws.column_dimensions[col].width = w
    ws.row_dimensions[1].height = 44; ws.freeze_panes = "A2"
    u = wb.create_sheet("Upute")
    for line in ["Upišite SAMO nove radnike (jedan red po osobi); radnici koji već postoje ostaju netaknuti.",
                 "Obavezno je samo ime i prezime. ID ostavite prazan: aplikacija dodjeljuje prvi slobodan broj i nikad ne ponavlja postojeći.",
                 "Datum rođenja i privatni e-mail se NE uvoze. Ime na uređaju se pravi bez č, ć, š, ž, đ i može imati najviše 32 znaka.",
                 "Prije primjene aplikacija prikazuje pregled; sumnjive redove (slično ime postojećeg radnika, zauzet ID) morate odobriti ručno."]:
        u.append([line])
    u.column_dimensions["A"].width = 130
    wb.save(path); return path
