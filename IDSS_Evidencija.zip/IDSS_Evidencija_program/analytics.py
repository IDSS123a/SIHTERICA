# -*- coding: utf-8 -*-
"""Podaci za nadzornu ploču i grafikone (čista logika, bez grafike)."""
import calendar, datetime as dt
import core, theme as T

def overview(db, y, m, today=None):
    today = today or dt.date.today(); ndays = calendar.monthrange(y, m)[1]; hol = db.holidays()
    emps = db.employees(); wd = {d.isoformat() for d in core.workdays(db, y, m)}
    labels, hours, colors, tips = [], [], [], []
    present = [0] * ndays; anom = [0] * ndays
    groups = {"Uredno": (T.BLUE, []), "Korigirano": (T.YELLOW, []), "Anomalija": (T.RED, []), "Neradni dan": (T.BLACK, [])}
    status = {"Uredno": 0, "Korigirano": 0, "Anomalija": 0, "Radni dan bez otiska": 0, "Odsustvo": 0}
    ranges = []; tot_hours = 0.0; with_punches = 0
    h = lambda s: core._mins(s) / 60
    for e in emps:
        recs = core.day_records(db, e["id"], y, m); absd = {a["day"] for a in db.absences(e["id"], y, m)}
        em, ndays_ok, n_anom, n_corr, starts, ends = 0, 0, 0, 0, [], []
        for day, r in recs.items():
            d = dt.date.fromisoformat(day); present[d.day - 1] += 1 if r["times"] else 0
            fin = r["final"]; nonwork = day not in wd; tip = f"{e['name']}\n{d:%d.%m.%Y.} · " + " ".join(r["times"])
            if not r["resolved"]:
                n_anom += 1; anom[d.day - 1] += 1; status["Anomalija"] += 1
                if len(r["times"]) >= 2: groups["Anomalija"][1].append((h(r["times"][0]), h(r["times"][-1]), tip + "\n" + (r["flag"] or "")))
                continue
            if fin.get("start") and fin.get("end"):
                hh = core.day_minutes(fin) or 0; em += hh; ndays_ok += 1; starts.append(h(fin["start"])); ends.append(h(fin["end"]))
                g = "Neradni dan" if nonwork else ("Korigirano" if r["corrected"] else "Uredno")
                groups[g][1].append((h(fin["start"]), h(fin["end"]), tip + f"\n{core.fmt_min(hh)} h"))
                if r["corrected"]: n_corr += 1; status["Korigirano"] += 1
                elif not nonwork: status["Uredno"] += 1
        status["Odsustvo"] += len(absd)
        status["Radni dan bez otiska"] += sum(1 for dd in wd if dt.date.fromisoformat(dd) < today and dd not in recs and dd not in absd)
        if recs: with_punches += 1
        tot_hours += em
        labels.append(e["id"][5:]); hours.append(round(em / 60, 2))
        colors.append(T.RED if n_anom else (T.YELLOW if n_corr else T.BLUE))
        tips.append(f"{e['name']}\n{core.fmt_min(em) or '0:00'} h · {ndays_ok} dana" + (f"\n{n_anom} dana za provjeru" if n_anom else "") + (f"\n{n_corr} korigiranih" if n_corr else ""))
        if starts: ranges.append((f"{e['id'][5:]} {e['name'][:16]}", sum(starts) / len(starts), sum(ends) / len(ends),
                                  f"{e['name']}\nprosječan dolazak {int(sum(starts)/len(starts)):02d}:{int(round((sum(starts)/len(starts)%1)*60))%60:02d}"))
    daily_tips = [f"{dt.date(y, m, i + 1):%d.%m.}: prisutno {present[i]}, anomalija {anom[i]}" for i in range(ndays)]
    return {"kpi": {"radnika": len(emps), "s_otiscima": with_punches, "sati": core.fmt_min(tot_hours) or "0:00",
                    "anomalije": status["Anomalija"], "bez_otiska": status["Radni dan bez otiska"]},
            "hours": {"labels": labels, "values": hours, "colors": colors, "tips": tips},
            "daily": {"labels": [str(i) for i in range(1, ndays + 1)], "present": present, "anomaly": anom, "tips": daily_tips},
            "scatter": [(n, c, p) for n, (c, p) in groups.items()],
            "status": [("Uredno", status["Uredno"], T.BLUE), ("Korigirano", status["Korigirano"], T.YELLOW), ("Anomalija", status["Anomalija"], T.RED),
                       ("Radni dan bez otiska", status["Radni dan bez otiska"], T.WHITE), ("Odsustvo", status["Odsustvo"], T.BLACK)],
            "ranges": ranges}

def employee_daily(db, emp, y, m):
    """Dnevni sati jednog radnika za grafikon u 'Pregledu': (oznake, vrijednosti, boje, tooltipovi)."""
    ndays = calendar.monthrange(y, m)[1]; recs = core.day_records(db, emp, y, m); vals, cols, tips = [], [], []
    for i in range(1, ndays + 1):
        d = dt.date(y, m, i); r = recs.get(d.isoformat())
        if not r: vals.append(0); cols.append(T.BLUE); tips.append(f"{d:%d.%m.} {core.DANI[d.weekday()]}: nema otisaka"); continue
        if not r["resolved"]: vals.append(0.4); cols.append(T.RED); tips.append(f"{d:%d.%m.}: ANOMALIJA – {r['flag']}"); continue
        mm = core.day_minutes(r["final"]) or 0
        vals.append(round(mm / 60, 2)); cols.append(T.YELLOW if r["corrected"] else T.BLUE); tips.append(f"{d:%d.%m.} {core.DANI[d.weekday()]}: {core.fmt_min(mm)} h" + (" (korigirano)" if r["corrected"] else ""))
    return [str(i) for i in range(1, ndays + 1)], vals, cols, tips
