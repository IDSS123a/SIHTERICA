# -*- coding: utf-8 -*-
"""Grafikoni bez vanjskih biblioteka. Svaki grafikon je 'scena' (liste jednostavnih oblika) koja se crta u Tkinteru
(aplikacija) ili u PNG preko Pillow-a (provjera izgleda u testovima). Samo palete: crna, žuta, plava, crvena, bijela."""
import math
import theme as T

NODATA = "Nema podataka za prikaz"

class Scene:
    def __init__(self, w, h, bg=T.WHITE):
        self.w, self.h, self.bg = w, h, bg; self.items = []; self.hits = []
    def rect(self, x0, y0, x1, y1, fill=None, outline=None, width=1): self.items.append(("rect", x0, y0, x1, y1, fill, outline, width))
    def line(self, x0, y0, x1, y1, color=T.LINE, width=1, dash=False): self.items.append(("line", [(x0, y0), (x1, y1)], color, width, dash))
    def polyline(self, pts, color, width=2): self.items.append(("line", list(pts), color, width, False))
    def poly(self, pts, fill=None, outline=None): self.items.append(("poly", list(pts), fill, outline))
    def oval(self, x, y, r, fill=None, outline=None, width=1): self.items.append(("oval", x, y, r, fill, outline, width))
    def text(self, x, y, s, color=T.TEXT, size=9, bold=False, anchor="w"): self.items.append(("text", x, y, str(s), color, size, bold, anchor))
    def hit(self, x0, y0, x1, y1, tip): self.hits.append((min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1), tip))
    def hit_at(self, x, y):
        for x0, y0, x1, y1, tip in reversed(self.hits):
            if x0 <= x <= x1 and y0 <= y <= y1: return tip
        return None

def nice_ticks(vmax, n=5):
    if vmax <= 0: return [0, 1]
    raw = vmax / n; mag = 10 ** math.floor(math.log10(raw)); step = mag
    for m in (1, 2, 2.5, 5, 10):
        step = m * mag
        if raw <= step: break
    top = math.ceil(vmax / step - 1e-9) * step
    return [round(i * step, 6) for i in range(int(round(top / step)) + 1)]

def fmt_hours(v): return f"{int(v):02d}:{int(round((v - int(v)) * 60)) % 60:02d}"
def fmt_num(v): return f"{v:g}"

def _frame(sc, title, subtitle=None):
    sc.text(16, 18, title, T.TEXT, 11, True, "w")
    if subtitle: sc.text(16, 36, subtitle, T.MUTED, 8, False, "w")

def _empty(sc):
    sc.text(sc.w / 2, sc.h / 2, NODATA, T.MUTED, 10, False, "center"); return sc

# ------------------------------------------------------------------ stubičasti grafikon
def bar_chart(w, h, labels, values, title, subtitle=None, colors=None, tips=None, fmt=fmt_num, unit="", legend=None):
    sc = Scene(w, h); _frame(sc, title, subtitle)
    if not values or max(values) <= 0 and not any(values): return _empty(sc)
    L, R, Tp, B = 46, 16, 52 if subtitle else 40, 30
    x0, x1, y0, y1 = L, w - R, Tp, h - B
    ticks = nice_ticks(max(values)); top = ticks[-1]
    for tk in ticks:
        y = y1 - (y1 - y0) * tk / top
        sc.line(x0, y, x1, y, T.LINE, 1); sc.text(x0 - 6, y, fmt(tk), T.MUTED, 8, False, "e")
    sc.line(x0, y1, x1, y1, T.TEXT, 1)
    n = len(values); slot = (x1 - x0) / n; bw = max(2, slot * 0.68)
    step = max(1, int(math.ceil(24 / slot)))
    for i, v in enumerate(values):
        cx = x0 + slot * (i + .5); bh = (y1 - y0) * v / top; col = (colors[i] if colors else T.BLUE)
        if bh > 0: sc.rect(cx - bw / 2, y1 - bh, cx + bw / 2, y1, col, None)
        if tips: sc.hit(cx - slot / 2, y0, cx + slot / 2, y1, tips[i])
        if i % step == 0: sc.text(cx, y1 + 14, labels[i], T.MUTED, 8, False, "center")
        if slot >= 34 and v > 0: sc.text(cx, y1 - bh - 8, fmt(v) + unit, T.TEXT, 8, True, "center")
    if legend: _legend(sc, legend, w - R, 18)
    return sc

def _legend(sc, items, x_right, y, left=None):
    if left is not None:                      # raspored slijeva nadesno u zasebnom redu
        x = left
        for name, col in items:
            sc.rect(x, y - 5, x + 10, y + 5, col, T.TEXT if col in (T.YELLOW, T.WHITE) else None); sc.text(x + 14, y, name, T.MUTED, 8, False, "w"); x += 14 + 6.2 * len(name) + 16
        return
    x = x_right
    for name, col in reversed(items):
        tw = 7 * len(name) * 0.95 + 6; x -= tw
        sc.text(x + 14, y, name, T.MUTED, 8, False, "w")
        sc.rect(x, y - 5, x + 10, y + 5, col, T.TEXT if col == T.YELLOW else None); x -= 14

# ------------------------------------------------------------------ linijski grafikon
def line_chart(w, h, labels, series, title, subtitle=None, fmt=fmt_num, tips=None):
    """series = [(naziv, vrijednosti, boja)]"""
    sc = Scene(w, h); _frame(sc, title, subtitle)
    allv = [v for _, vals, _ in series for v in vals]
    if not allv or max(allv) <= 0: return _empty(sc)
    L, R, Tp, B = 46, 16, 52 if subtitle else 40, 30
    x0, x1, y0, y1 = L, w - R, Tp, h - B
    ticks = nice_ticks(max(allv)); top = ticks[-1]
    for tk in ticks:
        y = y1 - (y1 - y0) * tk / top; sc.line(x0, y, x1, y, T.LINE, 1); sc.text(x0 - 6, y, fmt(tk), T.MUTED, 8, False, "e")
    sc.line(x0, y1, x1, y1, T.TEXT, 1)
    n = len(labels); slot = (x1 - x0) / max(1, n); step = max(1, int(math.ceil(26 / slot)))
    xs = [x0 + slot * (i + .5) for i in range(n)]
    for i, lab in enumerate(labels):
        if i % step == 0: sc.text(xs[i], y1 + 14, lab, T.MUTED, 8, False, "center")
    for name, vals, col in series:
        pts = [(xs[i], y1 - (y1 - y0) * v / top) for i, v in enumerate(vals)]
        sc.polyline(pts, col, 2.5)
        for i, (px, py) in enumerate(pts): sc.oval(px, py, 3.5, col, T.WHITE, 1)
    if tips:
        for i in range(n): sc.hit(xs[i] - slot / 2, y0, xs[i] + slot / 2, y1, tips[i])
    if len(series) > 1: _legend(sc, [(nm, c) for nm, _, c in series], w - R, 18)
    return sc

# ------------------------------------------------------------------ raspršeni grafikon (četiri grupe bodova)
def scatter_chart(w, h, groups, title, subtitle=None, xlabel="", ylabel=""):
    """groups = [(naziv, boja, [(x_sati, y_sati, tooltip)])]"""
    sc = Scene(w, h); _frame(sc, title, subtitle)
    pts = [p for _, _, ps in groups for p in ps]
    if not pts: return _empty(sc)
    L, R, Tp, B = 56, 16, 84 if subtitle else 70, 40
    x0, x1, y0, y1 = L, w - R, Tp, h - B
    xmin = max(0, math.floor(min(p[0] for p in pts)) - 1); xmax = min(24, math.ceil(max(p[0] for p in pts)) + 1)
    ymin = max(0, math.floor(min(p[1] for p in pts)) - 1); ymax = min(24, math.ceil(max(p[1] for p in pts)) + 1)
    if xmax - xmin < 2: xmax = xmin + 2
    if ymax - ymin < 2: ymax = ymin + 2
    sx = lambda v: x0 + (x1 - x0) * (v - xmin) / (xmax - xmin); sy = lambda v: y1 - (y1 - y0) * (v - ymin) / (ymax - ymin)
    stx = max(1, math.ceil((xmax - xmin) / 8)); sty = max(1, math.ceil((ymax - ymin) / 6))
    v = xmin
    while v <= xmax: sc.line(sx(v), y0, sx(v), y1, T.LINE, 1); sc.text(sx(v), y1 + 14, fmt_hours(v), T.MUTED, 8, False, "center"); v += stx
    v = ymin
    while v <= ymax: sc.line(x0, sy(v), x1, sy(v), T.LINE, 1); sc.text(x0 - 6, sy(v), fmt_hours(v), T.MUTED, 8, False, "e"); v += sty
    sc.line(x0, y1, x1, y1, T.TEXT, 1); sc.line(x0, y0, x0, y1, T.TEXT, 1)
    if xlabel: sc.text((x0 + x1) / 2, h - 8, xlabel, T.MUTED, 8, False, "center")
    if ylabel: sc.text(16, y0 - 8, ylabel, T.MUTED, 8, False, "w")
    for name, col, ps in groups:
        for x, y, tip in ps:
            px, py = sx(x), sy(y)
            sc.oval(px, py, 5, col, T.BLACK if col in (T.YELLOW, T.WHITE) else T.WHITE, 1.2); sc.hit(px - 7, py - 7, px + 7, py + 7, tip)
    _legend(sc, [(f"{nm} ({len(ps)})", col) for nm, col, ps in groups], 0, 58, left=16)
    return sc

# ------------------------------------------------------------------ kružni (prsten) grafikon
def donut_chart(w, h, parts, title, subtitle=None, center_caption=""):
    """parts = [(naziv, vrijednost, boja)]"""
    sc = Scene(w, h); _frame(sc, title, subtitle)
    tot = sum(v for _, v, _ in parts)
    if tot <= 0: return _empty(sc)
    top = 56 if subtitle else 44
    R = min((h - top - 14) / 2, (w * 0.46) / 2); r = R * 0.62; cx = 16 + R + 6; cy = top + (h - top) / 2 - 2
    a0 = -math.pi / 2
    for name, v, col in parts:
        if v <= 0: continue
        a1 = a0 + 2 * math.pi * v / tot; steps = max(2, int(60 * (a1 - a0) / (2 * math.pi)) + 2)
        outer = [(cx + R * math.cos(a0 + (a1 - a0) * k / steps), cy + R * math.sin(a0 + (a1 - a0) * k / steps)) for k in range(steps + 1)]
        inner = [(cx + r * math.cos(a1 - (a1 - a0) * k / steps), cy + r * math.sin(a1 - (a1 - a0) * k / steps)) for k in range(steps + 1)]
        sc.poly(outer + inner, col, T.WHITE if col != T.WHITE else T.BLACK)
        mid = (a0 + a1) / 2; sc.hit(cx + (R + r) / 2 * math.cos(mid) - 14, cy + (R + r) / 2 * math.sin(mid) - 14, cx + (R + r) / 2 * math.cos(mid) + 14, cy + (R + r) / 2 * math.sin(mid) + 14, f"{name}: {v:g} ({100 * v / tot:.0f}%)")
        a0 = a1
    sc.text(cx, cy - 6, f"{tot:g}", T.TEXT, 18, True, "center"); sc.text(cx, cy + 14, center_caption, T.MUTED, 8, False, "center")
    lx = cx + R + 28; ly = top + 8
    for name, v, col in parts:
        sc.rect(lx, ly - 6, lx + 12, ly + 6, col, T.BLACK if col in (T.YELLOW, T.WHITE) else None)
        sc.text(lx + 20, ly, f"{name}", T.TEXT, 9, False, "w"); sc.text(w - 16, ly, f"{v:g}", T.TEXT, 9, True, "e"); ly += 22
    return sc

# ------------------------------------------------------------------ raspon (od-do) po radniku
def range_chart(w, h, rows, title, subtitle=None):
    """rows = [(oznaka, od_sati, do_sati, tooltip)] – plutajuće trake"""
    sc = Scene(w, h); _frame(sc, title, subtitle)
    if not rows: return _empty(sc)
    L, R, Tp, B = 120, 16, 58 if subtitle else 46, 26
    x0, x1, y0, y1 = L, w - R, Tp, h - B
    xmin = max(0, math.floor(min(r[1] for r in rows)) - 1); xmax = min(24, math.ceil(max(r[2] for r in rows)) + 1)
    if xmax - xmin < 2: xmax = xmin + 2
    sx = lambda v: x0 + (x1 - x0) * (v - xmin) / (xmax - xmin)
    st = max(1, math.ceil((xmax - xmin) / 8)); v = xmin
    while v <= xmax: sc.line(sx(v), y0, sx(v), y1, T.LINE, 1); sc.text(sx(v), y1 + 13, fmt_hours(v), T.MUTED, 8, False, "center"); v += st
    n = len(rows); slot = (y1 - y0) / n; bh = max(3, min(14, slot * .62))
    for i, (lab, a, b, tip) in enumerate(rows):
        cy = y0 + slot * (i + .5)
        sc.text(x0 - 8, cy, lab, T.TEXT, 8, False, "e")
        sc.rect(sx(a), cy - bh / 2, max(sx(b), sx(a) + 2), cy + bh / 2, T.BLUE, None)
        sc.oval(sx(a), cy, bh / 2 + 1, T.YELLOW, T.BLACK, 1); sc.hit(x0, cy - slot / 2, x1, cy + slot / 2, tip)
    sc.line(x0, y0, x0, y1, T.TEXT, 1)
    _legend(sc, [("dolazak", T.YELLOW), ("raspon boravka", T.BLUE)], w - R, 18)
    return sc

# ------------------------------------------------------------------ renderi
def draw_tk(canvas, sc, font_family):
    canvas.delete("all"); canvas.configure(bg=sc.bg)
    anch = {"w": "w", "e": "e", "center": "center", "n": "n", "s": "s"}
    for it in sc.items:
        k = it[0]
        if k == "rect": _, x0, y0, x1, y1, fill, out, wd = it; canvas.create_rectangle(x0, y0, x1, y1, fill=fill or "", outline=out or "", width=wd if out else 0)
        elif k == "line":
            _, pts, col, wd, dash = it; flat = [c for p in pts for c in p]
            canvas.create_line(*flat, fill=col, width=wd, dash=(3, 3) if dash else None, capstyle="round", joinstyle="round")
        elif k == "poly": _, pts, fill, out = it; canvas.create_polygon([c for p in pts for c in p], fill=fill or "", outline=out or "", width=1)
        elif k == "oval": _, x, y, r, fill, out, wd = it; canvas.create_oval(x - r, y - r, x + r, y + r, fill=fill or "", outline=out or "", width=wd)
        elif k == "text":
            _, x, y, s, col, size, bold, anchor = it
            canvas.create_text(x, y, text=s, fill=col, font=(font_family, size, "bold" if bold else "normal"), anchor=anch.get(anchor, "w"))

def render_pil(sc, path, scale=1):
    from PIL import Image, ImageDraw, ImageFont
    reg, bld = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    img = Image.new("RGB", (int(sc.w * scale), int(sc.h * scale)), sc.bg); d = ImageDraw.Draw(img)
    S = lambda v: v * scale; amap = {"w": "lm", "e": "rm", "center": "mm", "n": "mt", "s": "ms"}
    for it in sc.items:
        k = it[0]
        if k == "rect": _, x0, y0, x1, y1, fill, out, wd = it; d.rectangle([S(x0), S(y0), S(x1), S(y1)], fill=fill, outline=out, width=int(wd * scale) if out else 0)
        elif k == "line": _, pts, col, wd, dash = it; d.line([(S(x), S(y)) for x, y in pts], fill=col, width=max(1, int(wd * scale)), joint="curve")
        elif k == "poly": _, pts, fill, out = it; d.polygon([(S(x), S(y)) for x, y in pts], fill=fill, outline=out)
        elif k == "oval": _, x, y, r, fill, out, wd = it; d.ellipse([S(x - r), S(y - r), S(x + r), S(y + r)], fill=fill, outline=out, width=max(1, int(wd * scale)))
        elif k == "text":
            _, x, y, s, col, size, bold, anchor = it
            d.text((S(x), S(y)), s, fill=col, font=ImageFont.truetype(bld if bold else reg, int(size * 1.33 * scale)), anchor=amap.get(anchor, "lm"))
    img.save(path); return path
