# -*- coding: utf-8 -*-
"""IDSS Evidencija radnog vremena - jezgra (bez grafičkog sučelja).
Sva logika je ovdje da se može testirati. Izvorni otisci se nikad ne mijenjaju."""
import sqlite3, hashlib, os, re, shutil, subprocess, sys, datetime as dt, secrets, hmac, time, calendar, unicodedata

MJESECI = ["Januar","Februar","Mart","April","Maj","Juni","Juli","August",
           "Septembar","Oktobar","Novembar","Decembar"]   # točno kao u obrascu (šihtarica)
DANI = ["Ponedjeljak","Utorak","Srijeda","Četvrtak","Petak","Subota","Nedjelja"]
VRSTE_ODSUSTVA = {   # vrsta -> kolona u šihtarici
    "prekovremeni": "I", "terenski": "J", "pripravnost": "K", "godisnji": "L",
    "bolovanje": "M", "praznik": "N", "sedmicni": "O", "drugo": "P"}
NAZIVI_VRSTA = {"prekovremeni":"Prekovremeni sati","terenski":"Terenski rad","pripravnost":"Pripravnost",
    "godisnji":"Godišnji odmor","bolovanje":"Bolovanje","praznik":"Praznik / neradni dan",
    "sedmicni":"Sedmični odmor","drugo":"Drugo odsustvo"}
SHEET_TEMPLATE = "IDSS - šihtarica"
MIN_RAZMAK_MIN = 3     # razmak kraći od 3 min = duplikat (kao 'Repeated Verification' uređaja; podesivo u Postavkama)

class AppError(Exception):
    pass

# Odjeli na uređaju (1-16). Nazivi samo ASCII (uređaj ne podržava dijakritike).
DEPT_NAMES = {1: "Uprava", 2: "Nastava njemacki", 3: "Nastava ostalo", 4: "Predskolsko", 5: "Tehnicko osoblje", 6: "Higijena"}
def dept_for_position(pos):
    p = (pos or "").strip().lower()
    if p in ("director", "administration", "secretary", "finance", "pedagogy", "psihology", "psychology", "teaching and learning advisor"): return 1
    if p == "german": return 2
    if p == "preschool": return 4
    if p == "maintenance": return 5
    if p == "internal hygiene": return 6
    return 3

# ---------------------------------------------------------------- pretvorbe
def dec_to_hhmm(h):
    if h is None or h == "": return ""
    mins = int(round(float(h) * 60))
    return f"{mins // 60}:{mins % 60:02d}"

def hhmm_to_dec(s):
    s = str(s).strip()
    m = re.fullmatch(r"(\d{1,3}):([0-5]\d)", s)
    if not m: raise AppError(f"Neispravan oblik vremena '{s}' (očekujem hh:mm).")
    return round(int(m[1]) + int(m[2]) / 60, 2)

def norm_hhmm(s):
    """'8:5' nije dozvoljeno; '8:05' -> '08:05'. Čuva se UVIJEK u obliku HH:MM."""
    t = parse_time(s); return f"{t.hour:02d}:{t.minute:02d}"

def parse_time(s):
    m = re.fullmatch(r"([01]?\d|2[0-3]):([0-5]\d)", str(s).strip())
    if not m: raise AppError(f"Neispravno vrijeme '{s}' (očekujem hh:mm).")
    return dt.time(int(m[1]), int(m[2]))

def sat_formula(start, end, ps, pe):
    """Isto što i formula u koloni H obrasca: ROUND(MOD(E-D,1)*24 - pauza, 2)."""
    if not start or not end: return None
    def frac(t): return (t.hour * 60 + t.minute) / 1440.0
    v = ((frac(end) - frac(start)) % 1) * 24
    if ps and pe: v -= ((frac(pe) - frac(ps)) % 1) * 24
    return round(v, 2)

def translit(name):
    """Ime za uređaj (tipkovnica podržava engleska slova)."""
    t = {"č":"c","ć":"c","š":"s","ž":"z","đ":"dj","Č":"C","Ć":"C","Š":"S","Ž":"Z","Đ":"Dj"}
    return "".join(t.get(c, c) for c in unicodedata.normalize("NFC", name))

def name_key(name):
    """Ključ za poređenje imena: bez dijakritika, malim slovima, jedan razmak ('Davor  Mulalić' == 'davor mulalic')."""
    return re.sub(r"\s+", " ", translit(name or "")).strip().lower()

# ---------------------------------------------------------------- baza
SCHEMA = """
CREATE TABLE IF NOT EXISTS employees(id TEXT PRIMARY KEY, device_no INTEGER UNIQUE NOT NULL, name TEXT NOT NULL,
  position TEXT, email TEXT, phone TEXT, weekly_hours REAL, active INTEGER NOT NULL DEFAULT 1,
  dept INTEGER, authority INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sources(id INTEGER PRIMARY KEY, filename TEXT, sha256 TEXT UNIQUE, imported_at TEXT, n_new INTEGER, n_dup INTEGER);
CREATE TABLE IF NOT EXISTS punches(id INTEGER PRIMARY KEY, emp TEXT NOT NULL REFERENCES employees(id), ts TEXT NOT NULL,
  src INTEGER REFERENCES sources(id), UNIQUE(emp, ts));
CREATE TABLE IF NOT EXISTS corrections(id INTEGER PRIMARY KEY, emp TEXT NOT NULL, day TEXT NOT NULL, field TEXT NOT NULL,
  value TEXT NOT NULL, reason TEXT NOT NULL, at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS absences(id INTEGER PRIMARY KEY, emp TEXT NOT NULL, day TEXT NOT NULL, kind TEXT NOT NULL,
  hours REAL, note TEXT);
CREATE TABLE IF NOT EXISTS holidays(day TEXT PRIMARY KEY, name TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, at TEXT, action TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS device_ids_seen(no INTEGER PRIMARY KEY, name TEXT, seen_at TEXT);
CREATE TRIGGER IF NOT EXISTS emp_no_delete BEFORE DELETE ON employees BEGIN SELECT RAISE(ABORT, 'Radnici se ne brišu (samo deaktiviraju).'); END;
CREATE TRIGGER IF NOT EXISTS emp_no_idchange BEFORE UPDATE OF id, device_no ON employees
  WHEN NEW.id <> OLD.id OR NEW.device_no <> OLD.device_no BEGIN SELECT RAISE(ABORT, 'ID radnika se ne može mijenjati.'); END;
"""

class DB:
    def __init__(self, folder):
        self.folder = folder
        for sub in ("Podaci", "Arhiva_uvoza", "Rezervne_kopije", "Izvoz"):
            os.makedirs(os.path.join(folder, sub), exist_ok=True)
        self.path = os.path.join(folder, "Podaci", "idss_evidencija.db")
        self.c = sqlite3.connect(self.path)
        self.c.row_factory = sqlite3.Row
        self.c.execute("PRAGMA foreign_keys=ON")
        self.c.executescript(SCHEMA)
        cols = {r[1] for r in self.c.execute("PRAGMA table_info(employees)")}
        if "dept" not in cols: self.c.execute("ALTER TABLE employees ADD COLUMN dept INTEGER")
        if "authority" not in cols: self.c.execute("ALTER TABLE employees ADD COLUMN authority INTEGER NOT NULL DEFAULT 0")
        for k, v in (("odgovorno_lice", "Davor Mulalić"), ("naziv_ustanove", "IDSS"), ("min_razmak", "3"), ("sedmicno_u_obrazac", "0")):
            self.c.execute("INSERT OR IGNORE INTO settings VALUES(?,?)", (k, v))
        self.c.commit()
        self.apply_settings()

    def apply_settings(self):
        global MIN_RAZMAK_MIN
        try: MIN_RAZMAK_MIN = max(1, min(30, int(self.get("min_razmak", "3"))))
        except ValueError: MIN_RAZMAK_MIN = 3

    def set_raw(self, key, value):
        self.c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (key, value))
    def get(self, key, default=""):
        r = self.c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r[0] if r else default
    def set(self, key, value):
        self.c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (key, value)); self.c.commit()
        if not key.startswith("pass_") and key != "login_fails": self.log("postavka", f"{key}={value}")
        if key == "min_razmak": self.apply_settings()
    def log(self, action, detail="", commit=True):
        self.c.execute("INSERT INTO audit(at,action,detail) VALUES(?,?,?)",
                       (dt.datetime.now().isoformat(timespec="seconds"), action, detail))
        if commit: self.c.commit()
    def backup(self):
        self.c.commit()
        dst = os.path.join(self.folder, "Rezervne_kopije", "idss_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".db")
        b = sqlite3.connect(dst); self.c.backup(b); b.close(); return dst

    # --- šifra (PBKDF2); pristup aplikaciji
    def has_password(self): return bool(self.get("pass_hash"))
    def set_password(self, pw):
        if len(pw) < 8: raise AppError("Šifra mora imati najmanje 8 znakova.")
        salt = secrets.token_hex(16)
        h = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 300_000).hex()
        self.set("pass_salt", salt); self.set("pass_hash", h); self.log("šifra_promijenjena")
    def check_password(self, pw):
        fails = int(self.get("login_fails", "0"))
        if fails >= 3: time.sleep(min(2 * fails, 30))
        h = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(self.get("pass_salt")), 300_000).hex()
        ok = hmac.compare_digest(h, self.get("pass_hash"))
        self.set("login_fails", str(0 if ok else fails + 1))
        self.log("prijava_uspjesna" if ok else "prijava_neuspjesna")
        return ok

    # --- zaposlenici
    def employees(self, active_only=True):
        q = "SELECT * FROM employees" + (" WHERE active=1" if active_only else "") + " ORDER BY device_no"
        return [dict(r) for r in self.c.execute(q)]
    def employee(self, emp_id):
        r = self.c.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
        if not r: raise AppError(f"Nepoznat radnik {emp_id}.")
        return dict(r)
    def next_device_no(self):
        """Prvi broj koji nikad nije korišten: iznad svih radnika (i deaktiviranih) i svih ID-eva viđenih na uređaju."""
        m = max(self.c.execute("SELECT COALESCE(MAX(device_no),0) FROM employees").fetchone()[0],
                self.c.execute("SELECT COALESCE(MAX(no),0) FROM device_ids_seen").fetchone()[0])
        return m + 1
    def used_numbers(self):
        return {r[0] for r in self.c.execute("SELECT device_no FROM employees")} | {r[0] for r in self.c.execute("SELECT no FROM device_ids_seen")}
    def _insert_employee(self, name, position, email, phone, weekly_hours, device_no, dept, authority, commit=True):
        if device_no is None: device_no = self.next_device_no()
        if device_no in self.used_numbers(): raise AppError(f"ID {device_no} je već zauzet (radnik ili uređaj). Radnik nije dodan.")
        emp_id = f"IDSS-{device_no:03d}"
        if dept is None: dept = dept_for_position(position)
        if authority is None: authority = 1 if device_no == 1 else 0      # ID 1 = direktor = administrator uređaja
        self.c.execute("INSERT INTO employees(id,device_no,name,position,email,phone,weekly_hours,dept,authority) VALUES(?,?,?,?,?,?,?,?,?)",
                       (emp_id, device_no, name.strip(), position, email, phone, weekly_hours, dept, authority))
        self.log("radnik_dodan", f"{emp_id} {name.strip()}", commit=False)
        if commit: self.c.commit()
        return emp_id
    def add_employee(self, name, position="", email="", phone="", weekly_hours=None, device_no=None, dept=None, authority=None):
        key = name_key(name)
        for e in self.employees(False):
            if name_key(e["name"]) == key: raise AppError(f"Radnik '{e['name']}' već postoji ({e['id']}{'' if e['active'] else ', deaktiviran'}). Za povratak deaktiviranog radnika koristite 'Aktiviraj'.")
        return self._insert_employee(name, position, email, phone, weekly_hours, device_no, dept, authority)
    def update_employee(self, emp_id, **f):
        allowed = {"name","position","email","phone","weekly_hours","active","dept","authority"}
        for k in f:
            if k not in allowed: raise AppError("Nedozvoljeno polje " + k)
        sets = ",".join(f"{k}=?" for k in f)
        self.c.execute(f"UPDATE employees SET {sets} WHERE id=?", (*f.values(), emp_id)); self.c.commit()
        self.log("radnik_izmijenjen", f"{emp_id} {f}")
    def load_employees_xlsx(self, path):
        """Učitava IDSS_Zaposlenici_prijedlog.xlsx (list 'Zaposlenici')."""
        from openpyxl import load_workbook
        wbk = load_workbook(path, read_only=True, data_only=True)
        rows_ = list(wbk["Zaposlenici"].iter_rows(values_only=True)); wbk.close()
        n = 0
        for r in rows_[1:]:
            if not r or not r[0]: continue
            m = re.fullmatch(r"IDSS-(\d{3})", str(r[0]).strip())
            if not m: raise AppError(f"Neispravan ID '{r[0]}'.")
            if self.c.execute("SELECT 1 FROM employees WHERE id=?", (r[0],)).fetchone(): continue
            self._insert_employee(r[1], r[2] or "", r[3] or "", r[4] or "", None, int(m[1]), None, None); n += 1
        return n

    # --- praznici, odsustva, korekcije
    def add_holiday(self, day, name):
        dt.date.fromisoformat(day)
        self.c.execute("INSERT OR REPLACE INTO holidays VALUES(?,?)", (day, name)); self.c.commit(); self.log("praznik", f"{day} {name}")
    def holidays(self): return {r[0]: r[1] for r in self.c.execute("SELECT day,name FROM holidays")}
    def add_absence(self, emp, day, kind, hours, note=""):
        if kind not in VRSTE_ODSUSTVA: raise AppError("Nepoznata vrsta odsustva.")
        dt.date.fromisoformat(day)
        if kind != "drugo" and (hours is None or float(hours) < 0 or float(hours) > 24): raise AppError("Sati moraju biti između 0 i 24.")
        self.c.execute("INSERT INTO absences(emp,day,kind,hours,note) VALUES(?,?,?,?,?)", (emp, day, kind, hours, note)); self.c.commit()
        self.log("odsustvo", f"{emp} {day} {kind} {hours}")
    def delete_absence(self, aid): self.c.execute("DELETE FROM absences WHERE id=?", (aid,)); self.c.commit(); self.log("odsustvo_obrisano", str(aid))
    def absences(self, emp, y, m):
        p = f"{y:04d}-{m:02d}-"
        return [dict(r) for r in self.c.execute("SELECT * FROM absences WHERE emp=? AND day LIKE ? ORDER BY day,id", (emp, p + "%"))]
    def add_correction(self, emp, day, field, value, reason):
        if field not in ("start", "end", "ps", "pe"): raise AppError("Nepoznato polje korekcije.")
        if not reason.strip(): raise AppError("Razlog korekcije je obavezan (pravilnik traži pojašnjenje).")
        dt.date.fromisoformat(day)
        if value != "": value = norm_hhmm(value)
        self.c.execute("INSERT INTO corrections(emp,day,field,value,reason,at) VALUES(?,?,?,?,?,?)",
                       (emp, day, field, value, reason.strip(), dt.datetime.now().isoformat(timespec="seconds"))); self.c.commit()
        self.log("korekcija", f"{emp} {day} {field}={value!r} ({reason})")

# ---------------------------------------------------------------- obrada dana
def _mins(s):
    t = parse_time(s); return t.hour * 60 + t.minute

def fmt_min(m):
    if m is None: return ""
    m = int(round(m)); sign = "-" if m < 0 else ""; m = abs(m); return f"{sign}{m // 60}:{m % 60:02d}"

def day_minutes(final):
    """Tačan broj minuta rada (bez zaokruživanja), isti obračun kao formula obrasca."""
    if not (final.get("start") and final.get("end")): return None
    v = (_mins(final["end"]) - _mins(final["start"])) % 1440
    if final.get("ps") and final.get("pe"): v -= (_mins(final["pe"]) - _mins(final["ps"])) % 1440
    return v

def clean_times(times):
    """Sortira i izbacuje duplikate bliže od MIN_RAZMAK_MIN minuta."""
    out = []
    for t in sorted(set(times)):
        if out and _mins(t) - _mins(out[-1]) < MIN_RAZMAK_MIN: continue
        out.append(t)
    return out

def assign(times):
    """Pravilo: 2 otiska = početak/završetak; 4 = početak, početak pauze, završetak pauze, završetak.
    Sve drugo je anomalija i NE popunjava se nagađanjem."""
    t = clean_times(times); n = len(t)
    if n == 0: return {}, None
    if n == 2: return {"start": t[0], "end": t[1]}, None
    if n == 4: return {"start": t[0], "ps": t[1], "pe": t[2], "end": t[3]}, None
    return {}, {1: "samo jedan otisak", 3: "tri otiska"}.get(n, f"{n} otisaka") + " – potrebna provjera"

def day_records(db, emp, y, m):
    """dict dan(ISO) -> {times, auto, final, flag, resolved, corrected}"""
    p = f"{y:04d}-{m:02d}-"
    by = {}
    for r in db.c.execute("SELECT ts FROM punches WHERE emp=? AND ts LIKE ? ORDER BY ts", (emp, p + "%")):
        by.setdefault(r[0][:10], []).append(r[0][11:16])
    corr = {}
    for r in db.c.execute("SELECT day,field,value,reason FROM corrections WHERE emp=? AND day LIKE ? ORDER BY id", (emp, p + "%")):
        corr.setdefault(r["day"], {})[r["field"]] = (r["value"], r["reason"])
    out = {}
    for day in sorted(set(by) | set(corr)):
        auto, flag = assign(by.get(day, []))
        final = dict(auto)
        for f, (v, _) in corr.get(day, {}).items():
            if v == "": final.pop(f, None)
            else: final[f] = norm_hhmm(v)
        out[day] = {"times": clean_times(by.get(day, [])), "auto": auto, "final": final, "flag": flag,
                    "corrected": day in corr, "resolved": flag is None or day in corr,
                    "reasons": sorted({r for _, r in corr.get(day, {}).values()})}
    return out

def day_hours(final):
    g = lambda k: parse_time(final[k]) if final.get(k) else None
    return sat_formula(g("start"), g("end"), g("ps"), g("pe"))

# ---------------------------------------------------------------- statistika
def workdays(db, y, m):
    hol = db.holidays()
    return [d for d in (dt.date(y, m, i) for i in range(1, calendar.monthrange(y, m)[1] + 1))
            if d.weekday() < 5 and d.isoformat() not in hol]

def month_stats(db, emp, y, m, today=None):
    """Statistika u TAČNIM minutama (hh:mm). 'ukupno_sati_dec' je zbir dnevnih decimalnih vrijednosti kako ga daje šihtarica (zaokruženo po danu)."""
    today = today or dt.date.today()
    e = db.employee(emp); recs = day_records(db, emp, y, m); abs_ = db.absences(emp, y, m)
    abs_days = {a["day"] for a in abs_ if a["kind"] in ("godisnji", "bolovanje", "praznik", "sedmicni", "terenski", "drugo")}
    wd = workdays(db, y, m)
    complete = {d: r["final"] for d, r in recs.items() if r["final"].get("start") and r["final"].get("end")}
    mins = [day_minutes(f) for f in complete.values()]; total = sum(mins)
    starts = [_mins(r["final"]["start"]) for r in recs.values() if r["final"].get("start")]
    ends = [_mins(r["final"]["end"]) for r in recs.values() if r["final"].get("end")]
    missing = [d.isoformat() for d in wd if d < today and d.isoformat() not in recs and d.isoformat() not in abs_days]
    fmt = lambda x: f"{int(x) // 60:02d}:{int(x) % 60:02d}"
    st = {"radnik": e["name"], "id": emp, "radnih_dana_u_mjesecu": len(wd), "dana_sa_potpunim_otiscima": len(complete),
          "ukupno_sati": fmt_min(total) if mins else "0:00", "ukupno_min": total, "ukupno_sati_dec": round(sum(round(x / 60, 2) for x in mins), 2),
          "prosjek_sati_po_danu": fmt_min(total / len(mins)) if mins else "",
          "najduži_dan": fmt_min(max(mins)) if mins else "", "najkraći_dan": fmt_min(min(mins)) if mins else "",
          "prosječan_dolazak": fmt(sum(starts) / len(starts)) if starts else "",
          "prosječan_odlazak": fmt(sum(ends) / len(ends)) if ends else "",
          "najraniji_dolazak": fmt(min(starts)) if starts else "", "najkasniji_odlazak": fmt(max(ends)) if ends else "",
          "dana_s_anomalijom": sum(1 for r in recs.values() if not r["resolved"]),
          "dana_s_korekcijom": sum(1 for r in recs.values() if r["corrected"]),
          "radni_dani_bez_otiska": missing, "broj_dana_bez_otiska": len(missing)}
    for k in ("godisnji", "bolovanje", "praznik", "sedmicni", "terenski", "pripravnost", "prekovremeni"):
        st["sati_" + k] = round(sum(a["hours"] or 0 for a in abs_ if a["kind"] == k), 2)
    if e["weekly_hours"]:
        exp = e["weekly_hours"] * 60 / 5 * len(complete)
        st["ugovoreno_za_odrađene_dane"] = fmt_min(exp)
        st["razlika_prema_ugovorenom"] = ("+" if total >= exp else "-") + fmt_min(abs(total - exp))
    return st

def presence_on(db, day):
    """Ko je bio u zgradi određenog dana (prvi i posljednji otisak)."""
    rows = []
    for e in db.employees():
        t = clean_times([r[0][11:16] for r in db.c.execute("SELECT ts FROM punches WHERE emp=? AND ts LIKE ?", (e["id"], day + "%"))])
        rows.append({"id": e["id"], "radnik": e["name"], "prvi": t[0] if t else "", "posljednji": t[-1] if len(t) > 1 else "", "otisaka": len(t)})
    return rows

# ---------------------------------------------------------------- uvoz s uređaja
TIME_RE = re.compile(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?(?!\d)")
DATE_RES = [(re.compile(r"(\d{1,2})/(\d{1,2})/(\d{4})"), "dmy"), (re.compile(r"(\d{4})-(\d{2})-(\d{2})"), "ymd"),
            (re.compile(r"(\d{1,2})\.(\d{1,2})\.(\d{4})"), "dmy")]

def _find_date(text):
    for rx, order in DATE_RES:
        m = rx.search(text)
        if m:
            a, b, c = map(int, m.groups())
            try: return dt.date(c, b, a) if order == "dmy" else dt.date(a, b, c)
            except ValueError: return None
    return None

def _cell_text(v):
    if v is None: return ""
    if isinstance(v, dt.datetime): return v.strftime("%Y-%m-%d %H:%M")
    if isinstance(v, dt.time): return v.strftime("%H:%M")
    if isinstance(v, float) and 0 <= v < 1:      # Excel vrijeme kao razlomak dana
        mins = round(v * 1440); return f"{mins // 60}:{mins % 60:02d}"
    if isinstance(v, float) and v == int(v): return str(int(v))
    return str(v).strip()

def read_workbook(path):
    try: return _read_workbook(path)
    except AppError: raise
    except Exception as ex:
        raise AppError(f"Datoteka '{os.path.basename(path)}' se ne može pročitati kao Excel dokument ({type(ex).__name__}). "
                       "Provjerite da li je cijela datoteka kopirana s USB-a i da nije otvorena u drugom programu.")

def _read_xls_xlrd(path):
    import xlrd
    wb = xlrd.open_workbook(path); out = {}
    for sh in wb.sheets():
        rows = []
        for r in range(sh.nrows):
            row = []
            for c in range(sh.ncols):
                cell = sh.cell(r, c)
                if cell.ctype == xlrd.XL_CELL_DATE:
                    t = xlrd.xldate_as_tuple(cell.value, wb.datemode); row.append(dt.datetime(*t) if t[0] else dt.time(*t[3:]))
                elif cell.ctype in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK): row.append(None)
                else: row.append(cell.value)
            rows.append(row)
        out[sh.name] = rows
    return out

def _read_xls(path):
    """Čita .xls DVAMA neovisnim čitačima (ugrađeni + xlrd, ako je instaliran) i uspoređuje list Attendance Logs.
    Ako se ne slažu, uvoz se zaustavlja. Ako je dostupan samo jedan, koristi se on."""
    import xlsparse
    got, errs = [], []
    try: got.append(("ugrađeni", xlsparse.read_xls(path)))
    except Exception as ex: errs.append(f"ugrađeni čitač: {ex}")
    try: got.append(("xlrd", _read_xls_xlrd(path)))
    except ImportError: pass
    except Exception as ex: errs.append(f"xlrd: {ex}")
    if not got: raise AppError("Datoteka .xls se ne može pročitati (" + "; ".join(errs) + "). Provjerite da je cijela datoteka kopirana s USB-a.")
    if len(got) == 2:
        key = lambda d: next((n for n in d if n.strip().lower() == "attendance logs"), None)
        (n1, d1), (n2, d2) = got; k1, k2 = key(d1), key(d2)
        if k1 != k2: raise AppError("Dva neovisna čitača ne vide iste listove u datoteci; uvoz je zaustavljen radi sigurnosti.")
        if k1:
            norm = lambda rows: [[_cell_text(c) for c in r] for r in rows]
            a, b = norm(d1[k1]), norm(d2[k2]); w = max([len(r) for r in a + b] + [0])
            pad = lambda rows: [r + [""] * (w - len(r)) for r in rows]; ra, rb = pad(a), pad(b)
            while ra and not any(ra[-1]): ra.pop()
            while rb and not any(rb[-1]): rb.pop()
            if ra != rb: raise AppError("Dva neovisna čitača daju različit sadržaj lista Attendance Logs; uvoz je zaustavljen radi sigurnosti. Pošaljite mi datoteku.")
    return got[0][1]

def _read_workbook(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".xls": return _read_xls(path)
    if ext in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        res = {ws.title: [list(r) for r in ws.iter_rows(values_only=True)] for ws in wb}
        wb.close(); return res
    raise AppError("Podržane su samo .xls i .xlsx datoteke.")

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

def summary_ids(sheets):
    """Nezavisan popis radnika iz listova 'Attendance summary' i 'Schedule information sheet' (po jedan red za svakog radnika, ID u koloni A).
    Vraća {ID: broj_dana_prisustva ili None} ili None ako takvog lista nema/nije prepoznat."""
    found = None
    for key in ("attendance summary", "schedule information sheet"):
        name = next((n for n in sheets if n.strip().lower() == key), None)
        if not name: continue
        rows = sheets[name]; hdr = next((i for i, r in enumerate(rows) if r and _cell_text(r[0]) == "ID"), None)
        if hdr is None: continue
        ids = {}
        for r in rows[hdr + 1:]:
            t = _cell_text(r[0]) if r else ""
            if not re.fullmatch(r"\d{1,9}", t): continue
            actual = None
            if key == "attendance summary":
                for c in r[3:]:                                       # kolona 'Attend(Standard/Actual)', npr. '16/2'
                    m = re.fullmatch(r"(\d+)\s*/\s*(\d+)", _cell_text(c))
                    if m: actual = int(m[2]); break
            ids[int(t)] = actual
        found = ids if found is None else {**found, **{k: (ids[k] if ids[k] is not None else found.get(k)) for k in ids}}
    return found

def parse_logs(sheets, known_nos):
    """Čita list 'Attendance Logs' STVARNOG formata uređaja FA01H.
    Raspored (potvrđen na stvarnoj datoteci): red 2 = period 'dd/mm/yyyy ~ dd/mm/yyyy'; zatim blokovi po radniku:
      red 'ID | <broj> ... Name | <ime> ... Dept. | <odjel>', red s brojevima dana, red s kraticama dana (Mon..Sun),
      red s otiscima (jedna ćelija po danu, vremena odvojena novim redom).
    Vraća (otisci, info). Uz bilo kakvu nejasnoću PREKIDA uvoz; ništa se ne nagađa."""
    name = next((n for n in sheets if n.strip().lower() == "attendance logs"), None)
    if not name: raise AppError("U datoteci nema lista 'Attendance Logs'. Uvezite izvještaj 'All Report' ili 'Individual Report' s uređaja.")
    rows = sheets[name]; errors = []; res = []; info = {}; unknown = {}
    period = None
    for r in rows[:4]:
        ds = re.findall(r"\d{1,2}/\d{1,2}/\d{4}", " ".join(_cell_text(c) for c in r))
        if len(ds) >= 2: period = (_find_date(ds[0]), _find_date(ds[1])); break
    if not period or None in period or period[1] < period[0]: raise AppError("Nije pronađen ispravan period (Date) u datoteci.")
    n_days = (period[1] - period[0]).days + 1
    if n_days > 31: raise AppError(f"Period ima {n_days} dana; uređaj izvozi najviše 31 dan.")
    starts = [i for i, r in enumerate(rows) if r and _cell_text(r[0]) == "ID"]
    if not starts: raise AppError("Nisam pronašao nijedan blok radnika (red 'ID') u listu Attendance Logs. Pošaljite mi datoteku da prilagodim čitač.")
    labels = {"ID", "Name", "Dept."}
    def after(head, label):
        txt = [_cell_text(c) for c in head]
        if label not in txt: return ""
        for t in txt[txt.index(label) + 1:]:
            if t in labels: return ""
            if t: return t
        return ""
    for k, i in enumerate(starts):
        end = starts[k + 1] if k + 1 < len(starts) else len(rows)
        head = rows[i]; idtxt = after(head, "ID")
        if not re.fullmatch(r"\d{1,9}", idtxt): errors.append(f"Red {i+1}: ID radnika '{idtxt}' nije broj."); continue
        no = int(idtxt); info[no] = {"name": after(head, "Name"), "dept": after(head, "Dept.")}
        if no not in known_nos: unknown[no] = info[no]["name"]; errors.append(f"Red {i+1}: nepoznat ID uređaja {no} (ime na uređaju: '{info[no]['name']}'). Dodajte radnika s tim brojem u aplikaciju ili ga uklonite s uređaja."); continue
        if end - i < 3: errors.append(f"Red {i+1}: blok radnika {no} je nepotpun."); continue
        days_row, wk_row = rows[i + 1], rows[i + 2]
        for d in range(n_days):
            day = period[0] + dt.timedelta(d)
            got_n = _cell_text(days_row[d]) if d < len(days_row) else ""
            got_w = _cell_text(wk_row[d])[:3] if d < len(wk_row) else ""
            if got_n != str(day.day) or got_w.lower() != WEEKDAYS[day.weekday()].lower():
                errors.append(f"Radnik {no}: kolona {d+1} ima '{got_n} {got_w}', a očekivano je '{day.day} {WEEKDAYS[day.weekday()]}' (period se ne poklapa s kolonama)."); break
        else:
            for r_i in range(i + 3, end):
                row = rows[r_i]
                for j, cell in enumerate(row):
                    txt = _cell_text(cell)
                    if not txt: continue
                    if j >= n_days: errors.append(f"Red {r_i+1}, kolona {j+1}: podatak izvan perioda ('{txt[:20]}')."); continue
                    ts = TIME_RE.findall(txt)
                    if not ts or TIME_RE.sub("", txt).strip(): errors.append(f"Red {r_i+1}, kolona {j+1}: ne razumijem '{txt[:30]}'."); continue
                    day = (period[0] + dt.timedelta(j)).isoformat()
                    for h, mi in ts: res.append((no, f"{day}T{int(h):02d}:{mi}"))
    notes = []; summ = summary_ids(sheets)
    if summ is not None:                                                       # unakrsna provjera s popisom radnika iz sažetka uređaja
        days_by = {}
        for no, ts in res: days_by.setdefault(no, set()).add(ts[:10])
        for no, actual in sorted(summ.items()):
            if no not in info and (actual or 0) > 0:
                errors.append(f"Sažetak uređaja pokazuje da radnik {no} ima {actual} dana prisustva, ali u listu Attendance Logs nema njegovog bloka: uvoz bi izgubio podatke.")
            elif no not in info: notes.append(f"Radnik {no} je u sažetku uređaja bez otisaka u ovom periodu.")
            elif actual is not None and actual != len(days_by.get(no, ())):
                notes.append(f"ID {no}: sažetak uređaja navodi {actual} dana prisustva, a u otiscima je {len(days_by.get(no, ()))} dana s otiscima (uređaj ih može računati prema smjenama).")
        for no in sorted(set(info) - set(summ)): notes.append(f"ID {no} ima blok u Attendance Logs, ali ga nema u sažetku uređaja.")
    if summ:
        for no in summ:
            if no not in info and no not in known_nos: unknown.setdefault(no, "")
    if errors:
        ex = AppError("Uvoz je prekinut, ništa nije upisano:\n" + "\n".join(errors[:30])); ex.unknown = unknown; raise ex
    if not res: raise AppError("U datoteci nema nijednog otiska za odabrani period.")
    info["__beleške__"] = notes; info["__nepoznati__"] = unknown
    return res, info

def import_device_file(db, path):
    with open(path, "rb") as fh: h = hashlib.sha256(fh.read()).hexdigest()
    if db.c.execute("SELECT 1 FROM sources WHERE sha256=?", (h,)).fetchone():
        return {"novih": 0, "duplikata": 0, "poruka": "Ova datoteka je već ranije uvezena.", "upozorenja": []}
    nos = {e["device_no"]: e["id"] for e in db.employees(active_only=False)}
    def reserve(unknown):                                  # ID-evi koji postoje na uređaju, a nisu u aplikaciji, ne smiju se dodijeliti novim radnicima
        for no, nm in unknown.items(): db.c.execute("INSERT OR IGNORE INTO device_ids_seen(no,name,seen_at) VALUES(?,?,?)", (no, nm, dt.datetime.now().isoformat(timespec="seconds")))
        db.c.commit()
    try: punches, info = parse_logs(read_workbook(path), set(nos))
    except AppError as ex:
        if getattr(ex, "unknown", None): reserve(ex.unknown)
        raise
    reserve(info.pop("__nepoznati__", {}))
    warn = list(info.pop("__beleške__", []))
    n_blocks = len(info)
    for no, d in sorted(info.items()):
        e = db.employee(nos[no]) if no in nos else None
        if e and d["name"] and d["name"].strip().lower() != translit(e["name"]).lower():
            warn.append(f"ID {no}: na uređaju je ime '{d['name']}', u aplikaciji '{e['name']}' – uskladite učitavanjem obrasca za zaposlene.")
        if e and not e["active"]: warn.append(f"ID {no} ({e['name']}) je deaktiviran u aplikaciji, a ima otiske.")
    db.backup()
    arch = os.path.join(db.folder, "Arhiva_uvoza", dt.datetime.now().strftime("%Y%m%d_%H%M%S_") + os.path.basename(path))
    shutil.copy2(path, arch)
    new = dup = 0
    try:
        cur = db.c.execute("INSERT INTO sources(filename,sha256,imported_at,n_new,n_dup) VALUES(?,?,?,0,0)",
                           (os.path.basename(path), h, dt.datetime.now().isoformat(timespec="seconds")))
        sid = cur.lastrowid
        for no, ts in punches:
            try: db.c.execute("INSERT INTO punches(emp,ts,src) VALUES(?,?,?)", (nos[no], ts, sid)); new += 1
            except sqlite3.IntegrityError: dup += 1
        db.c.execute("UPDATE sources SET n_new=?, n_dup=? WHERE id=?", (new, dup, sid)); db.c.commit()
    except Exception:
        db.c.rollback(); raise
    db.log("uvoz", f"{os.path.basename(path)} novih={new} duplikata={dup} sha256={h[:12]}")
    return {"novih": new, "duplikata": dup, "poruka": "Uvoz završen.", "upozorenja": warn, "radnika_u_izvjestaju": n_blocks, "radnika_s_otiscima": len({no for no, _ in punches})}

# ---------------------------------------------------------------- izvoz šihtarice (format obrasca ostaje netaknut)
def _safe_title(s):
    """Naziv lista po Excelovim pravilima: najviše 31 znak, bez []:*?/\\, bez apostrofa/razmaka na početku i kraju."""
    t = re.sub(r"[\[\]:*?/\\]", "", s)[:31].strip(" '")
    return t or "List"

def _put(ws, coord, v):
    """Upis vrijednosti; tekst koji počinje s '=' ostaje TEKST (ne smije postati formula)."""
    ws[coord] = v
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@"): ws[coord].data_type = "s"

def unresolved(db, emp, y, m):
    return [d for d, r in day_records(db, emp, y, m).items() if not r["resolved"]]

DAY_COLS = {"D": "start", "E": "end", "F": "ps", "G": "pe"}
INPUT_CELLS = ("B3", "D3", "F3", "L3", "F4", "D4")      # polja zaglavlja koja aplikacija smije popuniti (ostalo je kanonski tekst obrasca)
FIRST_DAY_ROW, MAX_DAYS = 7, 31

def sheet_content(db, e, y, m):
    """JEDINI izvor istine o tome šta ide u list radnika: (zaglavlje {ćelija: vrijednost}, dani {red: {kolona: vrijednost}}).
    Koriste ga i izvoz i INSPEKCIJA, pa se ne mogu razilaziti."""
    head = {"B3": MJESECI[m - 1], "D3": y, "F3": e["name"], "L3": e["position"] or None, "F4": db.get("odgovorno_lice") or None}
    if e["weekly_hours"] and db.get("sedmicno_u_obrazac", "0") == "1": head["D4"] = e["weekly_hours"]
    days = {}
    for day, r in day_records(db, e["id"], y, m).items():
        if not r["resolved"]: continue
        cells = days.setdefault(6 + int(day[8:10]), {})
        for col, f in DAY_COLS.items():
            if r["final"].get(f): cells[col] = parse_time(r["final"][f])
        if r["reasons"]: cells["P"] = "Korekcija: " + "; ".join(r["reasons"])
    for a in db.absences(e["id"], y, m):
        cells = days.setdefault(6 + int(a["day"][8:10]), {}); col = VRSTE_ODSUSTVA[a["kind"]]
        def add_note(t):
            cells["P"] = f"{cells['P']}; {t}" if cells.get("P") else t
        if col == "P": add_note(a["note"] or NAZIVI_VRSTA["drugo"])
        else:
            cells[col] = round((cells.get(col) or 0) + (a["hours"] or 0), 2)
            if a["note"] and a["kind"] != "prekovremeni": add_note(a["note"])
    return head, days

def build_sheet(wb, tpl, e, y, m, db, title):
    """Pravi list radnika kao vjernu kopiju obrasca (sve osobine) i upisuje samo dozvoljene ćelije."""
    from openpyxl.worksheet.datavalidation import DataValidation
    ws = wb.copy_worksheet(tpl); ws.title = title
    ws.freeze_panes = tpl.freeze_panes; ws.print_title_rows = tpl.print_title_rows
    if tpl.print_area: ws.print_area = tpl.print_area
    ps, pt = ws.page_setup, tpl.page_setup
    for k in ("orientation", "paperSize", "fitToWidth", "fitToHeight", "scale", "horizontalDpi", "verticalDpi", "blackAndWhite", "draft", "pageOrder", "firstPageNumber", "useFirstPageNumber"):
        setattr(ps, k, getattr(pt, k))
    ws.sheet_properties.pageSetUpPr = tpl.sheet_properties.pageSetUpPr
    for k in ("left", "right", "top", "bottom", "header", "footer"): setattr(ws.page_margins, k, getattr(tpl.page_margins, k))
    for k in ("horizontalCentered", "verticalCentered", "headings", "gridLines"): setattr(ws.print_options, k, getattr(tpl.print_options, k))
    for part in ("oddHeader", "oddFooter", "evenHeader", "evenFooter", "firstHeader", "firstFooter"):
        for pos in ("left", "center", "right"):
            src, dst = getattr(getattr(tpl.HeaderFooter, part), pos), getattr(getattr(ws.HeaderFooter, part), pos)
            dst.text, dst.font, dst.size, dst.color = src.text, src.font, src.size, src.color
    ws.sheet_view.showGridLines = tpl.sheet_view.showGridLines; ws.sheet_view.zoomScale = tpl.sheet_view.zoomScale
    for dv in tpl.data_validations.dataValidation:
        nd = DataValidation(type=dv.type, operator=dv.operator, formula1=dv.formula1, formula2=dv.formula2, allow_blank=dv.allow_blank,
                            showErrorMessage=dv.showErrorMessage, showInputMessage=dv.showInputMessage, errorTitle=dv.errorTitle, error=dv.error,
                            promptTitle=dv.promptTitle, prompt=dv.prompt, errorStyle=dv.errorStyle)
        nd.sqref = dv.sqref; ws.add_data_validation(nd)
    head, days = sheet_content(db, e, y, m)
    for cell, v in head.items(): _put(ws, cell, v)
    for row, cells in days.items():
        for col, v in cells.items(): _put(ws, f"{col}{row}", v)
    return ws

def _safe_save(wb, path):
    try: wb.save(path)
    except OSError as ex:
        raise AppError(f"Datoteku nije moguće upisati: {path}\nMožda je otvorena u Excelu ili nemate pravo upisa u tu mapu. Zatvorite je i pokušajte ponovo. ({ex.strerror or ex})")

def export_sihtarica(db, template, out, y, m, emp_ids=None, allow_unresolved=False, verify=True, soffice_cmd=None):
    from openpyxl import load_workbook
    emps = [db.employee(i) for i in emp_ids] if emp_ids else db.employees()
    if not emps: raise AppError("Nema radnika za izvoz.")
    problems = {e["id"]: unresolved(db, e["id"], y, m) for e in emps}
    problems = {k: v for k, v in problems.items() if v}
    if problems and not allow_unresolved:
        raise AppError("Postoje nerazriješeni dani (neparan/neočekivan broj otisaka). Riješite ih korekcijom ili izvezite uz potvrdu:\n" +
                       "\n".join(f"{k}: {', '.join(v)}" for k, v in problems.items()))
    wb = load_workbook(template); tpl = wb[SHEET_TEMPLATE]; originals = list(wb.sheetnames); used = set()
    for e in emps:
        title = _safe_title(f"{e['id']} {e['name']}"); base, k = title, 1
        while title in used: k += 1; title = f"{base[:28]}~{k}"
        used.add(title); build_sheet(wb, tpl, e, y, m, db, title)
    for n in originals: del wb[n]
    wb.calculation.fullCalcOnLoad = True
    tmp = out + ".tmp.xlsx"; _safe_save(wb, tmp)
    if verify:
        import inspekcija
        rep = inspekcija.inspect_file(db, tmp, y, m, [e["id"] for e in emps], template=template, allow_unresolved=allow_unresolved, soffice_cmd=soffice_cmd)
        db.last_inspection = rep
        if not rep.ok:
            os.remove(tmp); raise AppError("Izvoz je ZAUSTAVLJEN jer inspekcija nije prošla (datoteka nije napravljena):\n" + rep.errors_text())
    try: os.replace(tmp, out)
    except OSError as ex:
        try: os.remove(tmp)
        except OSError: pass
        raise AppError(f"Datoteku nije moguće zamijeniti: {out}\nMožda je otvorena u Excelu. Zatvorite je i pokušajte ponovo. ({ex.strerror or ex})")
    db.log("izvoz_sihtarice", f"{MJESECI[m-1]} {y}, radnika={len(emps)}, {os.path.basename(out)}, inspekcija={'ok' if verify else 'preskocena'}")
    return out

# ---------------------------------------------------------------- obrazac za uređaj (Employee_Form)
DEVICE_TEMPLATE_SHEETS = ("Employee Form", "Attendance Rules Form")

def device_rows(db, only_ids=None):
    rows = []
    for e in db.employees():
        if only_ids is not None and e["id"] not in only_ids: continue
        dept = e["dept"] or dept_for_position(e["position"])
        rows.append((e["device_no"], translit(e["name"]).strip(), int(dept), int(e["authority"] or 0)))
    return rows

def validate_device_rows(rows):
    errs = []; seen = set()
    for no, nm, dept, auth in rows:
        if not 1 <= no <= 99999999: errs.append(f"ID {no}: broj mora biti između 1 i 99999999.")
        if no in seen: errs.append(f"ID {no} se ponavlja.")
        seen.add(no)
        if not nm: errs.append(f"ID {no}: ime je prazno.")
        if not all(32 <= ord(c) < 127 for c in nm): errs.append(f"ID {no}: ime '{nm}' sadrži znakove koje uređaj ne podržava.")
        if len(nm) > 32: errs.append(f"ID {no}: ime '{nm}' je predugo (najviše 32 znaka).")
        if not 1 <= dept <= 16: errs.append(f"ID {no}: odjel mora biti 1–16.")
        if auth not in (0, 1): errs.append(f"ID {no}: ovlast mora biti 0 ili 1.")
    if errs: raise AppError("Obrazac nije napravljen:\n" + "\n".join(errs))

def fill_device_form(db, template, out_xlsx, only_ids=None):
    """Popunjava uređajev vlastiti 'Employee Form' (list 'Employee Form': *ID, *Name, *Department(1-16), *Authority od reda 9;
    list 'Attendance Rules Form': nazivi odjela). Raspored po danima i pravila ostaju netaknuti."""
    from openpyxl import load_workbook
    wb = load_workbook(template)
    if list(wb.sheetnames) != list(DEVICE_TEMPLATE_SHEETS): raise AppError("Predložak nije obrazac uređaja (očekujem listove 'Employee Form' i 'Attendance Rules Form').")
    ws = wb["Employee Form"]
    if [ws.cell(7, c).value for c in range(1, 5)] != ["*ID", "*Name", "*Department(1-16)", "*Authority"]:
        raise AppError("Zaglavlje obrasca nije kakvo očekujem (red 7: *ID, *Name, *Department(1-16), *Authority).")
    rows = device_rows(db, only_ids)
    if not rows: raise AppError("Nema radnika za obrazac.")
    validate_device_rows(rows)
    for r in range(9, max(ws.max_row, 9 + len(rows)) + 1):
        for c in range(1, 5): ws.cell(r, c).value = None
    for k, (no, nm, dept, auth) in enumerate(rows):
        for c, v in enumerate((no, nm, dept, auth), 1): _put(ws, ws.cell(9 + k, c).coordinate, v)
    rl = wb["Attendance Rules Form"]
    for r in range(5, 21):
        n = rl.cell(r, 8).value
        if isinstance(n, (int, float)) and int(n) in DEPT_NAMES: rl.cell(r, 9).value = DEPT_NAMES[int(n)]
    _safe_save(wb, out_xlsx)
    db.log("obrazac_za_uredjaj", f"{os.path.basename(out_xlsx)} radnika={len(rows)}{' (samo odabrani)' if only_ids is not None else ''}")
    return out_xlsx

def find_soffice():
    p = shutil.which("soffice") or shutil.which("soffice.exe")
    if p: return [p]
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        c = os.path.join(base, "LibreOffice", "program", "soffice.exe")
        if os.path.exists(c): return [c]
    return None

def xlsx_to_xls(xlsx, out_dir, soffice_cmd=None):
    """Pretvara u .xls (BIFF8) pomoću LibreOffice-a, ako postoji. Inače vraća None (korisnik: Excel → Save As → 97-2003)."""
    cmd = soffice_cmd or find_soffice()
    if not cmd: return None
    subprocess.run(cmd + ["--headless", "--convert-to", "xls", "--outdir", out_dir, xlsx], check=True, capture_output=True, timeout=180, creationflags=(0x08000000 if os.name == "nt" else 0))
    out = os.path.join(out_dir, os.path.splitext(os.path.basename(xlsx))[0] + ".xls")
    return out if os.path.exists(out) else None

# ---------------------------------------------------------------- izvoz statistike
STAT_KOLONE = [("id","ID"),("radnik","Radnik"),("radnih_dana_u_mjesecu","Radnih dana u mjesecu"),
    ("dana_sa_potpunim_otiscima","Dana s potpunim otiscima"),("ukupno_sati","Ukupno sati (hh:mm)"),("ukupno_sati_dec","Zbir u šihtarici (dec.)"),
    ("prosjek_sati_po_danu","Prosjek po danu"),("najduži_dan","Najduži dan"),("najkraći_dan","Najkraći dan"),
    ("prosječan_dolazak","Prosječan dolazak"),("prosječan_odlazak","Prosječan odlazak"),
    ("najraniji_dolazak","Najraniji dolazak"),("najkasniji_odlazak","Najkasniji odlazak"),
    ("broj_dana_bez_otiska","Radnih dana bez otiska"),("dana_s_anomalijom","Dana s anomalijom"),
    ("dana_s_korekcijom","Dana s korekcijom"),("sati_godisnji","Godišnji (sati)"),("sati_bolovanje","Bolovanje (sati)"),
    ("sati_praznik","Praznik (sati)"),("sati_terenski","Terenski (sati)"),("sati_prekovremeni","Prekovremeni (sati)"),
    ("razlika_prema_ugovorenom","Razlika prema ugovorenom")]

def all_stats(db, y, m, today=None):
    return [month_stats(db, e["id"], y, m, today) for e in db.employees()]

def export_stats_xlsx(db, path, y, m):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = Workbook(); ws = wb.active; ws.title = f"Statistika {m:02d}-{y}"
    ws.append([f"Statistika prisustva – {MJESECI[m-1]} {y}"]); ws["A1"].font = Font(name="Arial", bold=True, size=12)
    ws.append([k for _, k in STAT_KOLONE])
    for c in ws[2]:
        c.font = Font(name="Arial", bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F3864")
        c.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
    for s in all_stats(db, y, m):
        ws.append([s.get(k, "") for k, _ in STAT_KOLONE])
    for row in ws.iter_rows(min_row=3):
        for c in row:
            c.font = Font(name="Arial", size=10)
            if isinstance(c.value, str) and c.value[:1] in ("=", "+", "-", "@"): c.data_type = "s"
    for i in range(1, len(STAT_KOLONE) + 1): ws.column_dimensions[ws.cell(2, i).column_letter].width = 16
    ws.column_dimensions["B"].width = 28; ws.freeze_panes = "C3"
    _safe_save(wb, path); db.log("izvoz_statistike", f"{MJESECI[m-1]} {y}"); return path
