# -*- coding: utf-8 -*-
"""IDSS – Evidencija radnog vremena. Grafičko sučelje (Tkinter, dolazi uz Python za Windows)."""
import os, sys, datetime as dt, traceback, calendar
import tkinter as tk
from tkinter import ttk, filedialog
import tkinter.font as tkfont

APP_DIR = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, APP_DIR)
import core, inspekcija, analytics, charts, roster, theme as T
from core import AppError, MJESECI, DANI, NAZIVI_VRSTA, DEPT_NAMES
from widgets import Btn, Card, ChartCanvas, Form, message, ask_text, style_ttk, choice

DEFAULT_BASE = r"C:\DAVOR_IDSS\Locker\HR\SIHTERICE"
TEMPLATE = os.path.join(APP_DIR, "sablon", "Sihtarica_IDSS.xlsx")
DEVICE_TEMPLATE = os.path.join(APP_DIR, "sablon", "Employee_Form_sablon.xlsx")
START_LIST = os.path.join(APP_DIR, "podaci_za_pocetak", "IDSS_Zaposlenici_prijedlog.xlsx")
PAGES = ["Nadzorna ploča", "Zaposlenici", "Uvoz s uređaja", "Pregled po radniku", "Odsustva i praznici", "Statistika", "Šihtarica", "INSPEKCIJA", "Uređaj", "Postavke"]

def base_folder():
    try:
        p = os.path.join(DEFAULT_BASE, "IDSS_Evidencija"); os.makedirs(p, exist_ok=True); return p
    except OSError:
        p = os.path.join(os.path.expanduser("~"), "IDSS_Evidencija"); os.makedirs(p, exist_ok=True); return p

def bs_date(iso): return dt.date.fromisoformat(iso).strftime("%d.%m.%Y.")
def parse_bs_date(s):
    s = s.strip().rstrip(".")
    try: return dt.datetime.strptime(s, "%d.%m.%Y").date().isoformat()
    except ValueError: raise AppError("Datum upišite u obliku dd.mm.gggg (npr. 05.10.2026).")

def guarded(fn):
    def w(self, *a, **k):
        try: return fn(self, *a, **k)
        except AppError as e: self.error("Pažnja", str(e))
        except Exception:
            with open(os.path.join(self.db.folder, "greske.log"), "a", encoding="utf-8") as f: f.write(dt.datetime.now().isoformat() + "\n" + traceback.format_exc() + "\n")
            self.error("Neočekivana greška", "Došlo je do greške. Podaci nisu oštećeni. Detalji su u datoteci greske.log u mapi s podacima.")
        finally:
            try: self.config(cursor="")
            except Exception: pass
    return w

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("IDSS – Evidencija radnog vremena"); self.geometry("1280x800"); self.minsize(1100, 700); self.configure(bg=T.BG)
        self.withdraw(); self.ok = False
        self.fonts = T.Fonts(T.pick_font(tkfont.families(self))); style_ttk(self, self.fonts)
        _t = dt.date.today(); self.mv = tk.StringVar(value=MJESECI[_t.month - 1]); self.yv = tk.StringVar(value=str(_t.year))
        self.db = core.DB(base_folder())
        if not self.login(): self.destroy(); return
        if not self.db.employees() and os.path.exists(START_LIST):
            n = self.db.load_employees_xlsx(START_LIST); self.info("Početno stanje", f"Učitano je {n} zaposlenih iz početne liste (ID-evi IDSS-001 …).")
        self.deiconify(); self.build(); self.ok = True

    # ---------------------------------------------------------- poruke
    def info(self, title, text): message(self, self.fonts, "ok", title, text)
    def warn(self, title, text): message(self, self.fonts, "warn", title, text)
    def error(self, title, text): message(self, self.fonts, "error", title, text)
    def ask(self, title, text): return message(self, self.fonts, "ask", title, text, ask=True)

    def login(self):
        if not self.db.has_password():
            while True:
                p1 = ask_text(self, self.fonts, "Prvo pokretanje", "Odaberite šifru za aplikaciju (najmanje 8 znakova). Zapišite je: ne može se povratiti.")
                if p1 is None: return False
                if p1 != ask_text(self, self.fonts, "Prvo pokretanje", "Ponovite šifru:"): self.error("Pažnja", "Šifre se ne poklapaju."); continue
                try: self.db.set_password(p1); return True
                except AppError as e: self.error("Pažnja", str(e))
        for _ in range(5):
            p = ask_text(self, self.fonts, "Prijava", "Unesite šifru:")
            if p is None: return False
            if self.db.check_password(p): return True
            self.error("Pažnja", "Pogrešna šifra.")
        return False

    # ---------------------------------------------------------- okvir aplikacije
    def build(self):
        F = self.fonts
        hdr = tk.Frame(self, bg=T.BLACK, height=60); hdr.pack(fill="x"); hdr.pack_propagate(False)
        tk.Label(hdr, text="IDSS", bg=T.BLACK, fg=T.YELLOW, font=(F.family, 22, "bold")).pack(side="left", padx=(22, 10))
        tk.Label(hdr, text="Evidencija radnog vremena", bg=T.BLACK, fg=T.WHITE, font=F.title).pack(side="left")
        Btn(hdr, "INSPEKCIJA", lambda: self.show("INSPEKCIJA"), F, "primary").pack(side="right", padx=22)
        self.lbl_resp = tk.Label(hdr, text="", bg=T.BLACK, fg=T.WHITE, font=F.small); self.lbl_resp.pack(side="right", padx=8)
        tk.Frame(self, bg=T.YELLOW, height=4).pack(fill="x")
        nav = tk.Frame(self, bg=T.BLUE, height=46); nav.pack(fill="x"); nav.pack_propagate(False)
        self.nav_items = {}
        for name in PAGES:
            box = tk.Frame(nav, bg=T.BLUE, cursor="hand2"); box.pack(side="left", fill="y")
            lab = tk.Label(box, text=name, bg=T.BLUE, fg=T.WHITE, font=F.nav, padx=14, cursor="hand2"); lab.pack(fill="both", expand=True, pady=(8, 0))
            bar = tk.Frame(box, bg=T.BLUE, height=4); bar.pack(fill="x", side="bottom")
            for wdg in (box, lab): wdg.bind("<Button-1>", lambda e, n=name: self.show(n))
            self.nav_items[name] = (lab, bar)
        self.status = tk.Label(self, text="", bg=T.WHITE, fg=T.MUTED, font=F.small, anchor="w", padx=14, pady=5); self.status.pack(side="bottom", fill="x")
        self.content = tk.Frame(self, bg=T.BG); self.content.pack(fill="both", expand=True)
        self.pages = {}
        builders = {"Nadzorna ploča": self.pg_dashboard, "Zaposlenici": self.pg_emp, "Uvoz s uređaja": self.pg_import, "Pregled po radniku": self.pg_view,
                    "Odsustva i praznici": self.pg_abs, "Statistika": self.pg_stats, "Šihtarica": self.pg_sih, "INSPEKCIJA": self.pg_insp, "Uređaj": self.pg_device, "Postavke": self.pg_settings}
        for name in PAGES:
            f = tk.Frame(self.content, bg=T.BG); self.pages[name] = f; builders[name](f)
        self.current = None; self.refresh_combos(); self.show("Nadzorna ploča")

    def show(self, name):
        for n, f in self.pages.items(): f.pack_forget()
        self.pages[name].pack(fill="both", expand=True, padx=18, pady=14); self.current = name
        for n, (lab, bar) in self.nav_items.items():
            on = n == name; lab.configure(fg=T.YELLOW if on else T.WHITE); bar.configure(bg=T.YELLOW if on else T.BLUE)
        self.refresh_combos(); self.refresh_page(name)

    @guarded
    def refresh_page(self, name):
        self.lbl_resp.config(text="Odgovorno lice: " + (self.db.get("odgovorno_lice") or "—"))
        self.status.config(text=f"Podaci: {self.db.folder}    |    Radnika: {len(self.db.employees())}    |    Posljednji uvoz: " + (
            (self.db.c.execute("SELECT imported_at FROM sources ORDER BY id DESC LIMIT 1").fetchone() or ["nije bilo"])[0]))
        {"Nadzorna ploča": self.refresh_dashboard, "Zaposlenici": self.refresh_emp, "Uvoz s uređaja": self.refresh_import, "Pregled po radniku": self.refresh_view,
         "Odsustva i praznici": self.refresh_abs, "Statistika": self.refresh_stats, "Uređaj": self.refresh_dev, "Postavke": self.refresh_settings}.get(name, lambda: None)()

    # ---------------------------------------------------------- pomoćno
    def title_bar(self, f, title, sub=""):
        box = tk.Frame(f, bg=T.BG); box.pack(fill="x", pady=(0, 10))
        tk.Label(box, text=title, bg=T.BG, fg=T.BLACK, font=self.fonts.h1).pack(anchor="w")
        if sub: tk.Label(box, text=sub, bg=T.BG, fg=T.MUTED, font=self.fonts.base, wraplength=1100, justify="left").pack(anchor="w")
        return box
    def period_bar(self, parent, on_apply):
        fr = tk.Frame(parent, bg=T.BG)
        tk.Label(fr, text="Mjesec:", bg=T.BG, fg=T.TEXT, font=self.fonts.bold).pack(side="left")
        cb = ttk.Combobox(fr, textvariable=self.mv, values=MJESECI, state="readonly", width=12); cb.pack(side="left", padx=(6, 12))
        tk.Label(fr, text="Godina:", bg=T.BG, fg=T.TEXT, font=self.fonts.bold).pack(side="left")
        sp = ttk.Spinbox(fr, textvariable=self.yv, from_=2020, to=2100, width=6, command=on_apply); sp.pack(side="left", padx=(6, 12))
        cb.bind("<<ComboboxSelected>>", lambda e: on_apply()); sp.bind("<Return>", lambda e: on_apply())
        return fr
    def period(self):
        try: y = int(self.yv.get())
        except ValueError: raise AppError("Godina nije ispravna.")
        return y, MJESECI.index(self.mv.get()) + 1
    def tree(self, parent, cols, widths, height=None):
        fr = tk.Frame(parent, bg=T.WHITE, highlightbackground=T.LINE, highlightthickness=1)
        t = ttk.Treeview(fr, columns=cols, show="headings", height=height or 10)
        for c, w in zip(cols, widths): t.heading(c, text=c); t.column(c, width=w, minwidth=40)
        sb = ttk.Scrollbar(fr, orient="vertical", command=t.yview); t.configure(yscrollcommand=sb.set)
        t.pack(side="left", fill="both", expand=True); sb.pack(side="right", fill="y")
        t.tag_configure("bad", background=T.RED, foreground=T.WHITE); t.tag_configure("fix", background=T.YELLOW, foreground=T.BLACK)
        t.tag_configure("we", foreground=T.MUTED); t.tag_configure("odd", background="#F7F7F7"); t.tag_configure("warn", background=T.YELLOW, foreground=T.BLACK)
        return fr, t
    def emp_values(self): return [f"{e['id']}  {e['name']}" for e in self.db.employees()]
    def emp_id(self, s): return s.split()[0]
    def refresh_combos(self):
        vals = self.emp_values()
        for cb in (getattr(self, n, None) for n in ("cb_emp", "cb_abs_emp")):
            if cb is not None: cb["values"] = vals
        if hasattr(self, "cb_one"): self.cb_one["values"] = ["(svi radnici)"] + vals
        if hasattr(self, "cb_emp") and vals and not self.cb_emp.get(): self.cb_emp.set(vals[0])
        if hasattr(self, "cb_one") and not self.one.get(): self.one.set("(svi radnici)")

    # ---------------------------------------------------------- nadzorna ploča
    def pg_dashboard(self, f):
        self.title_bar(f, "Nadzorna ploča", "Pregled prisustva svih radnika za odabrani mjesec. Zadržite miš iznad tačke ili trake za detalje.")
        bar = tk.Frame(f, bg=T.BG); bar.pack(fill="x", pady=(0, 10)); self.period_bar(bar, lambda: self.refresh_page("Nadzorna ploča")).pack(side="left")
        Btn(bar, "Osvježi", lambda: self.refresh_page("Nadzorna ploča"), self.fonts, "secondary").pack(side="left")
        kp = tk.Frame(f, bg=T.BG); kp.pack(fill="x", pady=(0, 12)); self.kpi = {}
        for i, (key, label, accent) in enumerate((("s_otiscima", "Radnika s otiscima", T.BLUE), ("sati", "Ukupno sati (hh:mm)", T.BLUE), ("anomalije", "Dana za provjeru", T.RED), ("bez_otiska", "Radnih dana bez otiska", T.YELLOW))):
            card = Card(kp); card.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 10, 0)); kp.columnconfigure(i, weight=1)
            tk.Frame(card, bg=accent, width=6).pack(side="left", fill="y")
            inner = tk.Frame(card, bg=T.WHITE); inner.pack(side="left", padx=16, pady=10)
            v = tk.StringVar(value="–"); self.kpi[key] = v
            tk.Label(inner, textvariable=v, bg=T.WHITE, fg=T.BLACK, font=self.fonts.kpi).pack(anchor="w")
            tk.Label(inner, text=label, bg=T.WHITE, fg=T.MUTED, font=self.fonts.base).pack(anchor="w")
        grid = tk.Frame(f, bg=T.BG); grid.pack(fill="both", expand=True)
        for i in (0, 1): grid.columnconfigure(i, weight=1, uniform="c"); grid.rowconfigure(i, weight=1, uniform="r")
        self.ov = None
        def mk(r, c, builder):
            card = Card(grid); card.grid(row=r, column=c, sticky="nsew", padx=(0 if c == 0 else 8, 0), pady=(0 if r == 0 else 8, 0))
            cv = ChartCanvas(card, builder, self.fonts, height=200); cv.pack(fill="both", expand=True, padx=2, pady=2); return cv
        sub = lambda: f"{self.mv.get()} {self.yv.get()}"
        empty = lambda w, h: charts.Scene(w, h)
        self.ch = [
            mk(0, 0, lambda w, h: charts.bar_chart(w, h, self.ov["hours"]["labels"], self.ov["hours"]["values"], "Sati po radniku", sub() + " · oznaka = broj radnika (IDSS-0xx)",
                                                   self.ov["hours"]["colors"], self.ov["hours"]["tips"], legend=[("uredno", T.BLUE), ("korekcije", T.YELLOW), ("za provjeru", T.RED)]) if self.ov else empty(w, h)),
            mk(0, 1, lambda w, h: charts.line_chart(w, h, self.ov["daily"]["labels"], [("prisutno", self.ov["daily"]["present"], T.BLUE), ("anomalije", self.ov["daily"]["anomaly"], T.RED)],
                                                    "Prisutnost po danima", "broj radnika s barem jednim otiskom", tips=self.ov["daily"]["tips"]) if self.ov else empty(w, h)),
            mk(1, 0, lambda w, h: charts.scatter_chart(w, h, self.ov["scatter"], "Dolazak × odlazak", "svaki bod = jedan radni dan jednog radnika", "vrijeme dolaska", "vrijeme odlaska") if self.ov else empty(w, h)),
            mk(1, 1, lambda w, h: charts.donut_chart(w, h, self.ov["status"], "Struktura dana", sub() + " · svi radnici", "radnika-dana") if self.ov else empty(w, h))]
    def refresh_dashboard(self):
        y, m = self.period(); self.ov = analytics.overview(self.db, y, m)
        k = self.ov["kpi"]
        self.kpi["s_otiscima"].set(f"{k['s_otiscima']} / {k['radnika']}"); self.kpi["sati"].set(k["sati"]); self.kpi["anomalije"].set(str(k["anomalije"])); self.kpi["bez_otiska"].set(str(k["bez_otiska"]))
        for c in self.ch: c.redraw()

    # ---------------------------------------------------------- zaposlenici
    def pg_emp(self, f):
        self.title_bar(f, "Zaposlenici", "ID radnika (IDSS-001 …) je trajan i jednak broju na uređaju. Ime na uređaju je bez dijakritika jer ih uređaj ne podržava.")
        bar = tk.Frame(f, bg=T.BG); bar.pack(fill="x", pady=(0, 8))
        Btn(bar, "Dodaj radnika", self.emp_add, self.fonts, "primary").pack(side="left", padx=(0, 8))
        Btn(bar, "Uvezi listu novih radnika…", self.roster_import, self.fonts, "primary").pack(side="left", padx=(0, 8))
        for t, c in (("Izmijeni označenog", self.emp_edit), ("Aktiviraj / deaktiviraj", self.emp_toggle), ("Predložak liste…", self.roster_template)): Btn(bar, t, c, self.fonts, "secondary").pack(side="left", padx=(0, 8))
        cols = ("ID", "Ime i prezime", "Radno mjesto", "Poslovni e-mail", "Telefon", "Sedmično (sati)", "Aktivan", "Ime na uređaju", "Odjel", "Ovlast")
        fr, self.t_emp = self.tree(f, cols, (80, 190, 180, 210, 140, 100, 60, 170, 150, 100)); fr.pack(fill="both", expand=True)
    def refresh_emp(self):
        self.t_emp.delete(*self.t_emp.get_children())
        for i, e in enumerate(self.db.employees(False)):
            self.t_emp.insert("", "end", iid=e["id"], tags=(("odd",) if i % 2 else ()) if e["active"] else ("we",), values=(e["id"], e["name"], e["position"], e["email"], e["phone"], e["weekly_hours"] or "",
                              "da" if e["active"] else "ne", core.translit(e["name"]), self.dept_label(e["dept"] or core.dept_for_position(e["position"])), "administrator" if e["authority"] else "radnik"))
    def dept_label(self, n): return f"{n} – {DEPT_NAMES.get(n, 'Nije postavljeno')}"
    def emp_fields(self, e=None):
        e = e or {}; dept = (e.get("dept") or core.dept_for_position(e.get("position"))) if e else 3
        return [("name", "Ime i prezime", e.get("name")), ("position", "Radno mjesto", e.get("position")), ("email", "Poslovni e-mail", e.get("email")), ("phone", "Telefon", e.get("phone")),
                ("weekly", "Ugovoreno sedmično radno vrijeme (sati; prazno = nije uneseno)", e.get("weekly_hours")),
                ("dept", "Odjel na uređaju", self.dept_label(dept), [self.dept_label(n) for n in range(1, 17)]),
                ("auth", "Ovlast na uređaju", "1 – administrator" if e.get("authority") else "0 – radnik", ["0 – radnik", "1 – administrator"])]
    def weekly(self, s):
        if not s: return None
        try: v = float(s.replace(",", "."))
        except ValueError: raise AppError("Sedmično radno vrijeme mora biti broj.")
        if not 0 < v <= 60: raise AppError("Sedmično radno vrijeme mora biti između 0 i 60 sati.")
        return v
    @guarded
    def emp_add(self):
        r = Form(self, self.fonts, "Novi radnik (ID se dodjeljuje automatski)", self.emp_fields()).result
        if r:
            if not r["name"]: raise AppError("Ime je obavezno.")
            eid = self.db.add_employee(r["name"], r["position"], r["email"], r["phone"], self.weekly(r["weekly"]), dept=int(r["dept"].split()[0]), authority=int(r["auth"].split()[0]))
            self.info("Dodano", f"Radnik je dodan s ID-em {eid}. Ne zaboravite ga unijeti i na uređaj pod brojem {int(eid[5:])}."); self.refresh_page("Zaposlenici")
    @guarded
    def emp_edit(self):
        sel = self.t_emp.selection()
        if not sel: raise AppError("Označite radnika.")
        e = self.db.employee(sel[0]); r = Form(self, self.fonts, "Izmjena radnika " + e["id"], self.emp_fields(e)).result
        if r:
            self.db.update_employee(e["id"], name=r["name"], position=r["position"], email=r["email"], phone=r["phone"], weekly_hours=self.weekly(r["weekly"]),
                                    dept=int(r["dept"].split()[0]), authority=int(r["auth"].split()[0])); self.refresh_page("Zaposlenici")
    @guarded
    def emp_toggle(self):
        sel = self.t_emp.selection()
        if not sel: raise AppError("Označite radnika.")
        e = self.db.employee(sel[0]); self.db.update_employee(e["id"], active=0 if e["active"] else 1); self.refresh_page("Zaposlenici")
    @guarded
    def roster_template(self):
        p = filedialog.asksaveasfilename(defaultextension=".xlsx", initialdir=os.path.join(self.db.folder, "Izvoz"), initialfile="Predlozak_liste_radnika.xlsx", filetypes=[("Excel", "*.xlsx")])
        if p: roster.make_template(p); self.info("Gotovo", "Predložak je spreman:\n" + p + "\n\nUpišite samo nove radnike. ID ostavite prazan.")
    @guarded
    def roster_import(self):
        p = filedialog.askopenfilename(title="Lista novih radnika", filetypes=[("Excel / CSV", "*.xlsx *.xls *.csv")])
        if not p: return
        items = roster.plan_roster(self.db, roster.read_roster(p)); res = self.roster_dialog(items)
        if res is None: return
        rep = roster.apply_roster(self.db, items, res[0], res[1], p)
        lines = [f"Dodano: {len(rep['dodani'])}   Aktivirano: {len(rep['reaktivirani'])}   Kontakt ažuriran: {len(rep['azurirani'])}   Preskočeno: {rep['preskoceno']}", ""]
        lines += [f"  {e}  {n}" for e, n in rep["dodani"]] + [f"  {e}  {n}  (ponovo aktivan)" for e, n in rep["reaktivirani"]]
        txt = os.path.join(self.db.folder, "Izvoz", dt.datetime.now().strftime("Uvoz_liste_%Y%m%d_%H%M%S.txt"))
        open(txt, "w", encoding="utf-8").write("UVOZ LISTE RADNIKA\n" + p + "\n\n" + "\n".join(lines) + "\n\nRezervna kopija baze prije uvoza: " + rep["backup"] + "\nNa uređaju unesite otiske prstiju pod gornjim brojevima.\n")
        self.refresh_page("Zaposlenici")
        if not rep["dodani"] and not rep["reaktivirani"]: self.info("Gotovo", "\n".join(lines)); return
        c = choice(self, self.fonts, "Uvoz završen", "\n".join(lines) + f"\n\nIzvještaj: {txt}\nStari radnici i njihovi podaci nisu mijenjani. Želite li odmah napraviti obrazac za uređaj?",
                   [("Samo novi radnici", "primary"), ("Svi aktivni radnici", "secondary"), ("Ne sada", "ghost")])
        if c == 0: self.device_make(only_ids={e for e, _ in rep["dodani"]} | {e for e, _ in rep["reaktivirani"]})
        elif c == 1: self.device_make()
    def roster_dialog(self, items):
        """Pregled uvoza prije primjene. Vraća (odobreni redovi, ažurirati kontakte) ili None."""
        F = self.fonts; win = tk.Toplevel(self); win.title("Pregled uvoza liste radnika"); win.geometry("1100x620"); win.transient(self); out = {"v": None}
        outer = tk.Frame(win, bg=T.WHITE, highlightbackground=T.BLUE, highlightthickness=3); outer.pack(fill="both", expand=True)
        cnt = roster.summarize(items)
        tk.Label(outer, text="Pregled uvoza (baza se još NE mijenja)", bg=T.WHITE, fg=T.BLACK, font=F.title).pack(anchor="w", padx=18, pady=(14, 2))
        tk.Label(outer, text=f"Novi: {cnt.get(roster.NOVI, 0)}   Već postoje: {cnt.get(roster.POSTOJI, 0)}   Za provjeru: {cnt.get(roster.PROVJERA, 0)}   Deaktivirani: {cnt.get(roster.REAKT, 0)}   Greške: {cnt.get(roster.GRESKA, 0)}.  "
                 "Postojeći radnici se ne brišu, ne preimenuju i ne mijenja im se ID. Redovi za provjeru i deaktivirani dodaju se tek kad ih odobrite.", bg=T.WHITE, fg=T.MUTED, font=F.base, wraplength=1040, justify="left").pack(anchor="w", padx=18, pady=(0, 8))
        cols = ("Status", "Red", "Ime i prezime", "Radno mjesto", "ID", "Odobreno", "Napomena")
        fr, tree = self.tree(outer, cols, (110, 50, 220, 150, 90, 80, 380), height=14); fr.pack(fill="both", expand=True, padx=18)
        accepted = set()
        def fill():
            tree.delete(*tree.get_children())
            for it in items:
                tag = {"GREŠKA": "bad", "PROVJERA": "warn", "REAKTIVIRATI": "warn", "POSTOJI": "we"}.get(it["status"], "")
                ok = "DA" if it["row"] in accepted else ("" if it["status"] in (roster.PROVJERA, roster.REAKT) else "")
                tree.insert("", "end", iid=str(it["row"]), tags=(tag,), values=(it["status"], it["row"], it["name"], it["position"], it["id"] or "(po odobrenju)", ok, it["note"]))
        fill(); upd = tk.BooleanVar(value=False)
        def toggle():
            for iid in tree.selection():
                it = next(i for i in items if str(i["row"]) == iid)
                if it["status"] in (roster.PROVJERA, roster.REAKT): accepted.symmetric_difference_update({it["row"]})
            fill()
        def go():
            if not (cnt.get(roster.NOVI, 0) or accepted or (upd.get() and any(i["diffs"] for i in items))): self.warn("Nema ničega za primjenu", "Nema novih radnika niti odobrenih izmjena."); return
            out["v"] = (set(accepted), bool(upd.get())); win.destroy()
        tk.Checkbutton(outer, text="Ažuriraj kontakt podatke POSTOJEĆIH radnika (radno mjesto, e-mail, telefon) ako se razlikuju. Ime i ID se nikad ne mijenjaju.", variable=upd, bg=T.WHITE, fg=T.BLACK, font=F.base, anchor="w", activebackground=T.WHITE).pack(fill="x", padx=18, pady=(8, 0))
        bar = tk.Frame(outer, bg=T.WHITE); bar.pack(fill="x", padx=18, pady=12)
        Btn(bar, "Primijeni", go, F, "primary").pack(side="right", padx=(8, 0)); Btn(bar, "Odustani", win.destroy, F, "ghost").pack(side="right", padx=(8, 0))
        Btn(bar, "Odobri / povuci označene (provjera, deaktivirani)", toggle, F, "secondary").pack(side="left")
        win.bind("<Escape>", lambda e: win.destroy()); win.grab_set(); self.wait_window(win); return out["v"]

    # ---------------------------------------------------------- uvoz
    def pg_import(self, f):
        self.title_bar(f, "Uvoz s uređaja", "Čita izvještaj s uređaja (All Report ili Individual Report, list Attendance Logs) i dodaje sve sirove otiske u bazu. Izvorna datoteka se ne mijenja; kopija ide u mapu Arhiva_uvoza. "
                       "Ponovni uvoz ili preklapanje perioda ne pravi duplikate. Ako išta nije jasno, uvoz staje i NIŠTA se ne upisuje.")
        Btn(f, "Odaberi datoteku s uređaja i uvezi…", self.do_import, self.fonts, "primary").pack(anchor="w", pady=(0, 12))
        fr, self.t_src = self.tree(f, ("Datoteka", "Uvezeno", "Novih otisaka", "Duplikata"), (420, 190, 130, 110), height=12); fr.pack(fill="x")
    @guarded
    def do_import(self):
        init = DEFAULT_BASE if os.path.isdir(DEFAULT_BASE) else os.path.expanduser("~")
        p = filedialog.askopenfilename(title="All Report", initialdir=init, filetypes=[("Excel", "*.xls *.xlsx")])
        if not p: return
        self.config(cursor="watch"); self.update_idletasks(); r = core.import_device_file(self.db, p)
        w = ("\n\nUpozorenja:\n" + "\n".join(r["upozorenja"])) if r.get("upozorenja") else ""
        (self.warn if r.get("upozorenja") else self.info)("Uvoz", f"{r['poruka']}\nRadnika u izvještaju: {r.get('radnika_u_izvjestaju', '–')} (s otiscima: {r.get('radnika_s_otiscima', '–')})\nNovih otisaka: {r['novih']}\nVeć postojećih (preskočeno): {r['duplikata']}{w}"); self.refresh_page("Uvoz s uređaja")
    def refresh_import(self):
        self.t_src.delete(*self.t_src.get_children())
        for i, r in enumerate(self.db.c.execute("SELECT filename, imported_at, n_new, n_dup FROM sources ORDER BY id DESC")): self.t_src.insert("", "end", tags=("odd",) if i % 2 else (), values=tuple(r))

    # ---------------------------------------------------------- pregled po radniku
    def pg_view(self, f):
        self.title_bar(f, "Pregled po radniku", "Plavo = uredno, žuto = korigirano, crveno = dan za provjeru (neparan ili neočekivan broj otisaka). Korekcija traži obavezan razlog.")
        bar = tk.Frame(f, bg=T.BG); bar.pack(fill="x", pady=(0, 8))
        self.cb_emp = ttk.Combobox(bar, state="readonly", width=38); self.cb_emp.pack(side="left", padx=(0, 12)); self.cb_emp.bind("<<ComboboxSelected>>", lambda e: self.refresh_view())
        self.period_bar(bar, self.refresh_view).pack(side="left")
        Btn(bar, "Korekcija označenog dana…", self.correct, self.fonts, "primary").pack(side="left")
        self.view_data = None
        card = Card(f); card.pack(fill="x", pady=(0, 8))
        self.ch_view = ChartCanvas(card, lambda w, h: charts.bar_chart(w, h, self.view_data[0], self.view_data[1], "Sati po danima", "", self.view_data[2], self.view_data[3], fmt=lambda v: core.fmt_min(round(v * 60))) if self.view_data else charts.Scene(w, h), self.fonts, height=190)
        self.ch_view.pack(fill="x")
        cols = ("Datum", "Dan", "Svi otisci", "Početak", "Poč. pauze", "Kraj pauze", "Kraj", "Ukupno (hh:mm)", "Status")
        fr, self.t_view = self.tree(f, cols, (100, 110, 260, 70, 90, 90, 70, 120, 280), height=14); fr.pack(fill="both", expand=True)
        self.lbl_sum = tk.Label(f, text="", bg=T.BG, fg=T.BLACK, font=self.fonts.bold, anchor="w"); self.lbl_sum.pack(fill="x", pady=(6, 0))
    @guarded
    def refresh_view(self):
        if not self.cb_emp.get(): return
        eid = self.emp_id(self.cb_emp.get()); y, m = self.period(); recs = core.day_records(self.db, eid, y, m); hol = self.db.holidays()
        self.view_data = analytics.employee_daily(self.db, eid, y, m); self.ch_view.redraw()
        self.t_view.delete(*self.t_view.get_children())
        for i in range(1, calendar.monthrange(y, m)[1] + 1):
            d = dt.date(y, m, i); iso = d.isoformat(); r = recs.get(iso); fin = r["final"] if r else {}
            if r: h = core.day_hours(fin); status = ("ANOMALIJA: " + r["flag"]) if not r["resolved"] else ("korigirano: " + "; ".join(r["reasons"]) if r["corrected"] else "uredno"); tag = "bad" if not r["resolved"] else ("fix" if r["corrected"] else "")
            else: h, status, tag = None, hol.get(iso, ""), ("we" if d.weekday() >= 5 else "")
            self.t_view.insert("", "end", iid=iso, tags=(tag,), values=(bs_date(iso), DANI[d.weekday()], " ".join(r["times"]) if r else "", fin.get("start", ""), fin.get("ps", ""), fin.get("pe", ""), fin.get("end", ""), core.fmt_min(core.day_minutes(fin)), status))
        s = core.month_stats(self.db, eid, y, m)
        self.lbl_sum.config(text=f"Ukupno: {s['ukupno_sati']}   |   prosječan dolazak {s['prosječan_dolazak'] or '–'}   |   prosječan odlazak {s['prosječan_odlazak'] or '–'}   |   dana za provjeru: {s['dana_s_anomalijom']}   |   radnih dana bez otiska: {s['broj_dana_bez_otiska']}")
    @guarded
    def correct(self):
        sel = self.t_view.selection()
        if not sel or not self.cb_emp.get(): raise AppError("Označite dan u tabeli.")
        eid = self.emp_id(self.cb_emp.get()); day = sel[0]; fin = core.day_records(self.db, eid, *self.period()).get(day, {"final": {}})["final"]
        res = Form(self, self.fonts, "Korekcija za " + bs_date(day), [("start", "Početak rada (hh:mm, prazno = bez vrijednosti)", fin.get("start", "")), ("ps", "Početak pauze", fin.get("ps", "")),
                   ("pe", "Završetak pauze", fin.get("pe", "")), ("end", "Završetak rada", fin.get("end", "")), ("reason", "Razlog korekcije (OBAVEZNO)", "")]).result
        if not res: return
        if not res["reason"]: raise AppError("Razlog korekcije je obavezan.")
        for k in ("start", "ps", "pe", "end"):
            if res[k] != fin.get(k, ""): self.db.add_correction(eid, day, k, res[k], res["reason"])
        new = core.day_records(self.db, eid, *self.period()).get(day, {"final": {}})["final"]
        if new.get("start") and new.get("end") and core.norm_hhmm(new["end"]) <= core.norm_hhmm(new["start"]):
            self.warn("Provjerite unos", "Završetak rada nije poslije početka. Takav dan INSPEKCIJA ne propušta (šihtarica se neće izvesti) dok se ne ispravi.")
        self.refresh_view()

    # ---------------------------------------------------------- odsustva
    def pg_abs(self, f):
        self.title_bar(f, "Odsustva i praznici", "Odsustva i posebni sati (unosi direktor) upisuju se u odgovarajuće kolone šihtarice. Praznici se koriste u statistici radnih dana.")
        top = Card(f); top.pack(fill="x", pady=(0, 10)); inner = tk.Frame(top, bg=T.WHITE); inner.pack(fill="x", padx=12, pady=10)
        self.ab = {k: tk.StringVar() for k in ("emp", "day", "kind", "hours", "note")}; self.ab["kind"].set(NAZIVI_VRSTA["godisnji"]); self.ab["hours"].set("8")
        def lab(t): tk.Label(inner, text=t, bg=T.WHITE, fg=T.MUTED, font=self.fonts.small).pack(side="left", padx=(4, 2))
        self.cb_abs_emp = ttk.Combobox(inner, textvariable=self.ab["emp"], state="readonly", width=32); self.cb_abs_emp.pack(side="left", padx=3)
        ttk.Entry(inner, textvariable=self.ab["day"], width=12).pack(side="left", padx=3); lab("dd.mm.gggg")
        ttk.Combobox(inner, textvariable=self.ab["kind"], values=list(NAZIVI_VRSTA.values()), state="readonly", width=22).pack(side="left", padx=3)
        ttk.Entry(inner, textvariable=self.ab["hours"], width=6).pack(side="left", padx=3); lab("sati")
        ttk.Entry(inner, textvariable=self.ab["note"], width=28).pack(side="left", padx=3); lab("napomena / referenca")
        Btn(inner, "Dodaj", self.abs_add, self.fonts, "primary").pack(side="left", padx=10)
        bar = tk.Frame(f, bg=T.BG); bar.pack(fill="x", pady=(0, 6)); self.period_bar(bar, self.refresh_abs).pack(side="left")
        Btn(bar, "Prikaži za izabranog radnika", self.refresh_abs, self.fonts, "secondary").pack(side="left", padx=(0, 8)); Btn(bar, "Obriši označeno", self.abs_del, self.fonts, "danger").pack(side="left")
        fr, self.t_abs = self.tree(f, ("Datum", "Vrsta", "Sati", "Napomena"), (110, 230, 70, 560), height=9); fr.pack(fill="x", pady=(0, 10))
        hol = Card(f); hol.pack(fill="x"); hi = tk.Frame(hol, bg=T.WHITE); hi.pack(fill="x", padx=12, pady=10); self.hd, self.hn = tk.StringVar(), tk.StringVar()
        tk.Label(hi, text="Praznik / neradni dan:", bg=T.WHITE, fg=T.BLACK, font=self.fonts.bold).pack(side="left", padx=(0, 8))
        ttk.Entry(hi, textvariable=self.hd, width=12).pack(side="left"); tk.Label(hi, text="dd.mm.gggg", bg=T.WHITE, fg=T.MUTED, font=self.fonts.small).pack(side="left", padx=4)
        ttk.Entry(hi, textvariable=self.hn, width=30).pack(side="left", padx=6); Btn(hi, "Dodaj praznik", self.hol_add, self.fonts, "secondary").pack(side="left", padx=6)
        self.lbl_hol = tk.Label(f, text="", bg=T.BG, fg=T.MUTED, font=self.fonts.small, wraplength=1150, justify="left"); self.lbl_hol.pack(anchor="w", pady=6)
    @guarded
    def abs_add(self):
        if not self.ab["emp"].get(): raise AppError("Odaberite radnika.")
        kind = next(k for k, v in NAZIVI_VRSTA.items() if v == self.ab["kind"].get())
        try: hrs = float(self.ab["hours"].get().replace(",", "."))
        except ValueError: raise AppError("Sati moraju biti broj (npr. 8 ili 7,5).")
        self.db.add_absence(self.emp_id(self.ab["emp"].get()), parse_bs_date(self.ab["day"].get()), kind, hrs, self.ab["note"].get().strip()); self.refresh_abs()
    @guarded
    def abs_del(self):
        for i in self.t_abs.selection(): self.db.delete_absence(int(i))
        self.refresh_abs()
    @guarded
    def hol_add(self): self.db.add_holiday(parse_bs_date(self.hd.get()), self.hn.get().strip() or "Neradni dan"); self.refresh_abs()
    def refresh_abs(self):
        self.t_abs.delete(*self.t_abs.get_children())
        if self.ab["emp"].get():
            y, m = self.period()
            for i, a in enumerate(self.db.absences(self.emp_id(self.ab["emp"].get()), y, m)):
                self.t_abs.insert("", "end", iid=str(a["id"]), tags=("odd",) if i % 2 else (), values=(bs_date(a["day"]), NAZIVI_VRSTA[a["kind"]], a["hours"] if a["hours"] is not None else "", a["note"] or ""))
        self.lbl_hol.config(text="Praznici: " + (", ".join(f"{bs_date(d)} {n}" for d, n in sorted(self.db.holidays().items())) or "nema unesenih"))

    # ---------------------------------------------------------- statistika
    def pg_stats(self, f):
        self.title_bar(f, "Statistika", "Pokazatelji po radniku za odabrani mjesec, uz grafikon raspona boravka (prosječan dolazak → odlazak).")
        bar = tk.Frame(f, bg=T.BG); bar.pack(fill="x", pady=(0, 8)); self.period_bar(bar, self.refresh_stats).pack(side="left")
        Btn(bar, "Izvezi u Excel…", self.export_stats, self.fonts, "primary").pack(side="left", padx=(0, 16))
        tk.Label(bar, text="Prisutnost na dan:", bg=T.BG, fg=T.TEXT, font=self.fonts.bold).pack(side="left"); self.pd = tk.StringVar(value=dt.date.today().strftime("%d.%m.%Y"))
        ttk.Entry(bar, textvariable=self.pd, width=12).pack(side="left", padx=6); Btn(bar, "Ko je bio u školi", self.show_presence, self.fonts, "secondary").pack(side="left")
        card = Card(f); card.pack(fill="x", pady=(0, 8)); self.st_ov = None
        self.ch_range = ChartCanvas(card, lambda w, h: charts.range_chart(w, h, self.st_ov["ranges"][:16], "Raspon boravka po radniku", "žuti krug = prosječan dolazak, traka = do prosječnog odlaska") if self.st_ov else charts.Scene(w, h), self.fonts, height=300); self.ch_range.pack(fill="x")
        cols = [k for _, k in core.STAT_KOLONE]; fr, self.t_stat = self.tree(f, cols, [120 if c != "Radnik" else 190 for c in cols], height=10); fr.pack(fill="both", expand=True)
        self.lbl_stat = tk.Label(f, text="", bg=T.BG, fg=T.BLACK, font=self.fonts.bold, anchor="w"); self.lbl_stat.pack(fill="x", pady=(6, 0))
    def refresh_stats(self):
        y, m = self.period(); self.t_stat.delete(*self.t_stat.get_children()); rows = core.all_stats(self.db, y, m)
        for i, s in enumerate(rows): self.t_stat.insert("", "end", tags=("odd",) if i % 2 else (), values=[s.get(k, "") for k, _ in core.STAT_KOLONE])
        self.lbl_stat.config(text=f"Ukupno sati svih radnika: {core.fmt_min(sum(s['ukupno_min'] for s in rows))}   |   dana za provjeru: {sum(s['dana_s_anomalijom'] for s in rows)}")
        self.st_ov = analytics.overview(self.db, y, m); self.ch_range.redraw()
    @guarded
    def export_stats(self):
        y, m = self.period(); p = filedialog.asksaveasfilename(defaultextension=".xlsx", initialdir=os.path.join(self.db.folder, "Izvoz"), initialfile=f"Statistika_{y}_{m:02d}.xlsx", filetypes=[("Excel", "*.xlsx")])
        if p: core.export_stats_xlsx(self.db, p, y, m); self.info("Gotovo", "Statistika je izvezena.")
    @guarded
    def show_presence(self):
        day = parse_bs_date(self.pd.get()); rows = core.presence_on(self.db, day)
        self.info(f"Prisutnost {bs_date(day)}", f"Prisutno: {sum(1 for r in rows if r['otisaka'])} od {len(rows)}\n\n" + "\n".join(f"{r['radnik']}:  {r['prvi'] or '—'}  {('→ ' + r['posljednji']) if r['posljednji'] else ''}" for r in rows))

    # ---------------------------------------------------------- šihtarica
    def pg_sih(self, f):
        self.title_bar(f, "Šihtarica", "Jedna Excel datoteka, jedan radnik = jedan list, u točno istom obliku kao obrazac Sihtarica_IDSS.xlsx (Pravilnik FBiH, Sl. novine FBiH 92/16, čl. 8–9). "
                       "Svaki izvoz prolazi automatsku INSPEKCIJU; ako ne prođe, datoteka se ne pravi.")
        bar = tk.Frame(f, bg=T.BG); bar.pack(fill="x", pady=(0, 8)); self.period_bar(bar, lambda: None).pack(side="left")
        self.one = tk.StringVar(); tk.Label(bar, text="Radnik:", bg=T.BG, fg=T.TEXT, font=self.fonts.bold).pack(side="left")
        self.cb_one = ttk.Combobox(bar, textvariable=self.one, state="readonly", width=34); self.cb_one.pack(side="left", padx=(6, 14))
        Btn(bar, "Izvezi šihtarice", self.export_sih, self.fonts, "primary").pack(side="left", padx=(0, 8)); Btn(bar, "Provjeri nerazriješene dane", self.check_sih, self.fonts, "secondary").pack(side="left")
        card = Card(f); card.pack(fill="both", expand=True); self.txt_sih = tk.Text(card, height=20, bg=T.WHITE, fg=T.BLACK, font=self.fonts.mono, relief="flat", padx=12, pady=10); self.txt_sih.pack(fill="both", expand=True)
    def selected_ids(self):
        v = self.one.get(); return None if (not v or v.startswith("(svi")) else [self.emp_id(v)]
    @guarded
    def check_sih(self):
        y, m = self.period(); self.txt_sih.delete("1.0", "end"); n = 0
        for e in (self.db.employees() if not self.selected_ids() else [self.db.employee(self.selected_ids()[0])]):
            u = core.unresolved(self.db, e["id"], y, m)
            if u: n += 1; self.txt_sih.insert("end", f"{e['id']} {e['name']}: " + ", ".join(bs_date(d) for d in u) + "\n")
        self.txt_sih.insert("end", "Nema nerazriješenih dana." if not n else f"\nRadnika s nerazriješenim danima: {n}")
    @guarded
    def export_sih(self):
        y, m = self.period(); out = os.path.join(self.db.folder, "Izvoz", f"Sihtarica_IDSS_{y}_{m:02d}.xlsx")
        out = filedialog.asksaveasfilename(defaultextension=".xlsx", initialdir=os.path.dirname(out), initialfile=os.path.basename(out), filetypes=[("Excel", "*.xlsx")])
        if not out: return
        self.config(cursor="watch"); self.update_idletasks(); allow = False
        try: core.export_sihtarica(self.db, TEMPLATE, out, y, m, self.selected_ids())
        except AppError as e:
            if "nerazriješeni" not in str(e): raise
            if not self.ask("Nerazriješeni dani", str(e) + "\n\nIzvesti ipak? Ti dani ostaju PRAZNI u šihtarici."): return
            allow = True; core.export_sihtarica(self.db, TEMPLATE, out, y, m, self.selected_ids(), allow_unresolved=True)
        rep = getattr(self.db, "last_inspection", None); extra = ""
        if rep: rp = os.path.splitext(out)[0] + "_INSPEKCIJA.txt"; rep.save(rp); extra = f"\n\nInspekcija: {'PROŠLA' if rep.ok else 'NIJE PROŠLA'} (upozorenja: {rep.count(inspekcija.UPOZ)}). Izvještaj: {rp}"
        (self.warn if allow else self.info)("Gotovo", "Šihtarice su izvezene. Ukupni sati se izračunavaju formulama pri otvaranju u Excelu." + extra)

    # ---------------------------------------------------------- INSPEKCIJA
    def pg_insp(self, f):
        self.title_bar(f, "INSPEKCIJA", "Nezavisna provjera da svaki radni list tačno odgovara kanonskom obrascu šihtarice i podacima u bazi: tekstovi, formule, formati, validacije, postavke štampe, logika unosa i (uz LibreOffice) preračun formula. "
                       "Ne zamjenjuje pravnu ocjenu usklađenosti s propisima.")
        bar = tk.Frame(f, bg=T.BG); bar.pack(fill="x", pady=(0, 8)); self.period_bar(bar, lambda: None).pack(side="left")
        Btn(bar, "Pokreni inspekciju mjeseca", self.run_insp_month, self.fonts, "primary").pack(side="left", padx=(0, 8))
        Btn(bar, "Provjeri postojeću datoteku…", self.run_insp_file, self.fonts, "secondary").pack(side="left", padx=(0, 8))
        Btn(bar, "Snimi izvještaj…", self.save_insp, self.fonts, "ghost").pack(side="left")
        self.banner = tk.Label(f, text="Inspekcija još nije pokrenuta.", bg=T.WHITE, fg=T.MUTED, font=self.fonts.h2, anchor="w", padx=18, pady=14, highlightbackground=T.LINE, highlightthickness=1); self.banner.pack(fill="x", pady=(0, 8))
        self.cnt = tk.Label(f, text="", bg=T.BG, fg=T.BLACK, font=self.fonts.base, anchor="w"); self.cnt.pack(fill="x", pady=(0, 6))
        fr, self.t_insp = self.tree(f, ("Ozbiljnost", "List", "Ćelija", "Kod", "Opis"), (110, 230, 70, 130, 640), height=16); fr.pack(fill="both", expand=True); self.last_rep = None
    def show_report(self, rep):
        self.last_rep = rep; self.t_insp.delete(*self.t_insp.get_children())
        if rep.ok: self.banner.config(text=f"✔ INSPEKCIJA PROŠLA – nema grešaka  ({len(rep.sheets)} listova)", bg=T.BLUE, fg=T.WHITE, highlightbackground=T.BLUE)
        else: self.banner.config(text=f"✖ INSPEKCIJA NIJE PROŠLA – grešaka: {rep.count(inspekcija.GRESKA)}", bg=T.RED, fg=T.WHITE, highlightbackground=T.RED)
        self.cnt.config(text=f"Grešaka: {rep.count(inspekcija.GRESKA)}    Upozorenja: {rep.count(inspekcija.UPOZ)}    Napomena: {rep.count(inspekcija.INFO)}    SHA-256: {rep.sha256[:16]}…")
        order = {inspekcija.GRESKA: 0, inspekcija.UPOZ: 1, inspekcija.INFO: 2}
        for sev, sheet, cell, code, msg in sorted(rep.findings, key=lambda x: order[x[0]]):
            self.t_insp.insert("", "end", tags=("bad" if sev == inspekcija.GRESKA else "warn" if sev == inspekcija.UPOZ else "",), values=(sev, sheet, cell, code, msg))
    @guarded
    def run_insp_month(self):
        y, m = self.period(); self.config(cursor="watch"); self.update_idletasks()
        self.show_report(inspekcija.inspect_month(self.db, TEMPLATE, y, m))
    @guarded
    def run_insp_file(self):
        y, m = self.period(); p = filedialog.askopenfilename(title="Šihtarica za inspekciju", initialdir=os.path.join(self.db.folder, "Izvoz"), filetypes=[("Excel", "*.xlsx")])
        if not p: return
        self.config(cursor="watch"); self.update_idletasks(); self.show_report(inspekcija.inspect_file(self.db, p, y, m, template=TEMPLATE, allow_unresolved=False))
    @guarded
    def save_insp(self):
        if not self.last_rep: raise AppError("Najprije pokrenite inspekciju.")
        p = filedialog.asksaveasfilename(defaultextension=".txt", initialdir=os.path.join(self.db.folder, "Izvoz"), initialfile=f"Inspekcija_{self.last_rep.title.replace(' ', '_')}.txt", filetypes=[("Tekst", "*.txt")])
        if p: self.last_rep.save(p); self.info("Snimljeno", p)

    # ---------------------------------------------------------- uređaj
    def pg_device(self, f):
        self.title_bar(f, "Uređaj FA01H", "Aplikacija popunjava uređajev vlastiti obrazac (Employee Form): ID, ime bez dijakritika, odjel i ovlast. Raspored i pravila ostaju kakva jesu. Otisci prstiju, kartice i lozinke se unose samo na uređaju. "
                       "Na uređaju: Izbornik → Statistika pohađanja → Učitajte obrazac za zaposlene (USB u FAT32 formatu). PRIJE učitavanja sačuvajte korisnike s uređaja i izvezite sve izvještaje. Deaktivirani radnici se ne nalaze u obrascu: ako ih uređaj pri učitavanju briše, mogu nestati njihovi otisci prstiju.")
        bar = tk.Frame(f, bg=T.BG); bar.pack(fill="x", pady=(0, 10))
        Btn(bar, "Obrazac za uređaj – svi aktivni radnici", self.device_make, self.fonts, "primary").pack(side="left", padx=(0, 8))
        Btn(bar, "Obrazac – samo radnici iz posljednjeg uvoza liste", lambda: self.device_make(only_ids=set(filter(None, self.db.get("zadnje_dodani").split(",")))), self.fonts, "secondary").pack(side="left")
        fr, self.t_dev = self.tree(f, ("Broj na uređaju", "Ime na uređaju", "Ime i prezime", "Odjel", "Ovlast"), (130, 250, 270, 190, 120)); fr.pack(fill="both", expand=True)
    @guarded
    def device_make(self, only_ids=None):
        out_dir = os.path.join(self.db.folder, "Izvoz", "Za_uredjaj" + ("_samo_novi" if only_ids is not None else "")); os.makedirs(out_dir, exist_ok=True)
        x = core.fill_device_form(self.db, DEVICE_TEMPLATE, os.path.join(out_dir, "Employee_Form.xlsx"), only_ids=only_ids)
        try: xls = core.xlsx_to_xls(x, out_dir)
        except Exception: xls = None
        if xls: self.info("Gotovo", f"Obrazac je spreman:\n{xls}\n\nKopirajte ga na korijen USB-a (FAT32) pod imenom Employee_Form.xls i učitajte na uređaju.")
        else: self.warn("Skoro gotovo", f"Napravljen je:\n{x}\n\nUređaj traži .xls. Otvorite datoteku u Excelu, pa Datoteka → Spremi kao → 'Excel 97-2003 radna knjiga (*.xls)' pod imenom Employee_Form.xls, i kopirajte na USB.")
    def refresh_dev(self):
        self.t_dev.delete(*self.t_dev.get_children())
        for i, e in enumerate(self.db.employees()): self.t_dev.insert("", "end", tags=("odd",) if i % 2 else (), values=(e["device_no"], core.translit(e["name"]), e["name"], self.dept_label(e["dept"] or core.dept_for_position(e["position"])), "administrator" if e["authority"] else "radnik"))

    # ---------------------------------------------------------- postavke
    def pg_settings(self, f):
        self.title_bar(f, "Postavke"); card = Card(f); card.pack(fill="x"); g = tk.Frame(card, bg=T.WHITE); g.pack(fill="x", padx=20, pady=16)
        self.s_resp, self.s_naz, self.s_gap = tk.StringVar(), tk.StringVar(), tk.StringVar()
        for i, (lab, var) in enumerate((("Odgovorno lice (ide u šihtaricu)", self.s_resp), ("Naziv ustanove", self.s_naz), ("Razmak duplih otisaka (minute, kao na uređaju)", self.s_gap))):
            tk.Label(g, text=lab, bg=T.WHITE, fg=T.BLACK, font=self.fonts.base).grid(row=i, column=0, sticky="w", pady=6, padx=(0, 18)); ttk.Entry(g, textvariable=var, width=42).grid(row=i, column=1, pady=6, sticky="w")
        b = tk.Frame(card, bg=T.WHITE); b.pack(fill="x", padx=20, pady=(0, 16))
        Btn(b, "Spremi postavke", self.save_settings, self.fonts, "primary").pack(side="left", padx=(0, 8)); Btn(b, "Promijeni šifru…", self.change_pw, self.fonts, "secondary").pack(side="left", padx=(0, 8))
        Btn(b, "Napravi rezervnu kopiju baze", self.do_backup, self.fonts, "secondary").pack(side="left")
        self.lbl_path = tk.Label(f, text="", bg=T.BG, fg=T.MUTED, font=self.fonts.small); self.lbl_path.pack(anchor="w", pady=12)
    def refresh_settings(self):
        self.s_resp.set(self.db.get("odgovorno_lice")); self.s_naz.set(self.db.get("naziv_ustanove")); self.s_gap.set(self.db.get("min_razmak", "3")); self.lbl_path.config(text="Podaci se nalaze u: " + self.db.folder)
    @guarded
    def save_settings(self):
        g = self.s_gap.get().strip()
        if not g.isdigit() or not 1 <= int(g) <= 30: raise AppError("Razmak duplih otisaka mora biti cijeli broj minuta od 1 do 30.")
        self.db.set("odgovorno_lice", self.s_resp.get().strip()); self.db.set("naziv_ustanove", self.s_naz.get().strip()); self.db.set("min_razmak", g); self.info("Spremljeno", "Postavke su spremljene."); self.refresh_page("Postavke")
    @guarded
    def change_pw(self):
        old = ask_text(self, self.fonts, "Šifra", "Trenutna šifra:")
        if old is None or not self.db.check_password(old): raise AppError("Trenutna šifra nije točna.")
        n1 = ask_text(self, self.fonts, "Šifra", "Nova šifra (najmanje 8 znakova):")
        if n1 is None: return
        if n1 != ask_text(self, self.fonts, "Šifra", "Ponovite novu šifru:"): raise AppError("Šifre se ne poklapaju.")
        self.db.set_password(n1); self.info("Gotovo", "Šifra je promijenjena.")
    @guarded
    def do_backup(self): self.info("Gotovo", "Rezervna kopija:\n" + self.db.backup())

if __name__ == "__main__":
    app = App()
    if app.ok: app.mainloop()
