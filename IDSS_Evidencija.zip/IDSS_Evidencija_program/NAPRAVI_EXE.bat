@echo off
cd /d "%~dp0"
py -3 -m pip install --upgrade pyinstaller openpyxl xlrd
py -3 -m PyInstaller --noconfirm --windowed --name IDSS_Evidencija --add-data "sablon;sablon" --add-data "podaci_za_pocetak;podaci_za_pocetak" start.py
echo.
echo Gotovo. Program je u mapi dist\IDSS_Evidencija (IDSS_Evidencija.exe).
pause
